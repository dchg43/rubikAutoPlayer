import ch.randelshofer.rubik.RubikPlayerApp;
import java.awt.BorderLayout;

public class RubikPlayer extends RubikPlayerApp {
  private void initComponents() {
    setLayout(new BorderLayout());
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\RubikPlayer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */