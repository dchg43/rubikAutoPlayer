package ch.randelshofer.io;

import java.io.IOException;
import java.io.Reader;
import java.util.Vector;

public class StreamPosTokenizer {
  private Reader reader = null;
  
  private int readpos = 0;
  
  private int startpos = -1;
  
  private int endpos = -1;
  
  private Vector unread = new Vector();
  
  private char[] buf = new char[20];
  
  private int peekc = Integer.MAX_VALUE;
  
  private static final int NEED_CHAR = 2147483647;
  
  private static final int SKIP_LF = 2147483646;
  
  private boolean pushedBack;
  
  private boolean forceLower;
  
  private int LINENO = 1;
  
  private boolean eolIsSignificantP = false;
  
  private boolean slashSlashCommentsP = false;
  
  private boolean slashStarCommentsP = false;
  
  private char[] slashSlash = new char[] { '/', '/' };
  
  private char[] slashStar = new char[] { '/', '*' };
  
  private char[] starSlash = new char[] { '*', '/' };
  
  private byte[] ctype = new byte[256];
  
  private static final byte CT_WHITESPACE = 1;
  
  private static final byte CT_DIGIT = 2;
  
  private static final byte CT_ALPHA = 4;
  
  private static final byte CT_QUOTE = 8;
  
  private static final byte CT_COMMENT = 16;
  
  public int ttype = -4;
  
  public static final int TT_EOF = -1;
  
  public static final int TT_EOL = 10;
  
  public static final int TT_NUMBER = -2;
  
  public static final int TT_WORD = -3;
  
  private static final int TT_NOTHING = -4;
  
  public String sval;
  
  public double nval;
  
  private StreamPosTokenizer() {
    wordChars(97, 122);
    wordChars(65, 90);
    wordChars(160, 255);
    whitespaceChars(0, 32);
    commentChar(47);
    quoteChar(34);
    quoteChar(39);
    parseNumbers();
  }
  
  public StreamPosTokenizer(Reader paramReader) {
    this();
    if (paramReader == null)
      throw new NullPointerException(); 
    this.reader = paramReader;
  }
  
  public void resetSyntax() {
    int i = this.ctype.length;
    while (--i >= 0)
      this.ctype[i] = 0; 
  }
  
  public void wordChars(int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      paramInt1 = 0; 
    if (paramInt2 >= this.ctype.length)
      paramInt2 = this.ctype.length - 1; 
    while (paramInt1 <= paramInt2)
      this.ctype[paramInt1++] = (byte)(this.ctype[paramInt1++] | 0x4); 
  }
  
  public void whitespaceChars(int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      paramInt1 = 0; 
    if (paramInt2 >= this.ctype.length)
      paramInt2 = this.ctype.length - 1; 
    while (paramInt1 <= paramInt2)
      this.ctype[paramInt1++] = 1; 
  }
  
  public void ordinaryChars(int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      paramInt1 = 0; 
    if (paramInt2 >= this.ctype.length)
      paramInt2 = this.ctype.length - 1; 
    while (paramInt1 <= paramInt2)
      this.ctype[paramInt1++] = 0; 
  }
  
  public void ordinaryChar(int paramInt) {
    if (paramInt >= 0 && paramInt < this.ctype.length)
      this.ctype[paramInt] = 0; 
  }
  
  public void commentChar(int paramInt) {
    if (paramInt >= 0 && paramInt < this.ctype.length)
      this.ctype[paramInt] = 16; 
  }
  
  public void quoteChar(int paramInt) {
    if (paramInt >= 0 && paramInt < this.ctype.length)
      this.ctype[paramInt] = 8; 
  }
  
  public void parseNumbers() {
    for (byte b = 48; b <= 57; b++)
      this.ctype[b] = (byte)(this.ctype[b] | 0x2); 
    this.ctype[46] = (byte)(this.ctype[46] | 0x2);
    this.ctype[45] = (byte)(this.ctype[45] | 0x2);
  }
  
  public void eolIsSignificant(boolean paramBoolean) {
    this.eolIsSignificantP = paramBoolean;
  }
  
  public void slashStarComments(boolean paramBoolean) {
    this.slashStarCommentsP = paramBoolean;
  }
  
  public void slashSlashComments(boolean paramBoolean) {
    this.slashSlashCommentsP = paramBoolean;
  }
  
  public void lowerCaseMode(boolean paramBoolean) {
    this.forceLower = paramBoolean;
  }
  
  private int read() throws IOException {
    int i;
    if (this.unread.size() > 0) {
      i = ((Integer)this.unread.lastElement()).intValue();
      this.unread.removeElementAt(this.unread.size() - 1);
    } else {
      i = this.reader.read();
    } 
    if (i != -1)
      this.readpos++; 
    return i;
  }
  
  private void unread(int paramInt) {
    this.unread.addElement(new Integer(paramInt));
    this.readpos--;
  }
  
  public int nextToken() throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: getfield pushedBack : Z
    //   4: ifeq -> 17
    //   7: aload_0
    //   8: iconst_0
    //   9: putfield pushedBack : Z
    //   12: aload_0
    //   13: getfield ttype : I
    //   16: ireturn
    //   17: aload_0
    //   18: getfield ctype : [B
    //   21: astore_1
    //   22: aload_0
    //   23: aconst_null
    //   24: putfield sval : Ljava/lang/String;
    //   27: aload_0
    //   28: getfield peekc : I
    //   31: istore_2
    //   32: iload_2
    //   33: ifge -> 39
    //   36: ldc 2147483647
    //   38: istore_2
    //   39: iload_2
    //   40: ldc 2147483646
    //   42: if_icmpne -> 85
    //   45: aload_0
    //   46: invokespecial read : ()I
    //   49: istore_2
    //   50: iload_2
    //   51: ifge -> 76
    //   54: aload_0
    //   55: aload_0
    //   56: aload_0
    //   57: getfield readpos : I
    //   60: iconst_1
    //   61: isub
    //   62: dup_x1
    //   63: putfield endpos : I
    //   66: putfield startpos : I
    //   69: aload_0
    //   70: iconst_m1
    //   71: dup_x1
    //   72: putfield ttype : I
    //   75: ireturn
    //   76: iload_2
    //   77: bipush #10
    //   79: if_icmpne -> 85
    //   82: ldc 2147483647
    //   84: istore_2
    //   85: iload_2
    //   86: ldc 2147483647
    //   88: if_icmpne -> 122
    //   91: aload_0
    //   92: invokespecial read : ()I
    //   95: istore_2
    //   96: iload_2
    //   97: ifge -> 122
    //   100: aload_0
    //   101: aload_0
    //   102: aload_0
    //   103: getfield readpos : I
    //   106: iconst_1
    //   107: isub
    //   108: dup_x1
    //   109: putfield endpos : I
    //   112: putfield startpos : I
    //   115: aload_0
    //   116: iconst_m1
    //   117: dup_x1
    //   118: putfield ttype : I
    //   121: ireturn
    //   122: aload_0
    //   123: iload_2
    //   124: putfield ttype : I
    //   127: aload_0
    //   128: ldc 2147483647
    //   130: putfield peekc : I
    //   133: iload_2
    //   134: sipush #256
    //   137: if_icmpge -> 146
    //   140: aload_1
    //   141: iload_2
    //   142: baload
    //   143: goto -> 147
    //   146: iconst_4
    //   147: istore_3
    //   148: iload_3
    //   149: iconst_1
    //   150: iand
    //   151: ifeq -> 318
    //   154: iload_2
    //   155: bipush #13
    //   157: if_icmpne -> 225
    //   160: aload_0
    //   161: dup
    //   162: getfield LINENO : I
    //   165: iconst_1
    //   166: iadd
    //   167: putfield LINENO : I
    //   170: aload_0
    //   171: getfield eolIsSignificantP : Z
    //   174: ifeq -> 206
    //   177: aload_0
    //   178: ldc 2147483646
    //   180: putfield peekc : I
    //   183: aload_0
    //   184: aload_0
    //   185: aload_0
    //   186: getfield readpos : I
    //   189: iconst_1
    //   190: isub
    //   191: dup_x1
    //   192: putfield endpos : I
    //   195: putfield startpos : I
    //   198: aload_0
    //   199: bipush #10
    //   201: dup_x1
    //   202: putfield ttype : I
    //   205: ireturn
    //   206: aload_0
    //   207: invokespecial read : ()I
    //   210: istore_2
    //   211: iload_2
    //   212: bipush #10
    //   214: if_icmpne -> 276
    //   217: aload_0
    //   218: invokespecial read : ()I
    //   221: istore_2
    //   222: goto -> 276
    //   225: iload_2
    //   226: bipush #10
    //   228: if_icmpne -> 271
    //   231: aload_0
    //   232: dup
    //   233: getfield LINENO : I
    //   236: iconst_1
    //   237: iadd
    //   238: putfield LINENO : I
    //   241: aload_0
    //   242: getfield eolIsSignificantP : Z
    //   245: ifeq -> 271
    //   248: aload_0
    //   249: aload_0
    //   250: aload_0
    //   251: getfield readpos : I
    //   254: iconst_1
    //   255: isub
    //   256: dup_x1
    //   257: putfield endpos : I
    //   260: putfield startpos : I
    //   263: aload_0
    //   264: bipush #10
    //   266: dup_x1
    //   267: putfield ttype : I
    //   270: ireturn
    //   271: aload_0
    //   272: invokespecial read : ()I
    //   275: istore_2
    //   276: iload_2
    //   277: ifge -> 300
    //   280: aload_0
    //   281: aload_0
    //   282: aload_0
    //   283: getfield readpos : I
    //   286: dup_x1
    //   287: putfield endpos : I
    //   290: putfield startpos : I
    //   293: aload_0
    //   294: iconst_m1
    //   295: dup_x1
    //   296: putfield ttype : I
    //   299: ireturn
    //   300: iload_2
    //   301: sipush #256
    //   304: if_icmpge -> 313
    //   307: aload_1
    //   308: iload_2
    //   309: baload
    //   310: goto -> 314
    //   313: iconst_4
    //   314: istore_3
    //   315: goto -> 148
    //   318: aload_0
    //   319: aload_0
    //   320: getfield readpos : I
    //   323: iconst_1
    //   324: isub
    //   325: putfield startpos : I
    //   328: iload_3
    //   329: iconst_2
    //   330: iand
    //   331: ifeq -> 584
    //   334: iconst_0
    //   335: istore #4
    //   337: iconst_0
    //   338: istore #5
    //   340: iload_2
    //   341: bipush #45
    //   343: if_icmpne -> 388
    //   346: aload_0
    //   347: invokespecial read : ()I
    //   350: istore_2
    //   351: iload_2
    //   352: bipush #46
    //   354: if_icmpeq -> 385
    //   357: iload_2
    //   358: bipush #48
    //   360: if_icmplt -> 369
    //   363: iload_2
    //   364: bipush #57
    //   366: if_icmple -> 385
    //   369: aload_0
    //   370: iload_2
    //   371: putfield peekc : I
    //   374: aload_0
    //   375: iload_2
    //   376: invokespecial unread : (I)V
    //   379: bipush #45
    //   381: istore_2
    //   382: goto -> 584
    //   385: iconst_1
    //   386: istore #5
    //   388: dconst_0
    //   389: dstore #6
    //   391: iconst_0
    //   392: istore #8
    //   394: iconst_0
    //   395: istore #9
    //   397: iload_2
    //   398: bipush #46
    //   400: if_icmpne -> 414
    //   403: iload #9
    //   405: ifne -> 414
    //   408: iconst_1
    //   409: istore #9
    //   411: goto -> 450
    //   414: bipush #48
    //   416: iload_2
    //   417: if_icmpgt -> 458
    //   420: iload_2
    //   421: bipush #57
    //   423: if_icmpgt -> 458
    //   426: iinc #4, 1
    //   429: dload #6
    //   431: ldc2_w 10.0
    //   434: dmul
    //   435: iload_2
    //   436: bipush #48
    //   438: isub
    //   439: i2d
    //   440: dadd
    //   441: dstore #6
    //   443: iload #8
    //   445: iload #9
    //   447: iadd
    //   448: istore #8
    //   450: aload_0
    //   451: invokespecial read : ()I
    //   454: istore_2
    //   455: goto -> 397
    //   458: aload_0
    //   459: iload_2
    //   460: putfield peekc : I
    //   463: iload #8
    //   465: ifeq -> 502
    //   468: ldc2_w 10.0
    //   471: dstore #10
    //   473: iinc #8, -1
    //   476: iload #8
    //   478: ifle -> 495
    //   481: dload #10
    //   483: ldc2_w 10.0
    //   486: dmul
    //   487: dstore #10
    //   489: iinc #8, -1
    //   492: goto -> 476
    //   495: dload #6
    //   497: dload #10
    //   499: ddiv
    //   500: dstore #6
    //   502: aload_0
    //   503: iload #5
    //   505: ifeq -> 514
    //   508: dload #6
    //   510: dneg
    //   511: goto -> 516
    //   514: dload #6
    //   516: putfield nval : D
    //   519: aload_0
    //   520: iload_2
    //   521: iconst_m1
    //   522: if_icmpne -> 534
    //   525: aload_0
    //   526: getfield readpos : I
    //   529: iconst_1
    //   530: isub
    //   531: goto -> 540
    //   534: aload_0
    //   535: getfield readpos : I
    //   538: iconst_2
    //   539: isub
    //   540: putfield endpos : I
    //   543: iload #4
    //   545: ifne -> 576
    //   548: aload_0
    //   549: iload_2
    //   550: invokespecial unread : (I)V
    //   553: iload #5
    //   555: ifeq -> 570
    //   558: aload_0
    //   559: bipush #46
    //   561: invokespecial unread : (I)V
    //   564: bipush #45
    //   566: istore_2
    //   567: goto -> 584
    //   570: bipush #46
    //   572: istore_2
    //   573: goto -> 584
    //   576: aload_0
    //   577: bipush #-2
    //   579: dup_x1
    //   580: putfield ttype : I
    //   583: ireturn
    //   584: iload_3
    //   585: iconst_4
    //   586: iand
    //   587: ifeq -> 752
    //   590: iconst_0
    //   591: istore #4
    //   593: iload #4
    //   595: aload_0
    //   596: getfield buf : [C
    //   599: arraylength
    //   600: if_icmplt -> 636
    //   603: aload_0
    //   604: getfield buf : [C
    //   607: arraylength
    //   608: iconst_2
    //   609: imul
    //   610: newarray char
    //   612: astore #5
    //   614: aload_0
    //   615: getfield buf : [C
    //   618: iconst_0
    //   619: aload #5
    //   621: iconst_0
    //   622: aload_0
    //   623: getfield buf : [C
    //   626: arraylength
    //   627: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   630: aload_0
    //   631: aload #5
    //   633: putfield buf : [C
    //   636: aload_0
    //   637: getfield buf : [C
    //   640: iload #4
    //   642: iinc #4, 1
    //   645: iload_2
    //   646: i2c
    //   647: castore
    //   648: aload_0
    //   649: invokespecial read : ()I
    //   652: istore_2
    //   653: iload_2
    //   654: ifge -> 661
    //   657: iconst_1
    //   658: goto -> 675
    //   661: iload_2
    //   662: sipush #256
    //   665: if_icmpge -> 674
    //   668: aload_1
    //   669: iload_2
    //   670: baload
    //   671: goto -> 675
    //   674: iconst_4
    //   675: istore_3
    //   676: iload_3
    //   677: bipush #6
    //   679: iand
    //   680: ifne -> 593
    //   683: aload_0
    //   684: iload_2
    //   685: putfield peekc : I
    //   688: aload_0
    //   689: aload_0
    //   690: getfield buf : [C
    //   693: iconst_0
    //   694: iload #4
    //   696: invokestatic copyValueOf : ([CII)Ljava/lang/String;
    //   699: putfield sval : Ljava/lang/String;
    //   702: aload_0
    //   703: getfield forceLower : Z
    //   706: ifeq -> 720
    //   709: aload_0
    //   710: aload_0
    //   711: getfield sval : Ljava/lang/String;
    //   714: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   717: putfield sval : Ljava/lang/String;
    //   720: aload_0
    //   721: iload_2
    //   722: iconst_m1
    //   723: if_icmpne -> 735
    //   726: aload_0
    //   727: getfield readpos : I
    //   730: iconst_1
    //   731: isub
    //   732: goto -> 741
    //   735: aload_0
    //   736: getfield readpos : I
    //   739: iconst_2
    //   740: isub
    //   741: putfield endpos : I
    //   744: aload_0
    //   745: bipush #-3
    //   747: dup_x1
    //   748: putfield ttype : I
    //   751: ireturn
    //   752: iload_3
    //   753: bipush #8
    //   755: iand
    //   756: ifeq -> 1192
    //   759: aload_0
    //   760: iload_2
    //   761: putfield ttype : I
    //   764: iconst_0
    //   765: istore #4
    //   767: aload_0
    //   768: invokespecial read : ()I
    //   771: istore #5
    //   773: iload #5
    //   775: iflt -> 1143
    //   778: iload #5
    //   780: aload_0
    //   781: getfield ttype : I
    //   784: if_icmpeq -> 1143
    //   787: iload #5
    //   789: bipush #10
    //   791: if_icmpeq -> 1143
    //   794: iload #5
    //   796: bipush #13
    //   798: if_icmpeq -> 1143
    //   801: iload #5
    //   803: bipush #92
    //   805: if_icmpne -> 1076
    //   808: aload_0
    //   809: invokespecial read : ()I
    //   812: istore_2
    //   813: iload_2
    //   814: istore #6
    //   816: iload_2
    //   817: bipush #48
    //   819: if_icmplt -> 923
    //   822: iload_2
    //   823: bipush #55
    //   825: if_icmpgt -> 923
    //   828: iload_2
    //   829: bipush #48
    //   831: isub
    //   832: istore_2
    //   833: aload_0
    //   834: invokespecial read : ()I
    //   837: istore #7
    //   839: bipush #48
    //   841: iload #7
    //   843: if_icmpgt -> 916
    //   846: iload #7
    //   848: bipush #55
    //   850: if_icmpgt -> 916
    //   853: iload_2
    //   854: iconst_3
    //   855: ishl
    //   856: iload #7
    //   858: bipush #48
    //   860: isub
    //   861: iadd
    //   862: istore_2
    //   863: aload_0
    //   864: invokespecial read : ()I
    //   867: istore #7
    //   869: bipush #48
    //   871: iload #7
    //   873: if_icmpgt -> 909
    //   876: iload #7
    //   878: bipush #55
    //   880: if_icmpgt -> 909
    //   883: iload #6
    //   885: bipush #51
    //   887: if_icmpgt -> 909
    //   890: iload_2
    //   891: iconst_3
    //   892: ishl
    //   893: iload #7
    //   895: bipush #48
    //   897: isub
    //   898: iadd
    //   899: istore_2
    //   900: aload_0
    //   901: invokespecial read : ()I
    //   904: istore #5
    //   906: goto -> 1085
    //   909: iload #7
    //   911: istore #5
    //   913: goto -> 1085
    //   916: iload #7
    //   918: istore #5
    //   920: goto -> 1085
    //   923: iload_2
    //   924: tableswitch default -> 1067, 97 -> 1028, 98 -> 1034, 99 -> 1067, 100 -> 1067, 101 -> 1067, 102 -> 1040, 103 -> 1067, 104 -> 1067, 105 -> 1067, 106 -> 1067, 107 -> 1067, 108 -> 1067, 109 -> 1067, 110 -> 1046, 111 -> 1067, 112 -> 1067, 113 -> 1067, 114 -> 1052, 115 -> 1067, 116 -> 1058, 117 -> 1067, 118 -> 1064
    //   1028: bipush #7
    //   1030: istore_2
    //   1031: goto -> 1067
    //   1034: bipush #8
    //   1036: istore_2
    //   1037: goto -> 1067
    //   1040: bipush #12
    //   1042: istore_2
    //   1043: goto -> 1067
    //   1046: bipush #10
    //   1048: istore_2
    //   1049: goto -> 1067
    //   1052: bipush #13
    //   1054: istore_2
    //   1055: goto -> 1067
    //   1058: bipush #9
    //   1060: istore_2
    //   1061: goto -> 1067
    //   1064: bipush #11
    //   1066: istore_2
    //   1067: aload_0
    //   1068: invokespecial read : ()I
    //   1071: istore #5
    //   1073: goto -> 1085
    //   1076: iload #5
    //   1078: istore_2
    //   1079: aload_0
    //   1080: invokespecial read : ()I
    //   1083: istore #5
    //   1085: iload #4
    //   1087: aload_0
    //   1088: getfield buf : [C
    //   1091: arraylength
    //   1092: if_icmplt -> 1128
    //   1095: aload_0
    //   1096: getfield buf : [C
    //   1099: arraylength
    //   1100: iconst_2
    //   1101: imul
    //   1102: newarray char
    //   1104: astore #6
    //   1106: aload_0
    //   1107: getfield buf : [C
    //   1110: iconst_0
    //   1111: aload #6
    //   1113: iconst_0
    //   1114: aload_0
    //   1115: getfield buf : [C
    //   1118: arraylength
    //   1119: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   1122: aload_0
    //   1123: aload #6
    //   1125: putfield buf : [C
    //   1128: aload_0
    //   1129: getfield buf : [C
    //   1132: iload #4
    //   1134: iinc #4, 1
    //   1137: iload_2
    //   1138: i2c
    //   1139: castore
    //   1140: goto -> 773
    //   1143: aload_0
    //   1144: iload #5
    //   1146: aload_0
    //   1147: getfield ttype : I
    //   1150: if_icmpne -> 1158
    //   1153: ldc 2147483647
    //   1155: goto -> 1160
    //   1158: iload #5
    //   1160: putfield peekc : I
    //   1163: aload_0
    //   1164: aload_0
    //   1165: getfield buf : [C
    //   1168: iconst_0
    //   1169: iload #4
    //   1171: invokestatic copyValueOf : ([CII)Ljava/lang/String;
    //   1174: putfield sval : Ljava/lang/String;
    //   1177: aload_0
    //   1178: aload_0
    //   1179: getfield readpos : I
    //   1182: iconst_2
    //   1183: isub
    //   1184: putfield endpos : I
    //   1187: aload_0
    //   1188: getfield ttype : I
    //   1191: ireturn
    //   1192: aload_0
    //   1193: getfield slashSlashCommentsP : Z
    //   1196: ifeq -> 1209
    //   1199: iload_2
    //   1200: aload_0
    //   1201: getfield slashSlash : [C
    //   1204: iconst_0
    //   1205: caload
    //   1206: if_icmpeq -> 1226
    //   1209: aload_0
    //   1210: getfield slashStarCommentsP : Z
    //   1213: ifeq -> 1656
    //   1216: iload_2
    //   1217: aload_0
    //   1218: getfield slashStar : [C
    //   1221: iconst_0
    //   1222: caload
    //   1223: if_icmpne -> 1656
    //   1226: iload_2
    //   1227: aload_0
    //   1228: getfield slashStar : [C
    //   1231: iconst_0
    //   1232: caload
    //   1233: if_icmpne -> 1340
    //   1236: aload_0
    //   1237: getfield slashStar : [C
    //   1240: arraylength
    //   1241: iconst_1
    //   1242: if_icmpne -> 1340
    //   1245: aload_0
    //   1246: invokespecial read : ()I
    //   1249: dup
    //   1250: istore_2
    //   1251: aload_0
    //   1252: getfield starSlash : [C
    //   1255: iconst_0
    //   1256: caload
    //   1257: if_icmpeq -> 1335
    //   1260: iload_2
    //   1261: bipush #13
    //   1263: if_icmpne -> 1295
    //   1266: aload_0
    //   1267: dup
    //   1268: getfield LINENO : I
    //   1271: iconst_1
    //   1272: iadd
    //   1273: putfield LINENO : I
    //   1276: aload_0
    //   1277: invokespecial read : ()I
    //   1280: istore_2
    //   1281: iload_2
    //   1282: bipush #10
    //   1284: if_icmpne -> 1316
    //   1287: aload_0
    //   1288: invokespecial read : ()I
    //   1291: istore_2
    //   1292: goto -> 1316
    //   1295: iload_2
    //   1296: bipush #10
    //   1298: if_icmpne -> 1316
    //   1301: aload_0
    //   1302: dup
    //   1303: getfield LINENO : I
    //   1306: iconst_1
    //   1307: iadd
    //   1308: putfield LINENO : I
    //   1311: aload_0
    //   1312: invokespecial read : ()I
    //   1315: istore_2
    //   1316: iload_2
    //   1317: ifge -> 1245
    //   1320: aload_0
    //   1321: aload_0
    //   1322: getfield readpos : I
    //   1325: putfield endpos : I
    //   1328: aload_0
    //   1329: iconst_m1
    //   1330: dup_x1
    //   1331: putfield ttype : I
    //   1334: ireturn
    //   1335: aload_0
    //   1336: invokevirtual nextToken : ()I
    //   1339: ireturn
    //   1340: iload_2
    //   1341: aload_0
    //   1342: getfield slashSlash : [C
    //   1345: iconst_0
    //   1346: caload
    //   1347: if_icmpne -> 1393
    //   1350: aload_0
    //   1351: getfield slashSlash : [C
    //   1354: arraylength
    //   1355: iconst_1
    //   1356: if_icmpne -> 1393
    //   1359: aload_0
    //   1360: invokespecial read : ()I
    //   1363: dup
    //   1364: istore_2
    //   1365: bipush #10
    //   1367: if_icmpeq -> 1383
    //   1370: iload_2
    //   1371: bipush #13
    //   1373: if_icmpeq -> 1383
    //   1376: iload_2
    //   1377: iflt -> 1383
    //   1380: goto -> 1359
    //   1383: aload_0
    //   1384: iload_2
    //   1385: putfield peekc : I
    //   1388: aload_0
    //   1389: invokevirtual nextToken : ()I
    //   1392: ireturn
    //   1393: aload_0
    //   1394: invokespecial read : ()I
    //   1397: istore_2
    //   1398: iload_2
    //   1399: aload_0
    //   1400: getfield slashStar : [C
    //   1403: iconst_1
    //   1404: caload
    //   1405: if_icmpne -> 1530
    //   1408: aload_0
    //   1409: getfield slashStarCommentsP : Z
    //   1412: ifeq -> 1530
    //   1415: iconst_0
    //   1416: istore #4
    //   1418: aload_0
    //   1419: invokespecial read : ()I
    //   1422: dup
    //   1423: istore_2
    //   1424: aload_0
    //   1425: getfield starSlash : [C
    //   1428: iconst_1
    //   1429: caload
    //   1430: if_icmpne -> 1444
    //   1433: iload #4
    //   1435: aload_0
    //   1436: getfield starSlash : [C
    //   1439: iconst_0
    //   1440: caload
    //   1441: if_icmpeq -> 1525
    //   1444: iload_2
    //   1445: bipush #13
    //   1447: if_icmpne -> 1479
    //   1450: aload_0
    //   1451: dup
    //   1452: getfield LINENO : I
    //   1455: iconst_1
    //   1456: iadd
    //   1457: putfield LINENO : I
    //   1460: aload_0
    //   1461: invokespecial read : ()I
    //   1464: istore_2
    //   1465: iload_2
    //   1466: bipush #10
    //   1468: if_icmpne -> 1500
    //   1471: aload_0
    //   1472: invokespecial read : ()I
    //   1475: istore_2
    //   1476: goto -> 1500
    //   1479: iload_2
    //   1480: bipush #10
    //   1482: if_icmpne -> 1500
    //   1485: aload_0
    //   1486: dup
    //   1487: getfield LINENO : I
    //   1490: iconst_1
    //   1491: iadd
    //   1492: putfield LINENO : I
    //   1495: aload_0
    //   1496: invokespecial read : ()I
    //   1499: istore_2
    //   1500: iload_2
    //   1501: ifge -> 1519
    //   1504: aload_0
    //   1505: aload_0
    //   1506: getfield readpos : I
    //   1509: putfield endpos : I
    //   1512: aload_0
    //   1513: iconst_m1
    //   1514: dup_x1
    //   1515: putfield ttype : I
    //   1518: ireturn
    //   1519: iload_2
    //   1520: istore #4
    //   1522: goto -> 1418
    //   1525: aload_0
    //   1526: invokevirtual nextToken : ()I
    //   1529: ireturn
    //   1530: iload_2
    //   1531: aload_0
    //   1532: getfield slashSlash : [C
    //   1535: iconst_1
    //   1536: caload
    //   1537: if_icmpne -> 1581
    //   1540: aload_0
    //   1541: getfield slashSlashCommentsP : Z
    //   1544: ifeq -> 1581
    //   1547: aload_0
    //   1548: invokespecial read : ()I
    //   1551: dup
    //   1552: istore_2
    //   1553: bipush #10
    //   1555: if_icmpeq -> 1571
    //   1558: iload_2
    //   1559: bipush #13
    //   1561: if_icmpeq -> 1571
    //   1564: iload_2
    //   1565: iflt -> 1571
    //   1568: goto -> 1547
    //   1571: aload_0
    //   1572: iload_2
    //   1573: putfield peekc : I
    //   1576: aload_0
    //   1577: invokevirtual nextToken : ()I
    //   1580: ireturn
    //   1581: aload_1
    //   1582: aload_0
    //   1583: getfield slashSlash : [C
    //   1586: iconst_0
    //   1587: caload
    //   1588: baload
    //   1589: bipush #16
    //   1591: iand
    //   1592: ifeq -> 1629
    //   1595: aload_0
    //   1596: invokespecial read : ()I
    //   1599: dup
    //   1600: istore_2
    //   1601: bipush #10
    //   1603: if_icmpeq -> 1619
    //   1606: iload_2
    //   1607: bipush #13
    //   1609: if_icmpeq -> 1619
    //   1612: iload_2
    //   1613: iflt -> 1619
    //   1616: goto -> 1595
    //   1619: aload_0
    //   1620: iload_2
    //   1621: putfield peekc : I
    //   1624: aload_0
    //   1625: invokevirtual nextToken : ()I
    //   1628: ireturn
    //   1629: aload_0
    //   1630: iload_2
    //   1631: putfield peekc : I
    //   1634: aload_0
    //   1635: aload_0
    //   1636: getfield readpos : I
    //   1639: iconst_2
    //   1640: isub
    //   1641: putfield endpos : I
    //   1644: aload_0
    //   1645: aload_0
    //   1646: getfield slashSlash : [C
    //   1649: iconst_0
    //   1650: caload
    //   1651: dup_x1
    //   1652: putfield ttype : I
    //   1655: ireturn
    //   1656: iload_3
    //   1657: bipush #16
    //   1659: iand
    //   1660: ifeq -> 1697
    //   1663: aload_0
    //   1664: invokespecial read : ()I
    //   1667: dup
    //   1668: istore_2
    //   1669: bipush #10
    //   1671: if_icmpeq -> 1687
    //   1674: iload_2
    //   1675: bipush #13
    //   1677: if_icmpeq -> 1687
    //   1680: iload_2
    //   1681: iflt -> 1687
    //   1684: goto -> 1663
    //   1687: aload_0
    //   1688: iload_2
    //   1689: putfield peekc : I
    //   1692: aload_0
    //   1693: invokevirtual nextToken : ()I
    //   1696: ireturn
    //   1697: aload_0
    //   1698: aload_0
    //   1699: getfield readpos : I
    //   1702: iconst_1
    //   1703: isub
    //   1704: putfield endpos : I
    //   1707: aload_0
    //   1708: iload_2
    //   1709: dup_x1
    //   1710: putfield ttype : I
    //   1713: ireturn
  }
  
  public void setSlashStarTokens(String paramString1, String paramString2) {
    if (paramString1.length() != paramString2.length())
      throw new IllegalArgumentException("SlashStar and StarSlash tokens must be of same length: '" + paramString1 + "' '" + paramString2 + "'"); 
    if (paramString1.length() < 1 || paramString1.length() > 2)
      throw new IllegalArgumentException("SlashStar and StarSlash tokens must be of length 1 or 2: '" + paramString1 + "' '" + paramString2 + "'"); 
    this.slashStar = paramString1.toCharArray();
    this.starSlash = paramString2.toCharArray();
    commentChar(this.slashStar[0]);
  }
  
  public void setSlashSlashToken(String paramString) {
    if (paramString.length() < 1 || paramString.length() > 2)
      throw new IllegalArgumentException("SlashSlash token must be of length 1 or 2: '" + paramString + "'"); 
    this.slashSlash = paramString.toCharArray();
    commentChar(this.slashSlash[0]);
  }
  
  public void pushBack() {
    if (this.ttype != -4)
      this.pushedBack = true; 
  }
  
  public int lineno() {
    return this.LINENO;
  }
  
  public int getStartPosition() {
    return this.startpos;
  }
  
  public void setStartPosition(int paramInt) {
    this.startpos = paramInt;
  }
  
  public int getEndPosition() {
    return this.endpos;
  }
  
  public String toString() {
    switch (this.ttype) {
      case -1:
        str = "EOF";
        return "Token[" + str + "], line " + this.LINENO;
      case 10:
        str = "EOL";
        return "Token[" + str + "], line " + this.LINENO;
      case -3:
        str = this.sval;
        return "Token[" + str + "], line " + this.LINENO;
      case -2:
        str = "n=" + this.nval;
        return "Token[" + str + "], line " + this.LINENO;
      case -4:
        str = "NOTHING";
        return "Token[" + str + "], line " + this.LINENO;
    } 
    char[] arrayOfChar = new char[3];
    arrayOfChar[2] = '\'';
    arrayOfChar[0] = '\'';
    arrayOfChar[1] = (char)this.ttype;
    String str = new String(arrayOfChar);
    return "Token[" + str + "], line " + this.LINENO;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\io\StreamPosTokenizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */