package ch.randelshofer.io;

import java.io.IOException;

public class ParseException extends IOException {
  private int startpos;
  
  private int endpos;
  
  public ParseException(String paramString, int paramInt1, int paramInt2) {
    super(paramString);
    this.startpos = paramInt1;
    this.endpos = paramInt2;
  }
  
  public int getStartPosition() {
    return this.startpos;
  }
  
  public int getEndPosition() {
    return this.endpos;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\io\ParseException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */