package ch.randelshofer.geom3d;

import ch.randelshofer.beans.AbstractStateModel;
import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;

public class RotatedTransform3DModel extends AbstractStateModel implements Transform3DModel, ChangeListener {
  private Transform3D rotator;
  
  private Transform3DModel model;
  
  public RotatedTransform3DModel(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.rotator = new Transform3D(paramDouble1, paramDouble2, paramDouble3);
    this.model = new DefaultTransform3DModel();
    this.model.addChangeListener(this);
  }
  
  public RotatedTransform3DModel(double paramDouble1, double paramDouble2, double paramDouble3, Transform3DModel paramTransform3DModel) {
    this.rotator = new Transform3D(paramDouble1, paramDouble2, paramDouble3);
    this.model = paramTransform3DModel;
    this.model.addChangeListener(this);
  }
  
  public void setModel(Transform3DModel paramTransform3DModel) {
    this.model.removeChangeListener(this);
    this.model = paramTransform3DModel;
    this.model.addChangeListener(this);
  }
  
  public void concatenate(Transform3D paramTransform3D) {
    this.model.concatenate(paramTransform3D);
  }
  
  public Transform3D getTransform() {
    Transform3D transform3D = this.model.getTransform();
    transform3D.concatenate(this.rotator);
    return transform3D;
  }
  
  public Transform3D getTransform(Transform3D paramTransform3D) {
    this.model.getTransform(paramTransform3D);
    paramTransform3D.concatenate(this.rotator);
    return paramTransform3D;
  }
  
  public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
    Transform3D transform3D = getTransform();
    transform3D.rotate(paramDouble1, paramDouble2, paramDouble3);
    transform3D.concatenate(this.rotator);
    this.model.setTransform(transform3D);
  }
  
  public void rotateX(double paramDouble) {
    Transform3D transform3D = getTransform();
    transform3D.rotateX(paramDouble);
    transform3D.concatenate(this.rotator);
    this.model.setTransform(transform3D);
  }
  
  public void rotateY(double paramDouble) {
    Transform3D transform3D = getTransform();
    transform3D.rotateY(paramDouble);
    transform3D.concatenate(this.rotator);
    this.model.setTransform(transform3D);
  }
  
  public void rotateZ(double paramDouble) {
    Transform3D transform3D = getTransform();
    transform3D.rotateZ(paramDouble);
    transform3D.concatenate(this.rotator);
    this.model.setTransform(transform3D);
  }
  
  public void scale(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.model.scale(paramDouble1, paramDouble2, paramDouble3);
  }
  
  public void setToIdentity() {
    this.model.setToIdentity();
  }
  
  public void setTransform(Transform3D paramTransform3D) {
    this.model.setTransform(paramTransform3D);
  }
  
  public void translate(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.model.translate(paramDouble1, paramDouble2, paramDouble3);
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent) {
    fireStateChanged();
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\RotatedTransform3DModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */