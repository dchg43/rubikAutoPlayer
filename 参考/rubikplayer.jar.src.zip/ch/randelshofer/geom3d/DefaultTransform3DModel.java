package ch.randelshofer.geom3d;

import ch.randelshofer.beans.AbstractStateModel;

public class DefaultTransform3DModel extends AbstractStateModel implements Transform3DModel {
  private Transform3D transform = new Transform3D();
  
  public DefaultTransform3DModel() {}
  
  public DefaultTransform3DModel(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {}
  
  public DefaultTransform3DModel(double[][] paramArrayOfdouble) {}
  
  public void setToIdentity() {
    this.transform.setToIdentity();
    fireStateChanged();
  }
  
  public void rotateX(double paramDouble) {
    this.transform.rotateX(paramDouble);
    fireStateChanged();
  }
  
  public void rotateY(double paramDouble) {
    this.transform.rotateY(paramDouble);
    fireStateChanged();
  }
  
  public void rotateZ(double paramDouble) {
    this.transform.rotateZ(paramDouble);
    fireStateChanged();
  }
  
  public void scale(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.transform.scale(paramDouble1, paramDouble2, paramDouble3);
    fireStateChanged();
  }
  
  public void translate(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.transform.translate(paramDouble1, paramDouble2, paramDouble3);
    fireStateChanged();
  }
  
  public void concatenate(Transform3D paramTransform3D) {
    this.transform.concatenate(paramTransform3D);
    fireStateChanged();
  }
  
  public void setTransform(Transform3D paramTransform3D) {
    this.transform.setTransform(paramTransform3D);
    fireStateChanged();
  }
  
  public Transform3D getTransform() {
    return (Transform3D)this.transform.clone();
  }
  
  public Transform3D getTransform(Transform3D paramTransform3D) {
    paramTransform3D.setTransform(this.transform);
    return paramTransform3D;
  }
  
  public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.transform.rotate(paramDouble1, paramDouble2, paramDouble3);
    fireStateChanged();
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\DefaultTransform3DModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */