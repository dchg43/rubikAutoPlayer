package ch.randelshofer.geom3d;

import java.util.Vector;

public interface SceneNode {
  void addVisibleFaces(Vector paramVector, Transform3D paramTransform3D, Point3D paramPoint3D);
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\SceneNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */