package ch.randelshofer.geom3d;

public class Point3D {
  public double x;
  
  public double y;
  
  public double z;
  
  public Point3D() {}
  
  public Point3D(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.x = paramDouble1;
    this.y = paramDouble2;
    this.z = paramDouble3;
  }
  
  public String toString() {
    return "Point3D[" + this.x + ", " + this.y + ", " + this.z + "]";
  }
  
  public double getX() {
    return this.x;
  }
  
  public double getY() {
    return this.y;
  }
  
  public double getZ() {
    return this.z;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\Point3D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */