package ch.randelshofer.geom3d;

import ch.randelshofer.util.Comparable;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

public class Face3D implements Comparable {
  private float[] coords;
  
  private int[] vertices;
  
  private double zAvg;
  
  private Color[] colors;
  
  private ActionListener action;
  
  private Point3D normal;
  
  public Face3D(float[] paramArrayOffloat, int[] paramArrayOfint, Color[] paramArrayOfColor) {
    this.coords = paramArrayOffloat;
    this.vertices = paramArrayOfint;
    this.colors = paramArrayOfColor;
    updateValues();
  }
  
  private void updateValues() {
    this.zAvg = 0.0D;
    int i;
    for (i = 0; i < this.vertices.length; i++)
      this.zAvg += this.coords[this.vertices[i] * 3 + 2]; 
    this.zAvg /= this.vertices.length;
    i = this.vertices[0] * 3;
    int j = this.vertices[1] * 3;
    int k = this.vertices[2] * 3;
    double d1 = (this.coords[j] - this.coords[i]);
    double d2 = (this.coords[j + 1] - this.coords[i + 1]);
    double d3 = (this.coords[j + 2] - this.coords[i + 2]);
    double d4 = (this.coords[k] - this.coords[i]);
    double d5 = (this.coords[k + 1] - this.coords[i + 1]);
    double d6 = (this.coords[k + 2] - this.coords[i + 2]);
    this.normal = new Point3D(d2 * d6 - d3 * d5, d3 * d4 - d1 * d6, d1 * d5 - d2 * d4);
  }
  
  public Color getBorderColor() {
    return this.colors[1];
  }
  
  public Color getFillColor() {
    return this.colors[0];
  }
  
  public void setAction(ActionListener paramActionListener) {
    this.action = paramActionListener;
  }
  
  public boolean handleEvent(MouseEvent paramMouseEvent) {
    if (this.action != null) {
      ActionEvent actionEvent = new ActionEvent(paramMouseEvent, 1001, null, paramMouseEvent.getModifiers());
      this.action.actionPerformed(actionEvent);
    } 
    return true;
  }
  
  public ActionListener getAction() {
    return this.action;
  }
  
  public boolean isVisible(Point3D paramPoint3D) {
    double d1 = this.coords[this.vertices[0] * 3] - paramPoint3D.x;
    double d2 = this.coords[this.vertices[0] * 3 + 1] - paramPoint3D.y;
    double d3 = this.coords[this.vertices[0] * 3 + 2] - paramPoint3D.z;
    double d4 = d1 * this.normal.x + d2 * this.normal.y + d3 * this.normal.z;
    return (d4 > 0.0D);
  }
  
  public int[] getVertices() {
    return this.vertices;
  }
  
  public float[] getCoords() {
    return this.coords;
  }
  
  public void setCoords(float[] paramArrayOffloat) {
    this.coords = paramArrayOffloat;
    updateValues();
  }
  
  public double getBrightness(Point3D paramPoint3D, double paramDouble1, double paramDouble2) {
    getNormal();
    double d1 = paramPoint3D.x - this.normal.x;
    double d2 = paramPoint3D.y - this.normal.y;
    double d3 = paramPoint3D.z - this.normal.z;
    double d4 = (this.normal.x * d1 + this.normal.y * d2 + this.normal.z * d3) / Math.sqrt((this.normal.x * this.normal.x + this.normal.y * this.normal.y + this.normal.z * this.normal.z) * (d1 * d1 + d2 * d2 + d3 * d3));
    return (d4 < 0.0D) ? (paramDouble2 - d4 * paramDouble1) : paramDouble2;
  }
  
  public int compareTo(Object paramObject) {
    Face3D face3D = (Face3D)paramObject;
    double d = this.zAvg - face3D.zAvg;
    return (d > 0.0D) ? 1 : ((d < 0.0D) ? -1 : 0);
  }
  
  private Point3D getNormal() {
    return this.normal;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\Face3D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */