package ch.randelshofer.geom3d;

public class Transform3D implements Cloneable {
  public double m00 = 1.0D;
  
  public double m10;
  
  public double m20;
  
  public double m30;
  
  public double m01;
  
  public double m11 = 1.0D;
  
  public double m21;
  
  public double m31;
  
  public double m02;
  
  public double m12;
  
  public double m22 = 1.0D;
  
  public double m32;
  
  public Transform3D() {}
  
  public Transform3D(double paramDouble1, double paramDouble2, double paramDouble3) {
    rotate(paramDouble1, paramDouble2, paramDouble3);
  }
  
  public Transform3D(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
    this.m00 = paramDouble1;
    this.m10 = paramDouble2;
    this.m20 = paramDouble3;
    this.m30 = paramDouble4;
    this.m01 = paramDouble5;
    this.m11 = paramDouble6;
    this.m21 = paramDouble7;
    this.m31 = paramDouble8;
    this.m02 = paramDouble9;
    this.m12 = paramDouble10;
    this.m22 = paramDouble11;
    this.m32 = paramDouble12;
  }
  
  public Transform3D(double[][] paramArrayOfdouble) {
    this.m00 = paramArrayOfdouble[0][0];
    this.m10 = paramArrayOfdouble[1][0];
    this.m20 = paramArrayOfdouble[2][0];
    this.m30 = paramArrayOfdouble[3][0];
    this.m01 = paramArrayOfdouble[0][1];
    this.m11 = paramArrayOfdouble[1][1];
    this.m21 = paramArrayOfdouble[2][1];
    this.m31 = paramArrayOfdouble[3][1];
    this.m02 = paramArrayOfdouble[0][2];
    this.m12 = paramArrayOfdouble[1][2];
    this.m22 = paramArrayOfdouble[2][2];
    this.m32 = paramArrayOfdouble[3][2];
  }
  
  public void setToIdentity() {
    this.m00 = 1.0D;
    this.m10 = 0.0D;
    this.m20 = 0.0D;
    this.m30 = 0.0D;
    this.m01 = 0.0D;
    this.m11 = 1.0D;
    this.m21 = 0.0D;
    this.m31 = 0.0D;
    this.m02 = 0.0D;
    this.m12 = 0.0D;
    this.m22 = 1.0D;
    this.m32 = 0.0D;
  }
  
  public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
    rotateX(paramDouble1);
    rotateY(paramDouble2);
    rotateZ(paramDouble3);
  }
  
  public void rotateX(double paramDouble) {
    double d1 = Math.sin(paramDouble);
    double d2 = Math.cos(paramDouble);
    Transform3D transform3D = new Transform3D(1.0D, 0.0D, 0.0D, 0.0D, 0.0D, d2, d1, 0.0D, 0.0D, -d1, d2, 0.0D);
    concatenate(transform3D);
  }
  
  public void rotateY(double paramDouble) {
    double d1 = Math.sin(paramDouble);
    double d2 = Math.cos(paramDouble);
    Transform3D transform3D = new Transform3D(d2, 0.0D, -d1, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, d1, 0.0D, d2, 0.0D);
    concatenate(transform3D);
  }
  
  public void rotateZ(double paramDouble) {
    double d1 = Math.sin(paramDouble);
    double d2 = Math.cos(paramDouble);
    Transform3D transform3D = new Transform3D(d2, d1, 0.0D, 0.0D, -d1, d2, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D);
    concatenate(transform3D);
  }
  
  public void scale(double paramDouble1, double paramDouble2, double paramDouble3) {
    Transform3D transform3D = new Transform3D(paramDouble1, 0.0D, 0.0D, 0.0D, 0.0D, paramDouble2, 0.0D, 0.0D, 0.0D, 0.0D, paramDouble3, 0.0D);
    concatenate(transform3D);
  }
  
  public void translate(double paramDouble1, double paramDouble2, double paramDouble3) {
    Transform3D transform3D = new Transform3D(1.0D, 0.0D, 0.0D, paramDouble1, 0.0D, 1.0D, 0.0D, paramDouble2, 0.0D, 0.0D, 1.0D, paramDouble3);
    concatenate(transform3D);
  }
  
  public void concatenate(Transform3D paramTransform3D) {
    double d1 = this.m00;
    double d2 = this.m10;
    double d3 = this.m20;
    double d4 = this.m30;
    double d5 = this.m01;
    double d6 = this.m11;
    double d7 = this.m21;
    double d8 = this.m31;
    double d9 = this.m02;
    double d10 = this.m12;
    double d11 = this.m22;
    double d12 = this.m32;
    this.m00 = d1 * paramTransform3D.m00 + d5 * paramTransform3D.m10 + d9 * paramTransform3D.m20;
    this.m01 = d1 * paramTransform3D.m01 + d5 * paramTransform3D.m11 + d9 * paramTransform3D.m21;
    this.m02 = d1 * paramTransform3D.m02 + d5 * paramTransform3D.m12 + d9 * paramTransform3D.m22;
    this.m10 = d2 * paramTransform3D.m00 + d6 * paramTransform3D.m10 + d10 * paramTransform3D.m20;
    this.m11 = d2 * paramTransform3D.m01 + d6 * paramTransform3D.m11 + d10 * paramTransform3D.m21;
    this.m12 = d2 * paramTransform3D.m02 + d6 * paramTransform3D.m12 + d10 * paramTransform3D.m22;
    this.m20 = d3 * paramTransform3D.m00 + d7 * paramTransform3D.m10 + d11 * paramTransform3D.m20;
    this.m21 = d3 * paramTransform3D.m01 + d7 * paramTransform3D.m11 + d11 * paramTransform3D.m21;
    this.m22 = d3 * paramTransform3D.m02 + d7 * paramTransform3D.m12 + d11 * paramTransform3D.m22;
    this.m30 = d4 * paramTransform3D.m00 + d8 * paramTransform3D.m10 + d12 * paramTransform3D.m20 + paramTransform3D.m30;
    this.m31 = d4 * paramTransform3D.m01 + d8 * paramTransform3D.m11 + d12 * paramTransform3D.m21 + paramTransform3D.m31;
    this.m32 = d4 * paramTransform3D.m02 + d8 * paramTransform3D.m12 + d12 * paramTransform3D.m22 + paramTransform3D.m32;
  }
  
  public double[][] getMatrix() {
    return new double[][] { { this.m00, this.m10, this.m20, this.m30 }, { this.m01, this.m11, this.m21, this.m31 }, { this.m02, this.m12, this.m22, this.m32 }, { 0.0D, 0.0D, 0.0D, 1.0D } };
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof Transform3D))
      return false; 
    Transform3D transform3D = (Transform3D)paramObject;
    return (this.m00 == transform3D.m00 && this.m10 == transform3D.m10 && this.m20 == transform3D.m20 && this.m30 == transform3D.m30 && this.m01 == transform3D.m01 && this.m11 == transform3D.m11 && this.m21 == transform3D.m21 && this.m31 == transform3D.m31 && this.m02 == transform3D.m02 && this.m12 == transform3D.m12 && this.m22 == transform3D.m22 && this.m32 == transform3D.m32);
  }
  
  public void transform(Point3D paramPoint3D) {
    transform(paramPoint3D, paramPoint3D);
  }
  
  public Point3D transform(Point3D paramPoint3D1, Point3D paramPoint3D2) {
    double d1 = paramPoint3D1.x * this.m00 + paramPoint3D1.y * this.m10 + paramPoint3D1.z * this.m20 + this.m30;
    double d2 = paramPoint3D1.x * this.m01 + paramPoint3D1.y * this.m11 + paramPoint3D1.z * this.m21 + this.m31;
    double d3 = paramPoint3D1.x * this.m02 + paramPoint3D1.y * this.m12 + paramPoint3D1.z * this.m22 + this.m32;
    if (paramPoint3D2 == null)
      return new Point3D(d1, d2, d3); 
    paramPoint3D2.x = d1;
    paramPoint3D2.y = d2;
    paramPoint3D2.z = d3;
    return paramPoint3D2;
  }
  
  public Polygon3D transform(Polygon3D paramPolygon3D1, Polygon3D paramPolygon3D2) {
    if (paramPolygon3D2 == null)
      paramPolygon3D2 = new Polygon3D(paramPolygon3D1.npoints); 
    if (paramPolygon3D2.xpoints.length < paramPolygon3D1.npoints)
      paramPolygon3D2.setCapacity(paramPolygon3D1.npoints); 
    int i = paramPolygon3D1.npoints - 1;
    while (--i >= 0) {
      paramPolygon3D2.xpoints[i] = paramPolygon3D1.xpoints[i] * this.m00 + paramPolygon3D1.ypoints[i] * this.m10 + paramPolygon3D1.zpoints[i] * this.m20 + this.m30;
      paramPolygon3D2.ypoints[i] = paramPolygon3D1.xpoints[i] * this.m01 + paramPolygon3D1.ypoints[i] * this.m11 + paramPolygon3D1.zpoints[i] * this.m21 + this.m31;
      paramPolygon3D2.ypoints[i] = paramPolygon3D1.xpoints[i] * this.m02 + paramPolygon3D1.ypoints[i] * this.m12 + paramPolygon3D1.zpoints[i] * this.m22 + this.m32;
    } 
    return paramPolygon3D2;
  }
  
  public void transform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
    int k = paramInt1 + paramInt3 * 3;
    int j = paramInt2 * 3;
    int i = paramInt1;
    while (i < k) {
      paramArrayOffloat2[j] = (float)(paramArrayOffloat1[i] * this.m00 + paramArrayOffloat1[i + 1] * this.m10 + paramArrayOffloat1[i + 2] * this.m20 + this.m30);
      paramArrayOffloat2[j + 1] = (float)(paramArrayOffloat1[i] * this.m01 + paramArrayOffloat1[i + 1] * this.m11 + paramArrayOffloat1[i + 2] * this.m21 + this.m31);
      paramArrayOffloat2[j + 2] = (float)(paramArrayOffloat1[i] * this.m02 + paramArrayOffloat1[i + 1] * this.m12 + paramArrayOffloat1[i + 2] * this.m22 + this.m32);
      i += 3;
      j += 3;
    } 
  }
  
  public Object clone() {
    try {
      return super.clone();
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new InternalError();
    } 
  }
  
  public String toString() {
    return "{" + this.m00 + "," + this.m10 + "," + this.m20 + "," + this.m30 + "\n" + this.m01 + "," + this.m11 + "," + this.m21 + "," + this.m31 + "\n" + this.m02 + "," + this.m12 + "," + this.m22 + "," + this.m32 + "}";
  }
  
  public boolean isNaN() {
    return (Double.isNaN(this.m00) || Double.isNaN(this.m10) || Double.isNaN(this.m20) || Double.isNaN(this.m30) || Double.isNaN(this.m01) || Double.isNaN(this.m11) || Double.isNaN(this.m21) || Double.isNaN(this.m31) || Double.isNaN(this.m02) || Double.isNaN(this.m12) || Double.isNaN(this.m22) || Double.isNaN(this.m32));
  }
  
  public void setTransform(Transform3D paramTransform3D) {
    this.m00 = paramTransform3D.m00;
    this.m10 = paramTransform3D.m10;
    this.m20 = paramTransform3D.m20;
    this.m30 = paramTransform3D.m30;
    this.m01 = paramTransform3D.m01;
    this.m11 = paramTransform3D.m11;
    this.m21 = paramTransform3D.m21;
    this.m31 = paramTransform3D.m31;
    this.m02 = paramTransform3D.m02;
    this.m12 = paramTransform3D.m12;
    this.m22 = paramTransform3D.m22;
    this.m32 = paramTransform3D.m32;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\Transform3D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */