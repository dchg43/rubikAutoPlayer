package ch.randelshofer.geom3d;

import ch.randelshofer.gui.event.ChangeListener;

public interface Transform3DModel {
  void setToIdentity();
  
  void rotate(double paramDouble1, double paramDouble2, double paramDouble3);
  
  void rotateX(double paramDouble);
  
  void rotateY(double paramDouble);
  
  void rotateZ(double paramDouble);
  
  void scale(double paramDouble1, double paramDouble2, double paramDouble3);
  
  void translate(double paramDouble1, double paramDouble2, double paramDouble3);
  
  void concatenate(Transform3D paramTransform3D);
  
  Transform3D getTransform();
  
  Transform3D getTransform(Transform3D paramTransform3D);
  
  void setTransform(Transform3D paramTransform3D);
  
  void addChangeListener(ChangeListener paramChangeListener);
  
  void removeChangeListener(ChangeListener paramChangeListener);
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\Transform3DModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */