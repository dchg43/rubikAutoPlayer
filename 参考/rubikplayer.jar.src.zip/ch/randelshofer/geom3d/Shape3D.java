package ch.randelshofer.geom3d;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.Vector;

public class Shape3D implements SceneNode {
  private float[] coords;
  
  private int[][] faces;
  
  private Color[][] colors;
  
  private boolean isVisible = true;
  
  private boolean isWireframe = false;
  
  private boolean isReduced = false;
  
  private int reducedFaceCount;
  
  private Face3D[] faces3D;
  
  private ActionListener[] faceActions;
  
  private Transform3D transform = new Transform3D();
  
  public Shape3D(float[] paramArrayOffloat, int[][] paramArrayOfint, Color[][] paramArrayOfColor) {
    this(paramArrayOffloat, paramArrayOfint, paramArrayOfColor, paramArrayOfint.length);
  }
  
  public Shape3D(float[] paramArrayOffloat, int[][] paramArrayOfint, Color[][] paramArrayOfColor, int paramInt) {
    this.coords = paramArrayOffloat;
    this.faces = paramArrayOfint;
    this.colors = paramArrayOfColor;
    this.reducedFaceCount = paramInt;
  }
  
  public float[] getCoords() {
    return this.coords;
  }
  
  public int[][] getFaces() {
    return this.faces;
  }
  
  public boolean isVisible() {
    return this.isVisible;
  }
  
  public void setVisible(boolean paramBoolean) {
    this.isVisible = paramBoolean;
  }
  
  public boolean isRecuced() {
    return this.isReduced;
  }
  
  public void setReduced(boolean paramBoolean) {
    this.isReduced = paramBoolean;
  }
  
  public void setTransform(Transform3D paramTransform3D) {
    this.transform = paramTransform3D;
  }
  
  private void createFaces() {
    if (this.faces3D == null) {
      this.faces3D = new Face3D[this.faces.length];
      for (byte b = 0; b < this.faces.length; b++) {
        (new Color[2])[0] = null;
        (new Color[2])[1] = this.colors[b][1];
        this.faces3D[b] = new Face3D(this.coords, this.faces[b], this.isWireframe ? new Color[2] : this.colors[b]);
        if (this.faceActions != null)
          this.faces3D[b].setAction(this.faceActions[b]); 
      } 
    } 
  }
  
  public void addVisibleFaces(Vector paramVector, Transform3D paramTransform3D, Point3D paramPoint3D) {
    if (this.isVisible) {
      Transform3D transform3D = (Transform3D)this.transform.clone();
      transform3D.concatenate(paramTransform3D);
      float[] arrayOfFloat = new float[this.coords.length];
      transform3D.transform(this.coords, 0, arrayOfFloat, 0, this.coords.length / 3);
      createFaces();
      byte b = 0;
      int i = this.isReduced ? this.reducedFaceCount : this.faces.length;
      while (b < i) {
        this.faces3D[b].setCoords(arrayOfFloat);
        if (this.faces3D[b].isVisible(paramPoint3D))
          paramVector.addElement(this.faces3D[b]); 
        b++;
      } 
    } 
  }
  
  public void setAction(int paramInt, ActionListener paramActionListener) {
    this.faces3D = null;
    if (this.faceActions == null)
      this.faceActions = new ActionListener[this.faces.length]; 
    this.faceActions[paramInt] = paramActionListener;
  }
  
  public void setBackgroundColor(int paramInt, Color paramColor) {
    this.colors[paramInt][0] = paramColor;
  }
  
  public void setBorderColor(int paramInt, Color paramColor) {
    this.colors[paramInt][1] = paramColor;
  }
  
  public int getFaceCount() {
    return this.faces.length;
  }
  
  public boolean isWireframe() {
    return this.isWireframe;
  }
  
  public void setWireframe(boolean paramBoolean) {
    this.isWireframe = paramBoolean;
    this.faces3D = null;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\Shape3D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */