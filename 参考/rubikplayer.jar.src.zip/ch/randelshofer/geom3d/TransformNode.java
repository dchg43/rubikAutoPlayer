package ch.randelshofer.geom3d;

import java.util.Enumeration;
import java.util.Vector;

public class TransformNode implements SceneNode {
  private Vector children = new Vector();
  
  private Transform3D transform = new Transform3D();
  
  private boolean isVisible = true;
  
  public void addChild(SceneNode paramSceneNode) {
    this.children.addElement(paramSceneNode);
  }
  
  public SceneNode getChild(int paramInt) {
    return this.children.elementAt(paramInt);
  }
  
  public void setTransform(Transform3D paramTransform3D) {
    this.transform = paramTransform3D;
  }
  
  public Transform3D getTransform() {
    return this.transform;
  }
  
  public void setVisible(boolean paramBoolean) {
    this.isVisible = paramBoolean;
  }
  
  public void addVisibleFaces(Vector paramVector, Transform3D paramTransform3D, Point3D paramPoint3D) {
    if (this.isVisible) {
      Transform3D transform3D = (Transform3D)this.transform.clone();
      transform3D.concatenate(paramTransform3D);
      Enumeration enumeration = this.children.elements();
      while (enumeration.hasMoreElements()) {
        SceneNode sceneNode = enumeration.nextElement();
        sceneNode.addVisibleFaces(paramVector, transform3D, paramPoint3D);
      } 
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\TransformNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */