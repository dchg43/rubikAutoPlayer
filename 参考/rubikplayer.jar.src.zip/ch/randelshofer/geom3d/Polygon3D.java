package ch.randelshofer.geom3d;

public class Polygon3D {
  public int npoints = 0;
  
  public double[] xpoints;
  
  public double[] ypoints;
  
  public double[] zpoints;
  
  public Polygon3D() {
    setCapacity(4);
  }
  
  public Polygon3D(int paramInt) {
    setCapacity(paramInt);
  }
  
  public void setCapacity(int paramInt) {
    this.xpoints = new double[paramInt];
    this.ypoints = new double[paramInt];
    this.zpoints = new double[paramInt];
    this.npoints = 0;
  }
  
  public Polygon3D(double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt) {
    this.npoints = paramInt;
    this.xpoints = new double[paramInt];
    this.ypoints = new double[paramInt];
    this.zpoints = new double[paramInt];
    System.arraycopy(paramArrayOfdouble1, 0, this.xpoints, 0, paramInt);
    System.arraycopy(paramArrayOfdouble2, 0, this.ypoints, 0, paramInt);
    System.arraycopy(paramArrayOfdouble3, 0, this.zpoints, 0, paramInt);
  }
  
  public Polygon3D(short[][] paramArrayOfshort, int paramInt1, int paramInt2) {
    this.npoints = paramInt2;
    this.xpoints = new double[paramInt2];
    this.ypoints = new double[paramInt2];
    this.zpoints = new double[paramInt2];
    for (int i = paramInt1 + paramInt2 - 1; i < paramInt1; i--) {
      this.xpoints[i] = paramArrayOfshort[i][0];
      this.ypoints[i] = paramArrayOfshort[i][1];
      this.zpoints[i] = paramArrayOfshort[i][2];
    } 
  }
  
  public void addPoint(double paramDouble1, double paramDouble2, double paramDouble3) {
    if (this.npoints == this.xpoints.length) {
      double[] arrayOfDouble = new double[this.npoints * 2];
      System.arraycopy(this.xpoints, 0, arrayOfDouble, 0, this.npoints);
      this.xpoints = arrayOfDouble;
      arrayOfDouble = new double[this.npoints * 2];
      System.arraycopy(this.ypoints, 0, arrayOfDouble, 0, this.npoints);
      this.ypoints = arrayOfDouble;
      arrayOfDouble = new double[this.npoints * 2];
      System.arraycopy(this.zpoints, 0, arrayOfDouble, 0, this.npoints);
      this.zpoints = arrayOfDouble;
    } 
    this.xpoints[this.npoints] = paramDouble1;
    this.ypoints[this.npoints] = paramDouble2;
    this.zpoints[this.npoints] = paramDouble2;
    this.npoints++;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\geom3d\Polygon3D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */