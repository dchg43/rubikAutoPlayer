package ch.randelshofer.rubik;

import ch.randelshofer.geom3d.Shape3D;
import java.awt.Color;

public class MiniCube3DAWT extends AbstractCube3DAWT {
  public static final Color[] STICKER_COLORS = new Color[] { new Color(231, 16, 0), new Color(33, 33, 189), new Color(247, 247, 247), new Color(255, 74, 0), new Color(49, 148, 0), new Color(247, 247, 0) };
  
  public void setStickerColor(int paramInt1, int paramInt2, Color paramColor) {
    switch (paramInt1) {
      case 0:
        switch (paramInt2) {
          case 0:
            this.cornerShapes[0].setBackgroundColor(1, paramColor);
            break;
          case 1:
            this.edgeShapes[0].setBackgroundColor(1, paramColor);
            break;
          case 2:
            this.cornerShapes[2].setBackgroundColor(2, paramColor);
            break;
          case 3:
            this.edgeShapes[1].setBackgroundColor(0, paramColor);
            break;
          case 4:
            this.sideShapes[0].setBackgroundColor(0, paramColor);
            break;
          case 5:
            this.edgeShapes[4].setBackgroundColor(0, paramColor);
            break;
          case 6:
            this.cornerShapes[1].setBackgroundColor(2, paramColor);
            break;
          case 7:
            this.edgeShapes[2].setBackgroundColor(1, paramColor);
            break;
          case 8:
            this.cornerShapes[3].setBackgroundColor(1, paramColor);
            break;
        } 
        break;
      case 1:
        switch (paramInt2) {
          case 0:
            this.cornerShapes[2].setBackgroundColor(1, paramColor);
            break;
          case 1:
            this.edgeShapes[3].setBackgroundColor(0, paramColor);
            break;
          case 2:
            this.cornerShapes[4].setBackgroundColor(2, paramColor);
            break;
          case 3:
            this.edgeShapes[4].setBackgroundColor(1, paramColor);
            break;
          case 4:
            this.sideShapes[1].setBackgroundColor(0, paramColor);
            break;
          case 5:
            this.edgeShapes[7].setBackgroundColor(1, paramColor);
            break;
          case 6:
            this.cornerShapes[3].setBackgroundColor(2, paramColor);
            break;
          case 7:
            this.edgeShapes[5].setBackgroundColor(0, paramColor);
            break;
          case 8:
            this.cornerShapes[5].setBackgroundColor(1, paramColor);
            break;
        } 
        break;
      case 2:
        switch (paramInt2) {
          case 0:
            this.cornerShapes[1].setBackgroundColor(0, paramColor);
            break;
          case 1:
            this.edgeShapes[2].setBackgroundColor(0, paramColor);
            break;
          case 2:
            this.cornerShapes[3].setBackgroundColor(0, paramColor);
            break;
          case 3:
            this.edgeShapes[11].setBackgroundColor(1, paramColor);
            break;
          case 4:
            this.sideShapes[2].setBackgroundColor(0, paramColor);
            break;
          case 5:
            this.edgeShapes[5].setBackgroundColor(1, paramColor);
            break;
          case 6:
            this.cornerShapes[7].setBackgroundColor(0, paramColor);
            break;
          case 7:
            this.edgeShapes[8].setBackgroundColor(0, paramColor);
            break;
          case 8:
            this.cornerShapes[5].setBackgroundColor(0, paramColor);
            break;
        } 
        break;
      case 3:
        switch (paramInt2) {
          case 0:
            this.cornerShapes[4].setBackgroundColor(1, paramColor);
            break;
          case 1:
            this.edgeShapes[6].setBackgroundColor(1, paramColor);
            break;
          case 2:
            this.cornerShapes[6].setBackgroundColor(2, paramColor);
            break;
          case 3:
            this.edgeShapes[7].setBackgroundColor(0, paramColor);
            break;
          case 4:
            this.sideShapes[3].setBackgroundColor(0, paramColor);
            break;
          case 5:
            this.edgeShapes[10].setBackgroundColor(0, paramColor);
            break;
          case 6:
            this.cornerShapes[5].setBackgroundColor(2, paramColor);
            break;
          case 7:
            this.edgeShapes[8].setBackgroundColor(1, paramColor);
            break;
          case 8:
            this.cornerShapes[7].setBackgroundColor(1, paramColor);
            break;
        } 
        break;
      case 4:
        switch (paramInt2) {
          case 0:
            this.cornerShapes[6].setBackgroundColor(1, paramColor);
            break;
          case 1:
            this.edgeShapes[9].setBackgroundColor(0, paramColor);
            break;
          case 2:
            this.cornerShapes[0].setBackgroundColor(2, paramColor);
            break;
          case 3:
            this.edgeShapes[10].setBackgroundColor(1, paramColor);
            break;
          case 4:
            this.sideShapes[4].setBackgroundColor(0, paramColor);
            break;
          case 5:
            this.edgeShapes[1].setBackgroundColor(1, paramColor);
            break;
          case 6:
            this.cornerShapes[7].setBackgroundColor(2, paramColor);
            break;
          case 7:
            this.edgeShapes[11].setBackgroundColor(0, paramColor);
            break;
          case 8:
            this.cornerShapes[1].setBackgroundColor(1, paramColor);
            break;
        } 
        break;
      case 5:
        switch (paramInt2) {
          case 0:
            this.cornerShapes[6].setBackgroundColor(0, paramColor);
            break;
          case 1:
            this.edgeShapes[6].setBackgroundColor(0, paramColor);
            break;
          case 2:
            this.cornerShapes[4].setBackgroundColor(0, paramColor);
            break;
          case 3:
            this.edgeShapes[9].setBackgroundColor(1, paramColor);
            break;
          case 4:
            this.sideShapes[5].setBackgroundColor(0, paramColor);
            break;
          case 5:
            this.edgeShapes[3].setBackgroundColor(1, paramColor);
            break;
          case 6:
            this.cornerShapes[0].setBackgroundColor(0, paramColor);
            break;
          case 7:
            this.edgeShapes[0].setBackgroundColor(0, paramColor);
            break;
          case 8:
            this.cornerShapes[2].setBackgroundColor(0, paramColor);
            break;
        } 
        break;
    } 
  }
  
  protected void initCorners() {
    float[] arrayOfFloat = { 
        -8.0F, 8.0F, 9.0F, -8.0F, -8.0F, 9.0F, 8.0F, 8.0F, 9.0F, 8.0F, 
        -8.0F, 9.0F, 8.0F, 8.0F, -9.0F, 8.0F, -8.0F, -9.0F, -8.0F, 8.0F, 
        -9.0F, -8.0F, -8.0F, -9.0F, -9.0F, 8.0F, 8.0F, -9.0F, -8.0F, 8.0F, 
        9.0F, 8.0F, 8.0F, 9.0F, -8.0F, 8.0F, 9.0F, 8.0F, -8.0F, 9.0F, 
        -8.0F, -8.0F, -9.0F, 8.0F, -8.0F, -9.0F, -8.0F, -8.0F, -8.0F, 9.0F, 
        8.0F, -8.0F, -9.0F, 8.0F, 8.0F, 9.0F, 8.0F, 8.0F, -9.0F, 8.0F, 
        8.0F, 9.0F, -8.0F, 8.0F, -9.0F, -8.0F, -8.0F, 9.0F, -8.0F, -8.0F, 
        -9.0F, -8.0F };
    int[][] arrayOfInt = { 
        { 16, 22, 20, 18 }, { 0, 2, 3, 1 }, { 14, 8, 9, 15 }, { 12, 13, 11, 10 }, { 17, 19, 21, 23 }, { 4, 6, 7, 5 }, { 17, 9, 1 }, { 19, 3, 11 }, { 23, 7, 15 }, { 16, 0, 8 }, 
        { 18, 10, 2 }, { 22, 14, 6 }, { 20, 4, 12 }, { 16, 18, 2, 0 }, { 18, 20, 12, 10 }, { 20, 22, 6, 4 }, { 22, 16, 8, 14 }, { 19, 17, 1, 3 }, { 21, 19, 11, 13 }, { 23, 21, 5, 7 }, 
        { 17, 23, 15, 9 }, { 3, 2, 10, 11 }, { 0, 1, 9, 8 }, { 4, 5, 13, 12 }, { 7, 6, 14, 15 } };
    Color[][][] arrayOfColor = new Color[8][arrayOfInt.length][0];
    Color[] arrayOfColor1 = { AbstractCube3DAWT.PART_FILL_COLOR, null };
    byte b;
    for (b = 0; b < 8; b++) {
      for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
        arrayOfColor[b][b1] = arrayOfColor1; 
    } 
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[0][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[0][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[0][2] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[1][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[1][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[1][2] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[2][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[2][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[2][2] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[3][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[3][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[3][2] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[4][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[4][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[4][2] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[5][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[5][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[5][2] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[6][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[6][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[6][2] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[7][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[7][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[7][2] = new Color[2];
    for (b = 0; b < 8; b++)
      this.cornerShapes[b] = new Shape3D(arrayOfFloat, arrayOfInt, arrayOfColor[b]); 
  }
  
  protected void initEdges() {
    float[] arrayOfFloat = { 
        -8.0F, 8.0F, 9.0F, -8.0F, -8.0F, 9.0F, 8.0F, 8.0F, 9.0F, 8.0F, 
        -8.0F, 9.0F, 8.0F, 8.0F, -9.0F, 8.0F, -8.0F, -9.0F, -8.0F, 8.0F, 
        -9.0F, -8.0F, -8.0F, -9.0F, -9.0F, 8.0F, 8.0F, -9.0F, -8.0F, 8.0F, 
        9.0F, 8.0F, 8.0F, 9.0F, -8.0F, 8.0F, 9.0F, 8.0F, -8.0F, 9.0F, 
        -8.0F, -8.0F, -9.0F, 8.0F, -8.0F, -9.0F, -8.0F, -8.0F, -8.0F, 9.0F, 
        8.0F, -8.0F, -9.0F, 8.0F, 8.0F, 9.0F, 8.0F, 8.0F, -9.0F, 8.0F, 
        8.0F, 9.0F, -8.0F, 8.0F, -9.0F, -8.0F, -8.0F, 9.0F, -8.0F, -8.0F, 
        -9.0F, -8.0F };
    int[][] arrayOfInt = { 
        { 0, 2, 3, 1 }, { 16, 22, 20, 18 }, { 14, 8, 9, 15 }, { 12, 13, 11, 10 }, { 17, 19, 21, 23 }, { 4, 6, 7, 5 }, { 17, 9, 1 }, { 19, 3, 11 }, { 16, 0, 8 }, { 18, 10, 2 }, 
        { 22, 14, 6 }, { 20, 4, 12 }, { 16, 18, 2, 0 }, { 18, 20, 12, 10 }, { 20, 22, 6, 4 }, { 22, 16, 8, 14 }, { 19, 17, 1, 3 }, { 21, 19, 11, 13 }, { 17, 23, 15, 9 }, { 3, 2, 10, 11 }, 
        { 0, 1, 9, 8 }, { 4, 5, 13, 12 }, { 7, 6, 14, 15 } };
    Color[][][] arrayOfColor = new Color[12][arrayOfInt.length][0];
    Color[] arrayOfColor1 = { AbstractCube3DAWT.PART_FILL_COLOR, null };
    byte b;
    for (b = 0; b < 12; b++) {
      for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
        arrayOfColor[b][b1] = arrayOfColor1; 
    } 
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[0][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[0][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[1][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[1][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[2][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[2][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[3][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[3][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[4][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[4][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[5][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[5][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[6][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[6][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[7][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[7][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[8][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[8][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[9][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[9][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[10][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[10][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[11][1] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[11][0] = new Color[2];
    for (b = 0; b < 12; b++)
      this.edgeShapes[b] = new Shape3D(arrayOfFloat, arrayOfInt, arrayOfColor[b]); 
  }
  
  protected void initSides() {
    float[] arrayOfFloat = { 
        -8.0F, 8.0F, 9.0F, -8.0F, -8.0F, 9.0F, 8.0F, 8.0F, 9.0F, 8.0F, 
        -8.0F, 9.0F, 8.0F, 8.0F, -9.0F, 8.0F, -8.0F, -9.0F, -8.0F, 8.0F, 
        -9.0F, -8.0F, -8.0F, -9.0F, -9.0F, 8.0F, 8.0F, -9.0F, -8.0F, 8.0F, 
        9.0F, 8.0F, 8.0F, 9.0F, -8.0F, 8.0F, 9.0F, 8.0F, -8.0F, 9.0F, 
        -8.0F, -8.0F, -9.0F, 8.0F, -8.0F, -9.0F, -8.0F, -8.0F, -8.0F, 9.0F, 
        8.0F, -8.0F, -9.0F, 8.0F, 8.0F, 9.0F, 8.0F, 8.0F, -9.0F, 8.0F, 
        8.0F, 9.0F, -8.0F, 8.0F, -9.0F, -8.0F, -8.0F, 9.0F, -8.0F, -8.0F, 
        -9.0F, -8.0F };
    int[][] arrayOfInt = { 
        { 0, 2, 3, 1 }, { 16, 22, 20, 18 }, { 14, 8, 9, 15 }, { 12, 13, 11, 10 }, { 17, 19, 21, 23 }, { 17, 9, 1 }, { 19, 3, 11 }, { 16, 0, 8 }, { 18, 10, 2 }, { 16, 18, 2, 0 }, 
        { 18, 20, 12, 10 }, { 22, 16, 8, 14 }, { 19, 17, 1, 3 }, { 21, 19, 11, 13 }, { 17, 23, 15, 9 }, { 3, 2, 10, 11 }, { 0, 1, 9, 8 } };
    Color[][][] arrayOfColor = new Color[6][arrayOfInt.length][0];
    Color[] arrayOfColor1 = { AbstractCube3DAWT.PART_FILL_COLOR, null };
    byte b;
    for (b = 0; b < 6; b++) {
      for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
        arrayOfColor[b][b1] = arrayOfColor1; 
    } 
    (new Color[2])[0] = STICKER_COLORS[0];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[0][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[1];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[1][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[2];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[2][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[3];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[3][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[4];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[4][0] = new Color[2];
    (new Color[2])[0] = STICKER_COLORS[5];
    (new Color[2])[1] = AbstractCube3DAWT.PART_BORDER_COLOR;
    arrayOfColor[5][0] = new Color[2];
    for (b = 0; b < 6; b++)
      this.sideShapes[b] = new Shape3D(arrayOfFloat, arrayOfInt, arrayOfColor[b]); 
  }
  
  protected void initCenter() {
    float[] arrayOfFloat = new float[0];
    int[][] arrayOfInt = new int[0][];
    Color[][] arrayOfColor = new Color[0][];
    this.centerShape = new Shape3D(arrayOfFloat, arrayOfInt, arrayOfColor);
    this.centerShape.setVisible(false);
  }
  
  protected void initActions() {
    byte b;
    for (b = 0; b < 8; b++) {
      for (byte b1 = 0; b1 < 3; b1++)
        this.cornerShapes[b].setAction(b1, new AbstractCube3DAWT.CrnrActn(this, b, b1)); 
    } 
    for (b = 0; b < 12; b++) {
      for (byte b1 = 0; b1 < 2; b1++)
        this.edgeShapes[b].setAction(b1, new AbstractCube3DAWT.EdgeAction(this, b, b1)); 
    } 
    for (b = 0; b < 6; b++)
      this.sideShapes[b].setAction(0, new AbstractCube3DAWT.SideAction(this, b)); 
  }
  
  public String getName() {
    return "Rubik's Cube (simplified 3D model)";
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\MiniCube3DAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */