package ch.randelshofer.rubik;

import java.util.EventListener;

public interface RubikListener extends EventListener {
  void rubikTwisting(RubikEvent paramRubikEvent);
  
  void rubikTwisted(RubikEvent paramRubikEvent);
  
  void rubikPartRotated(RubikEvent paramRubikEvent);
  
  void rubikChanged(RubikEvent paramRubikEvent);
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\RubikListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */