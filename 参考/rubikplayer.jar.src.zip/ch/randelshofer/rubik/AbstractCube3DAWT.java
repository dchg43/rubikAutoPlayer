package ch.randelshofer.rubik;

import ch.randelshofer.geom3d.SceneNode;
import ch.randelshofer.geom3d.Shape3D;
import ch.randelshofer.geom3d.Transform3D;
import ch.randelshofer.geom3d.TransformNode;
import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.gui.event.EventListenerList;
import ch.randelshofer.util.PooledSequentialDispatcherAWT;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.EventListener;
import java.util.Vector;

public abstract class AbstractCube3DAWT implements RubikListener {
  public static final Color PART_FILL_COLOR = new Color(20, 20, 20);
  
  public static final Color CENTER_FILL_COLOR = Color.white;
  
  public static final Color PART_BORDER_COLOR = Color.black;
  
  protected Shape3D[] cornerShapes = new Shape3D[8];
  
  protected Transform3D[] cornerIdentityTransforms = new Transform3D[8];
  
  protected Shape3D[] edgeShapes = new Shape3D[12];
  
  protected Transform3D[] edgeIdentityTransforms = new Transform3D[12];
  
  protected Shape3D[] sideShapes = new Shape3D[6];
  
  protected Transform3D[] sideIdentityTransforms = new Transform3D[6];
  
  protected Shape3D centerShape;
  
  protected TransformNode sceneTransform;
  
  protected TransformNode[] cornerTransforms = new TransformNode[8];
  
  protected TransformNode[] edgeTransforms = new TransformNode[12];
  
  protected TransformNode[] sideTransforms = new TransformNode[6];
  
  protected TransformNode centerTransform;
  
  RubiksCubeCore model = new RubiksCubeCore();
  
  EventListenerList listenerList = new EventListenerList();
  
  protected ChangeEvent changeEvent;
  
  protected boolean isAnimated;
  
  protected PooledSequentialDispatcherAWT dispatcher;
  
  private boolean isLazy;
  
  private double explosion = 0.0D;
  
  public static final double[][] CORNER_EXPLODE_TRANSLATION = new double[][] { { -1.0D, 1.0D, 1.0D }, { -1.0D, -1.0D, 1.0D }, { 1.0D, 1.0D, 1.0D }, { 1.0D, -1.0D, 1.0D }, { 1.0D, 1.0D, -1.0D }, { 1.0D, -1.0D, -1.0D }, { -1.0D, 1.0D, -1.0D }, { -1.0D, -1.0D, -1.0D } };
  
  public static final double[][] EDGE_EXPLODE_TRANSLATION = new double[][] { 
      { 0.0D, 1.0D, 1.0D }, { -1.0D, 0.0D, 1.0D }, { 0.0D, -1.0D, 1.0D }, { 1.0D, 1.0D, 0.0D }, { 1.0D, 0.0D, 1.0D }, { 1.0D, -1.0D, 0.0D }, { 0.0D, 1.0D, -1.0D }, { 1.0D, 0.0D, -1.0D }, { 0.0D, -1.0D, -1.0D }, { -1.0D, 1.0D, 0.0D }, 
      { -1.0D, 0.0D, -1.0D }, { -1.0D, -1.0D, 0.0D } };
  
  public static final double[][] SIDE_EXPLODE_TRANSLATION = new double[][] { { 0.0D, 0.0D, 1.0D }, { 1.0D, 0.0D, 0.0D }, { 0.0D, -1.0D, 0.0D }, { 0.0D, 0.0D, -1.0D }, { -1.0D, 0.0D, 0.0D }, { 0.0D, 1.0D, 0.0D } };
  
  public static final int TWIST_MODE = 0;
  
  public static final int PARTS_MODE = 1;
  
  protected int mode = 0;
  
  public AbstractCube3DAWT() {
    init();
  }
  
  private void computeTransformation() {
    synchronized (this.model) {
      byte b;
      for (b = 0; b < this.sideTransforms.length; b++) {
        int i = this.model.getSideLocation(b);
        Transform3D transform3D = (Transform3D)this.sideIdentityTransforms[i].clone();
        transform3D.translate(SIDE_EXPLODE_TRANSLATION[i][0] * this.explosion, SIDE_EXPLODE_TRANSLATION[i][1] * this.explosion, SIDE_EXPLODE_TRANSLATION[i][2] * this.explosion);
        this.sideTransforms[b].setTransform(transform3D);
      } 
      for (b = 0; b < this.edgeTransforms.length; b++) {
        int i = this.model.getEdgeLocation(b);
        Transform3D transform3D1 = this.edgeTransforms[b].getTransform();
        transform3D1.setToIdentity();
        if (this.model.getEdgeOrientation(b) == 1) {
          transform3D1.rotateZ(Math.PI);
          transform3D1.rotateX(1.5707963267948966D);
        } 
        Transform3D transform3D2 = (Transform3D)this.edgeIdentityTransforms[i].clone();
        transform3D2.translate(EDGE_EXPLODE_TRANSLATION[i][0] * this.explosion, EDGE_EXPLODE_TRANSLATION[i][1] * this.explosion, EDGE_EXPLODE_TRANSLATION[i][2] * this.explosion);
        transform3D1.concatenate(transform3D2);
      } 
      for (b = 0; b < this.cornerTransforms.length; b++) {
        int i = this.model.getCornerLocation(b);
        Transform3D transform3D1 = this.cornerTransforms[b].getTransform();
        transform3D1.setToIdentity();
        switch (this.model.getCornerOrientation(b)) {
          case 1:
            transform3D1.rotateZ(-1.5707963267948966D);
            transform3D1.rotateX(1.5707963267948966D);
            break;
          case 2:
            transform3D1.rotate(-1.5707963267948966D, 0.0D, 1.5707963267948966D);
            break;
        } 
        Transform3D transform3D2 = (Transform3D)this.cornerIdentityTransforms[i].clone();
        transform3D2.translate(CORNER_EXPLODE_TRANSLATION[i][0] * this.explosion, CORNER_EXPLODE_TRANSLATION[i][1] * this.explosion, CORNER_EXPLODE_TRANSLATION[i][2] * this.explosion);
        transform3D1.concatenate(transform3D2);
      } 
    } 
  }
  
  public SceneNode getScene() {
    return (SceneNode)this.sceneTransform;
  }
  
  public void update() {
    computeTransformation();
    fireStateChanged();
  }
  
  public void setModel(RubiksCubeCore paramRubiksCubeCore) {
    if (this.model != null)
      this.model.removeRubikListener(this); 
    this.model = paramRubiksCubeCore;
    if (this.model != null) {
      this.model.addRubikListener(this);
      update();
    } 
  }
  
  public RubiksCubeCore getModel() {
    return this.model;
  }
  
  public void setCornerVisible(int paramInt, boolean paramBoolean) {
    this.cornerShapes[paramInt].setVisible(paramBoolean);
    fireStateChanged();
  }
  
  public void setEdgeVisible(int paramInt, boolean paramBoolean) {
    this.edgeShapes[paramInt].setVisible(paramBoolean);
    fireStateChanged();
  }
  
  public void setSideVisible(int paramInt, boolean paramBoolean) {
    this.sideShapes[paramInt].setVisible(paramBoolean);
    fireStateChanged();
  }
  
  public void setCenterVisible(boolean paramBoolean) {
    this.centerShape.setVisible(paramBoolean);
    fireStateChanged();
  }
  
  public void setExplosion(double paramDouble) {
    this.explosion = 27.0D * paramDouble;
    computeTransformation();
    fireStateChanged();
  }
  
  public double getExplosion() {
    return this.explosion / 27.0D;
  }
  
  public abstract void setStickerColor(int paramInt1, int paramInt2, Color paramColor);
  
  protected void init() {
    initCorners();
    initEdges();
    initSides();
    initCenter();
    initTransforms();
    initActions();
    setModel(new RubiksCubeCore());
  }
  
  protected abstract void initCorners();
  
  protected abstract void initEdges();
  
  protected abstract void initSides();
  
  protected abstract void initCenter();
  
  protected void initTransforms() {
    this.sceneTransform = new TransformNode();
    this.cornerIdentityTransforms[0] = new Transform3D();
    this.cornerIdentityTransforms[0].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[1] = new Transform3D();
    this.cornerIdentityTransforms[1].rotateZ(-1.5707963267948966D);
    this.cornerIdentityTransforms[1].rotateX(1.5707963267948966D);
    this.cornerIdentityTransforms[1].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[1].rotateZ(-1.5707963267948966D);
    this.cornerIdentityTransforms[2] = new Transform3D();
    this.cornerIdentityTransforms[2].rotateZ(-1.5707963267948966D);
    this.cornerIdentityTransforms[2].rotateX(1.5707963267948966D);
    this.cornerIdentityTransforms[2].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[2].rotateZ(1.5707963267948966D);
    this.cornerIdentityTransforms[3] = new Transform3D();
    this.cornerIdentityTransforms[3].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[3].rotateZ(Math.PI);
    this.cornerIdentityTransforms[4] = new Transform3D();
    this.cornerIdentityTransforms[4].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[4].rotateY(Math.PI);
    this.cornerIdentityTransforms[5] = new Transform3D();
    this.cornerIdentityTransforms[5].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[5].rotate(Math.PI, 1.5707963267948966D, 0.0D);
    this.cornerIdentityTransforms[6] = new Transform3D();
    this.cornerIdentityTransforms[6].rotate(-1.5707963267948966D, 0.0D, 1.5707963267948966D);
    this.cornerIdentityTransforms[6].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[6].rotateX(1.5707963267948966D);
    this.cornerIdentityTransforms[7] = new Transform3D();
    this.cornerIdentityTransforms[7].translate(-18.0D, 18.0D, 18.0D);
    this.cornerIdentityTransforms[7].rotateX(Math.PI);
    this.edgeIdentityTransforms[0] = new Transform3D();
    this.edgeIdentityTransforms[0].rotateZ(Math.PI);
    this.edgeIdentityTransforms[0].rotateX(1.5707963267948966D);
    this.edgeIdentityTransforms[0].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[1] = new Transform3D();
    this.edgeIdentityTransforms[1].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[1].rotateZ(-1.5707963267948966D);
    this.edgeIdentityTransforms[2] = new Transform3D();
    this.edgeIdentityTransforms[2].rotateZ(Math.PI);
    this.edgeIdentityTransforms[2].rotateX(1.5707963267948966D);
    this.edgeIdentityTransforms[2].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[2].rotateZ(Math.PI);
    this.edgeIdentityTransforms[3] = new Transform3D();
    this.edgeIdentityTransforms[3].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[3].rotate(0.0D, -1.5707963267948966D, 0.0D);
    this.edgeIdentityTransforms[4] = new Transform3D();
    this.edgeIdentityTransforms[4].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[4].rotateZ(1.5707963267948966D);
    this.edgeIdentityTransforms[5] = new Transform3D();
    this.edgeIdentityTransforms[5].rotateZ(Math.PI);
    this.edgeIdentityTransforms[5].rotateX(1.5707963267948966D);
    this.edgeIdentityTransforms[5].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[5].rotate(0.0D, -1.5707963267948966D, 1.5707963267948966D);
    this.edgeIdentityTransforms[6] = new Transform3D();
    this.edgeIdentityTransforms[6].rotateZ(Math.PI);
    this.edgeIdentityTransforms[6].rotateX(1.5707963267948966D);
    this.edgeIdentityTransforms[6].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[6].rotate(0.0D, Math.PI, 0.0D);
    this.edgeIdentityTransforms[7] = new Transform3D();
    this.edgeIdentityTransforms[7].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[7].rotate(0.0D, Math.PI, 1.5707963267948966D);
    this.edgeIdentityTransforms[8] = new Transform3D();
    this.edgeIdentityTransforms[8].rotateZ(Math.PI);
    this.edgeIdentityTransforms[8].rotateX(1.5707963267948966D);
    this.edgeIdentityTransforms[8].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[8].rotate(Math.PI, 0.0D, 0.0D);
    this.edgeIdentityTransforms[9] = new Transform3D();
    this.edgeIdentityTransforms[9].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[9].rotate(0.0D, 1.5707963267948966D, 0.0D);
    this.edgeIdentityTransforms[10] = new Transform3D();
    this.edgeIdentityTransforms[10].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[10].rotate(0.0D, Math.PI, -1.5707963267948966D);
    this.edgeIdentityTransforms[11] = new Transform3D();
    this.edgeIdentityTransforms[11].translate(0.0D, 18.0D, 18.0D);
    this.edgeIdentityTransforms[11].rotate(0.0D, -1.5707963267948966D, Math.PI);
    this.sideIdentityTransforms[0] = new Transform3D();
    this.sideIdentityTransforms[0].translate(0.0D, 0.0D, 18.0D);
    this.sideIdentityTransforms[1] = new Transform3D();
    this.sideIdentityTransforms[1].translate(0.0D, 0.0D, 18.0D);
    this.sideIdentityTransforms[1].rotateY(-1.5707963267948966D);
    this.sideIdentityTransforms[2] = new Transform3D();
    this.sideIdentityTransforms[2].translate(0.0D, 0.0D, 18.0D);
    this.sideIdentityTransforms[2].rotateX(-1.5707963267948966D);
    this.sideIdentityTransforms[3] = new Transform3D();
    this.sideIdentityTransforms[3].translate(0.0D, 0.0D, 18.0D);
    this.sideIdentityTransforms[3].rotateY(Math.PI);
    this.sideIdentityTransforms[4] = new Transform3D();
    this.sideIdentityTransforms[4].translate(0.0D, 0.0D, 18.0D);
    this.sideIdentityTransforms[4].rotateY(1.5707963267948966D);
    this.sideIdentityTransforms[5] = new Transform3D();
    this.sideIdentityTransforms[5].translate(0.0D, 0.0D, 18.0D);
    this.sideIdentityTransforms[5].rotateX(1.5707963267948966D);
    byte b;
    for (b = 0; b < 8; b++) {
      this.cornerTransforms[b] = new TransformNode();
      this.cornerTransforms[b].addChild((SceneNode)this.cornerShapes[b]);
      this.sceneTransform.addChild((SceneNode)this.cornerTransforms[b]);
    } 
    for (b = 0; b < 12; b++) {
      this.edgeTransforms[b] = new TransformNode();
      this.edgeTransforms[b].addChild((SceneNode)this.edgeShapes[b]);
      this.sceneTransform.addChild((SceneNode)this.edgeTransforms[b]);
    } 
    for (b = 0; b < 6; b++) {
      this.sideTransforms[b] = new TransformNode();
      this.sideTransforms[b].addChild((SceneNode)this.sideShapes[b]);
      this.sceneTransform.addChild((SceneNode)this.sideTransforms[b]);
    } 
    this.centerTransform = new TransformNode();
    this.centerTransform.addChild((SceneNode)this.centerShape);
    this.sceneTransform.addChild((SceneNode)this.centerTransform);
  }
  
  protected abstract void initActions();
  
  public void rubikTwisted(RubikEvent paramRubikEvent) {
    update();
  }
  
  public void rubikTwisting(RubikEvent paramRubikEvent) {
    if (this.isAnimated)
      animateTwist(paramRubikEvent); 
  }
  
  protected void animateTwist(RubikEvent paramRubikEvent) {
    Vector vector = new Vector();
    Transform3D transform3D = new Transform3D();
    int i = paramRubikEvent.getLayerMask();
    double d = paramRubikEvent.getAngle();
    byte b1 = (d == 2.0D || d == -2.0D) ? 20 : 10;
    d = 1.5707963267948966D / b1 * d;
    switch (paramRubikEvent.getAxis()) {
      case 0:
        transform3D.rotateX(d);
        if ((i & 0x1) == 1) {
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(0)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(1)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(6)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(7)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(1)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(9)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(10)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(11)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(4)]);
        } 
        if ((i & 0x2) == 2) {
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(0)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(2)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(6)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(8)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(0)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(2)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(3)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(5)]);
          vector.addElement(this.centerTransform);
        } 
        if ((i & 0x4) == 4) {
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(2)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(3)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(4)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(5)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(3)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(4)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(5)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(7)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(1)]);
        } 
        break;
      case 1:
        transform3D.rotateY(d);
        if ((i & 0x1) == 1) {
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(1)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(3)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(5)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(7)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(2)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(5)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(8)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(11)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(2)]);
        } 
        if ((i & 0x2) == 2) {
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(1)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(4)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(7)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(10)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(0)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(1)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(3)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(4)]);
          vector.addElement(this.centerTransform);
        } 
        if ((i & 0x4) == 4) {
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(0)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(2)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(4)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(6)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(0)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(3)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(6)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(9)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(5)]);
        } 
        break;
      case 2:
        transform3D.rotateZ(d);
        if ((i & 0x1) == 1) {
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(4)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(5)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(6)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(7)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(6)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(7)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(8)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(10)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(3)]);
        } 
        if ((i & 0x2) == 2) {
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(3)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(5)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(9)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(11)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(1)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(2)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(4)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(5)]);
          vector.addElement(this.centerTransform);
        } 
        if ((i & 0x4) == 4) {
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(0)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(1)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(2)]);
          vector.addElement(this.cornerTransforms[this.model.getCornerAt(3)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(0)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(1)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(2)]);
          vector.addElement(this.edgeTransforms[this.model.getEdgeAt(4)]);
          vector.addElement(this.sideTransforms[this.model.getSideAt(0)]);
        } 
        break;
    } 
    try {
      Thread.sleep(50L);
    } catch (InterruptedException interruptedException) {}
    long l = System.currentTimeMillis();
    for (byte b2 = 1; b2 < b1; b2++) {
      synchronized (this.model) {
        Enumeration enumeration = vector.elements();
        while (enumeration.hasMoreElements())
          ((TransformNode)enumeration.nextElement()).getTransform().concatenate(transform3D); 
      } 
      fireStateChanged();
      l += 50L;
      long l1 = l - System.currentTimeMillis();
      if (l1 > 0L) {
        try {
          Thread.sleep(l1);
        } catch (InterruptedException interruptedException) {}
      } else {
        l -= l1;
        Thread.yield();
      } 
    } 
    computeTransformation();
    fireStateChanged();
  }
  
  public void rubikChanged(RubikEvent paramRubikEvent) {
    update();
  }
  
  public void rubikPartRotated(RubikEvent paramRubikEvent) {
    update();
  }
  
  public void addChangeListener(ChangeListener paramChangeListener) {
    this.listenerList.add(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public void removeChangeListener(ChangeListener paramChangeListener) {
    this.listenerList.remove(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public void setAnimated(boolean paramBoolean) {
    this.isAnimated = paramBoolean;
  }
  
  public boolean isAnimated() {
    return this.isAnimated;
  }
  
  protected void fireStateChanged() {
    Object[] arrayOfObject = this.listenerList.getListenerList();
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == ChangeListener.class) {
        if (this.changeEvent == null)
          this.changeEvent = new ChangeEvent(this); 
        ((ChangeListener)arrayOfObject[i + 1]).stateChanged(this.changeEvent);
      } 
    } 
  }
  
  public void setDispatcher(PooledSequentialDispatcherAWT paramPooledSequentialDispatcherAWT) {
    this.dispatcher = paramPooledSequentialDispatcherAWT;
  }
  
  public PooledSequentialDispatcherAWT getDispatcher() {
    if (this.dispatcher == null)
      this.dispatcher = new PooledSequentialDispatcherAWT(); 
    return this.dispatcher;
  }
  
  public void setMode(int paramInt) {
    Shape3D shape3D;
    byte b;
    this.mode = paramInt;
    switch (paramInt) {
      case 0:
        for (b = 0; b < 8; b++) {
          Shape3D shape3D1 = this.cornerShapes[b];
          if (shape3D1.isWireframe()) {
            shape3D1.setWireframe(false);
            shape3D1.setVisible(false);
          } 
        } 
        for (b = 0; b < 12; b++) {
          Shape3D shape3D1 = this.edgeShapes[b];
          if (shape3D1.isWireframe()) {
            shape3D1.setWireframe(false);
            shape3D1.setVisible(false);
          } 
        } 
        for (b = 0; b < 6; b++) {
          Shape3D shape3D1 = this.sideShapes[b];
          if (shape3D1.isWireframe()) {
            shape3D1.setWireframe(false);
            shape3D1.setVisible(false);
          } 
        } 
        shape3D = this.centerShape;
        if (shape3D.isWireframe()) {
          shape3D.setWireframe(false);
          shape3D.setVisible(false);
        } 
        break;
      case 1:
        for (b = 0; b < 8; b++) {
          shape3D = this.cornerShapes[b];
          if (!shape3D.isVisible()) {
            shape3D.setWireframe(true);
            shape3D.setVisible(true);
          } 
        } 
        for (b = 0; b < 12; b++) {
          shape3D = this.edgeShapes[b];
          if (!shape3D.isVisible()) {
            shape3D.setWireframe(true);
            shape3D.setVisible(true);
          } 
        } 
        for (b = 0; b < 6; b++) {
          shape3D = this.sideShapes[b];
          if (!shape3D.isVisible()) {
            shape3D.setWireframe(true);
            shape3D.setVisible(true);
          } 
        } 
        shape3D = this.centerShape;
        if (!shape3D.isVisible()) {
          shape3D.setWireframe(true);
          shape3D.setVisible(true);
        } 
        break;
    } 
    fireStateChanged();
  }
  
  public abstract String getName();
  
  class SideEvent implements Runnable {
    private int side;
    
    private boolean isClockwise;
    
    private final AbstractCube3DAWT this$0;
    
    public SideEvent(AbstractCube3DAWT this$0, int param1Int, boolean param1Boolean) {
      this.this$0 = this$0;
      this.side = param1Int;
      this.isClockwise = param1Boolean;
    }
    
    public void run() {
      this.this$0.model.twistSide(this.side, this.isClockwise);
    }
  }
  
  class SideAction implements ActionListener {
    private int side;
    
    private final AbstractCube3DAWT this$0;
    
    public SideAction(AbstractCube3DAWT this$0, int param1Int) {
      this.this$0 = this$0;
      this.side = param1Int;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      if (param1ActionEvent.getSource() instanceof MouseEvent) {
        MouseEvent mouseEvent = (MouseEvent)param1ActionEvent.getSource();
        if (mouseEvent.getClickCount() <= 1) {
          int i = this.this$0.model.getSideLocation(this.side);
          boolean bool = ((param1ActionEvent.getModifiers() & 0x9) != 0) ? true : false;
          this.this$0.getDispatcher().dispatch(new AbstractCube3DAWT.SideEvent(this.this$0, i, bool));
        } 
      } 
    }
  }
  
  class EdgeEvent implements Runnable {
    private int side;
    
    private boolean isClockwise;
    
    private final AbstractCube3DAWT this$0;
    
    public EdgeEvent(AbstractCube3DAWT this$0, int param1Int, boolean param1Boolean) {
      this.this$0 = this$0;
      this.side = param1Int;
      this.isClockwise = param1Boolean;
    }
    
    public void run() {
      this.this$0.model.twistEdge(this.side, this.isClockwise);
    }
  }
  
  class EdgeAction implements ActionListener {
    private int edge;
    
    private int orientation;
    
    private final AbstractCube3DAWT this$0;
    
    public EdgeAction(AbstractCube3DAWT this$0, int param1Int1, int param1Int2) {
      this.this$0 = this$0;
      this.edge = param1Int1;
      this.orientation = param1Int2;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      if (param1ActionEvent.getSource() instanceof MouseEvent) {
        MouseEvent mouseEvent = (MouseEvent)param1ActionEvent.getSource();
        if (mouseEvent.getClickCount() <= 1) {
          int i = this.this$0.model.getEdgeLayerSide(this.edge, this.orientation);
          boolean bool = ((param1ActionEvent.getModifiers() & 0x9) != 0) ? true : false;
          this.this$0.getDispatcher().dispatch(new AbstractCube3DAWT.EdgeEvent(this.this$0, i, bool));
        } 
      } 
    }
  }
  
  class CrnrActn implements ActionListener {
    private int corner;
    
    private int orientation;
    
    private final AbstractCube3DAWT this$0;
    
    public CrnrActn(AbstractCube3DAWT this$0, int param1Int1, int param1Int2) {
      this.this$0 = this$0;
      this.corner = param1Int1;
      this.orientation = param1Int2;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      if (param1ActionEvent.getSource() instanceof MouseEvent) {
        MouseEvent mouseEvent = (MouseEvent)param1ActionEvent.getSource();
        if (mouseEvent.getClickCount() <= 1) {
          int i = this.this$0.model.getCornerSide(this.corner, this.orientation);
          boolean bool = ((param1ActionEvent.getModifiers() & 0x9) != 0) ? true : false;
          this.this$0.getDispatcher().dispatch(new AbstractCube3DAWT.SideEvent(this.this$0, i, bool));
        } 
      } 
    }
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\AbstractCube3DAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */