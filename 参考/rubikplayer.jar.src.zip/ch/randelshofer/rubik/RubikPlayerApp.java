package ch.randelshofer.rubik;

import ch.randelshofer.geom3d.Point3D;
import ch.randelshofer.geom3d.RotatedTransform3DModel;
import ch.randelshofer.geom3d.Transform3D;
import ch.randelshofer.geom3d.Transform3DModel;
import ch.randelshofer.gui.Canvas3DAWT;
import ch.randelshofer.gui.Canvas3DJ2D;
import ch.randelshofer.gui.MultilineLabel;
import ch.randelshofer.gui.RatioLayout;
import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.rubik.parserAWT.BandelowENGParser;
import ch.randelshofer.rubik.parserAWT.CastellaParser;
import ch.randelshofer.rubik.parserAWT.HarrisENGParser;
import ch.randelshofer.rubik.parserAWT.RandelshoferGERParser;
import ch.randelshofer.rubik.parserAWT.ScriptFRAParser;
import ch.randelshofer.rubik.parserAWT.ScriptNode;
import ch.randelshofer.rubik.parserAWT.ScriptPlayer;
import ch.randelshofer.rubik.parserAWT.SupersetENGParser;
import ch.randelshofer.rubik.parserAWT.TouchardDeledicqFRAParser;
import ch.randelshofer.util.Applets;
import ch.randelshofer.util.PooledSequentialDispatcherAWT;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class RubikPlayerApp extends Applet implements Runnable {
  private ScriptPlayer player;
  
  private boolean isInitialized = false;
  
  private MultilineLabel scriptTextArea;
  
  private Panel controlsPanel;
  
  private static final String version = "5.2.1";
  
  private static final String copyright = "© 2000-2005 W. Randelshofer";
  
  private static final Color inactiveSelectionBackground = new Color(213, 213, 213);
  
  private static final Color activeSelectionBackground = new Color(255, 255, 64);
  
  private Canvas3DAWT rearCanvas3D;
  
  private RubiksCubeCore initCube;
  
  private boolean isSolver;
  
  public void init() {
    initComponents();
    PooledSequentialDispatcherAWT.dispatchConcurrently(this);
  }
  
  public void stop() {
    if (this.player != null)
      this.player.stop(); 
  }
  
  public void paint(Graphics paramGraphics) {
    paramGraphics.setFont(new Font("Dialog", 0, 10));
    FontMetrics fontMetrics = paramGraphics.getFontMetrics();
    paramGraphics.drawString("Loading Rubik Player 5.2.1", 12, fontMetrics.getHeight());
    paramGraphics.drawString("© 2000-2005 W. Randelshofer", 12, fontMetrics.getHeight() * 2);
  }
  
  public void run() {
    Component component;
    this.player = new ScriptPlayer(this) {
        private final RubikPlayerApp this$0;
        
        public void reset() {
          super.reset();
          getCubeModel().setTo(this.this$0.initCube);
        }
      };
    this.initCube = new RubiksCubeCore();
    this.controlsPanel = new Panel();
    this.controlsPanel.setLayout(new BorderLayout());
    this.controlsPanel.add("North", this.player.getControlPanelComponent());
    this.controlsPanel.add("South", (Component)(this.scriptTextArea = new MultilineLabel()));
    this.scriptTextArea.setFont(new Font("Dialog", 0, 12));
    this.scriptTextArea.addMouseListener(new MouseAdapter(this) {
          private final RubikPlayerApp this$0;
          
          public void mousePressed(MouseEvent param1MouseEvent) {
            int i = this.this$0.scriptTextArea.viewToModel(param1MouseEvent.getX(), param1MouseEvent.getY());
            this.this$0.player.moveToCaret(i);
          }
        });
    this.scriptTextArea.setSize(getSize());
    if (Applets.getParameter(this, "rearView", "false").equals("true")) {
      Canvas3DAWT canvas3DAWT = (Canvas3DAWT)this.player.getVisualComponent();
      this.rearCanvas3D = Canvas3DJ2D.createCanvas3D();
      this.rearCanvas3D.setScene(this.player.getCube3D().getScene());
      this.rearCanvas3D.setSyncObject(this.player.getCube3D().getModel());
      this.player.getCube3D().addChangeListener((ChangeListener)this.rearCanvas3D);
      int[] arrayOfInt = Applets.getParameters(this, "rearViewRotation", new int[] { 180, 0, 0 });
      if (arrayOfInt.length != 3)
        throw new IllegalArgumentException("Invalid parameter 'rearViewRotation' provides " + arrayOfInt.length + " instead of 3 values."); 
      this.rearCanvas3D.setTransformModel((Transform3DModel)new RotatedTransform3DModel(arrayOfInt[0] / 180.0D * Math.PI, arrayOfInt[1] / 180.0D * Math.PI, arrayOfInt[2] / 180.0D * Math.PI, canvas3DAWT.getTransformModel()));
      this.rearCanvas3D.setScaleFactor(canvas3DAWT.getScaleFactor());
      canvas3DAWT.setPreferredSize(new Dimension(1, 1));
      this.rearCanvas3D.setPreferredSize(new Dimension(1, 1));
      float f = (float)Applets.getParameter(this, "rearViewScaleFactor", 0.75D);
      f = (float)Math.max(0.1D, Math.min(1.0D, f));
      Panel panel = new Panel();
      panel.setLayout((LayoutManager)new RatioLayout(1.0F - 0.5F * f));
      panel.add((Component)canvas3DAWT);
      panel.add((Component)this.rearCanvas3D);
      component = panel;
      this.rearCanvas3D.setScaleFactor(this.rearCanvas3D.getScaleFactor() * f);
      component = panel;
    } else {
      component = this.player.getVisualComponent();
    } 
    try {
      readParameters();
    } catch (Throwable throwable) {
      removeAll();
      setLayout(new BorderLayout());
      TextArea textArea = new TextArea(10, 40);
      add("Center", textArea);
      StringWriter stringWriter = new StringWriter();
      PrintWriter printWriter = new PrintWriter(stringWriter);
      throwable.printStackTrace(printWriter);
      printWriter.close();
      textArea.setText(getAppletInfo() + "\n\n" + throwable + "\n" + stringWriter.toString());
      invalidate();
      validate();
      return;
    } 
    ChangeListener changeListener = new ChangeListener(this) {
        private final RubikPlayerApp this$0;
        
        public void stateChanged(ChangeEvent param1ChangeEvent) {
          this.this$0.selectCurrentSymbol();
        }
      };
    this.player.getBoundedRangeModel().addChangeListener(changeListener);
    this.player.addChangeListener(changeListener);
    synchronized (getTreeLock()) {
      add("Center", component);
      add("South", this.controlsPanel);
      validate();
      this.controlsPanel.invalidate();
      validate();
    } 
    if (Applets.getParameter(this, "autoPlay", false)) {
      try {
        Thread.sleep(100L);
      } catch (InterruptedException interruptedException) {}
      this.player.start();
    } 
  }
  
  protected void selectCurrentSymbol() {
    int i;
    int j;
    ScriptNode scriptNode = this.player.getCurrentSymbol();
    if (scriptNode == null) {
      i = j = this.scriptTextArea.getText().length();
    } else {
      i = scriptNode.getStartPosition();
      j = scriptNode.getEndPosition() + 1;
    } 
    this.scriptTextArea.select(i, j);
    this.scriptTextArea.setSelectionBackground(this.player.isProcessingCurrentSymbol() ? activeSelectionBackground : inactiveSelectionBackground);
  }
  
  private void readParameters() throws IllegalArgumentException {
    CastellaParser castellaParser;
    AbstractCube3DAWT abstractCube3DAWT = this.player.getCube3D();
    Hashtable hashtable1 = new Hashtable();
    Hashtable hashtable2 = new Hashtable();
    Color color = new Color(Applets.getParameter(this, "backgroundColor", 16777215));
    Canvas3DAWT canvas3DAWT = (Canvas3DAWT)this.player.getVisualComponent();
    canvas3DAWT.setBackground(color);
    this.player.getControlPanelComponent().setBackground(color);
    this.controlsPanel.setBackground(color);
    Transform3D transform3D = new Transform3D();
    transform3D.rotateY(Applets.getParameter(this, "beta", 45) / 180.0D * Math.PI);
    transform3D.rotateX(Applets.getParameter(this, "alpha", -25) / 180.0D * Math.PI);
    this.player.setTransform(transform3D);
    hashtable1 = new Hashtable();
    hashtable1.put("0", "0x003373");
    hashtable1.put("1", "0xff4600");
    hashtable1.put("2", "0xf8f8f8");
    hashtable1.put("3", "0x00732f");
    hashtable1.put("4", "0x8c000f");
    hashtable1.put("5", "0xffd200");
    hashtable1 = Applets.getIndexedKeyValueParameters(this, "colorTable", hashtable1);
    Enumeration enumeration = hashtable1.keys();
    while (enumeration.hasMoreElements()) {
      Object object = enumeration.nextElement();
      try {
        hashtable1.put(object, new Color(Applets.decode((String)hashtable1.get(object)).intValue()));
      } catch (NumberFormatException numberFormatException) {
        throw new IllegalArgumentException("Invalid parameter 'colorTable', value " + hashtable1.get(object) + " for entry " + object + " is illegal.");
      } 
    } 
    if (getParameter("faces") == null)
      for (byte b = 0; b < 6; b++) {
        String str = Integer.toString(b);
        if (!hashtable1.containsKey(str))
          throw new IllegalArgumentException("Invalid parameter 'colorTable', entry number " + str + " missing."); 
        color = (Color)hashtable1.get(str);
        for (byte b1 = 0; b1 < 9; b1++)
          abstractCube3DAWT.setStickerColor(b, b1, color); 
      }  
    String[] arrayOfString1 = Applets.getParameters(this, "faces", (String[])null);
    if (arrayOfString1 != null) {
      if (arrayOfString1.length != 6)
        throw new IllegalArgumentException("Invalid parameter 'faces' provides " + arrayOfString1.length + " instead of 6 entries."); 
      byte b1 = 0;
      byte b2 = 0;
      for (b1 = 0; b1 < 6; b1++) {
        if (!hashtable1.containsKey(arrayOfString1[b1]))
          throw new IllegalArgumentException("Invalid parameter 'faces', unknown entry '" + arrayOfString1[b1] + "'."); 
        color = (Color)hashtable1.get(arrayOfString1[b1]);
        for (b2 = 0; b2 < 9; b2++)
          abstractCube3DAWT.setStickerColor(b1, b2, color); 
      } 
    } 
    arrayOfString1 = Applets.getParameters(this, "stickers", (String[])null);
    if (arrayOfString1 != null) {
      if (arrayOfString1.length != 54)
        throw new IllegalArgumentException("Invalid parameter 'stickers' provides " + arrayOfString1.length + " instead of 54 entries."); 
      for (byte b = 0; b < 6; b++) {
        for (byte b1 = 0; b1 < 9; b1++) {
          if (!hashtable1.containsKey(arrayOfString1[b * 9 + b1]))
            throw new IllegalArgumentException("Invalid parameter 'stickers', unknown entry '" + arrayOfString1[b * 9 + b1] + "'."); 
          abstractCube3DAWT.setStickerColor(b, b1, (Color)hashtable1.get(arrayOfString1[b * 9 + b1]));
        } 
      } 
    } 
    String[] arrayOfString2 = { "stickersFront", "stickersRight", "stickersDown", "stickersBack", "stickersLeft", "stickersUp" };
    int i;
    for (i = 0; i < 6; i++) {
      arrayOfString1 = Applets.getParameters(this, arrayOfString2[i], (String[])null);
      if (arrayOfString1 != null) {
        if (arrayOfString1.length != 9)
          throw new IllegalArgumentException("Invalid parameter '" + arrayOfString2[i] + "' provides " + arrayOfString1.length + " instead of 9 entries."); 
        for (byte b = 0; b < 9; b++) {
          if (!hashtable1.containsKey(arrayOfString1[b]))
            throw new IllegalArgumentException("Invalid parameter '" + arrayOfString2[i] + "', unknown entry '" + arrayOfString1[b] + "'."); 
          abstractCube3DAWT.setStickerColor(i, b, (Color)hashtable1.get(arrayOfString1[b]));
        } 
      } 
    } 
    String str1 = getParameter("scriptLanguage");
    if (str1 == null || str1.equals("BandelowENG")) {
      BandelowENGParser bandelowENGParser = new BandelowENGParser();
    } else if (str1.equals("RandelshoferGER")) {
      RandelshoferGERParser randelshoferGERParser = new RandelshoferGERParser();
    } else if (str1.equals("ScriptFRA")) {
      ScriptFRAParser scriptFRAParser = new ScriptFRAParser();
    } else if (str1.equals("SupersetENG")) {
      SupersetENGParser supersetENGParser = new SupersetENGParser();
    } else if (str1.equals("HarrisENG")) {
      HarrisENGParser harrisENGParser = new HarrisENGParser();
    } else if (str1.equals("TouchardDeledicqFRA")) {
      TouchardDeledicqFRAParser touchardDeledicqFRAParser = new TouchardDeledicqFRAParser();
    } else if (str1.equals("Castella")) {
      castellaParser = new CastellaParser();
    } else {
      throw new IllegalArgumentException("Invalid parameter 'scriptLanguage': Unsupported language '" + str1 + "'");
    } 
    str1 = Applets.getParameter(this, "scriptType", "Generator");
    if (str1.equals("Solver")) {
      this.isSolver = true;
    } else if (str1.equals("Generator")) {
      this.isSolver = false;
    } else {
      throw new IllegalArgumentException("Invalid parameter 'scriptType': Unsupported type '" + str1 + "'");
    } 
    String str2 = getParameter("script");
    if (str2 == null) {
      this.scriptTextArea.setVisible(false);
    } else {
      int j;
      while ((j = str2.indexOf("\\n")) != -1)
        str2 = str2.substring(0, j) + '\n' + str2.substring(j + 2); 
      try {
        ScriptNode scriptNode = castellaParser.parse(new StringReader(str2));
        this.scriptTextArea.setText(str2);
        this.player.setScript(scriptNode);
      } catch (Exception exception) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        exception.printStackTrace(printWriter);
        printWriter.close();
        throw new IllegalArgumentException("Invalid parameter 'script':\n" + exception.getMessage() + "\n" + stringWriter);
      } 
    } 
    String str3 = getParameter("initScript");
    if (str3 == null) {
      this.initCube.reset();
    } else {
      this.initCube.reset();
      int j;
      while ((j = str3.indexOf("\\n")) != -1)
        str2 = str3.substring(0, j) + '\n' + str3.substring(j + 2); 
      try {
        ScriptNode scriptNode = castellaParser.parse(new StringReader(str3));
        scriptNode.applySubtreeTo(this.initCube, false);
      } catch (Exception exception) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        exception.printStackTrace(printWriter);
        printWriter.close();
        throw new IllegalArgumentException("Invalid parameter 'initScript':\n" + exception.getMessage() + "\n" + stringWriter);
      } 
    } 
    if (this.isSolver && this.player.getScript() != null)
      this.player.getScript().applySubtreeTo(this.initCube, true); 
    this.player.reset();
    try {
      i = Applets.getParameter(this, "scriptProgress", (this.isSolver || Applets.getParameter(this, "autoPlay", false)) ? 0 : -1);
      if (i < 0)
        i = this.player.getBoundedRangeModel().getMaximum() - i + 1; 
      this.player.getBoundedRangeModel().setValue(i);
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      throw new IllegalArgumentException("Invalid parameter 'scriptProgress':\n" + indexOutOfBoundsException.getMessage());
    } 
    str1 = getParameter("displayLines");
    i = (str2 == null) ? 0 : (new StringTokenizer(str2, "\n")).countTokens();
    if (str1 != null)
      try {
        i = Integer.parseInt(str1);
      } catch (NumberFormatException numberFormatException) {
        throw new IllegalArgumentException("Invalid parameter 'displayLines':\n" + numberFormatException.getMessage());
      }  
    if (i <= 0) {
      this.scriptTextArea.setVisible(false);
    } else {
      try {
        this.scriptTextArea.setMinRows(i);
      } catch (NoSuchMethodError noSuchMethodError) {}
    } 
    canvas3DAWT.setLightSourceIntensity(Applets.getParameter(this, "lightSourceIntensity", 1.0D));
    canvas3DAWT.setAmbientLightIntensity(Applets.getParameter(this, "ambientLightIntensity", 0.6D));
    int[] arrayOfInt = Applets.getParameters(this, "lightSourcePosition", new int[] { -500, 500, 1000 });
    if (arrayOfInt.length != 3)
      throw new IllegalArgumentException("Invalid parameter 'lightSourcePosition' provides " + arrayOfInt.length + " instead of 3 entries."); 
    canvas3DAWT.setLightSource(new Point3D(arrayOfInt[0], arrayOfInt[1], arrayOfInt[2]));
    str1 = getParameter("backgroundImage");
    if (str1 != null)
      try {
        canvas3DAWT.setBackgroundImage(getImage(new URL(getDocumentBase(), str1)));
      } catch (MalformedURLException malformedURLException) {
        throw new IllegalArgumentException("Invalid parameter 'backgroundImage' malformed URL: " + str1);
      }  
    if (Applets.getParameter(this, "rearView", "false").equals("true")) {
      color = new Color(Applets.getParameter(this, "rearViewBackgroundColor", Applets.getParameter(this, "backgroundColor", 16777215)));
      this.rearCanvas3D.setBackground(color);
      str1 = Applets.getParameter(this, "rearViewBackgroundImage", getParameter("backgroundImage"));
      if (str1 != null)
        try {
          this.rearCanvas3D.setBackgroundImage(getImage(new URL(getDocumentBase(), str1)));
        } catch (MalformedURLException malformedURLException) {
          throw new IllegalArgumentException("Invalid parameter 'backgroundImage' malformed URL: " + str1);
        }  
      this.rearCanvas3D.setLightSourceIntensity(Applets.getParameter(this, "lightSourceIntensity", 1.0D));
      this.rearCanvas3D.setAmbientLightIntensity(Applets.getParameter(this, "ambientLightIntensity", 0.6D));
      arrayOfInt = Applets.getParameters(this, "lightSourcePosition", new int[] { -500, 500, 1000 });
      if (arrayOfInt.length != 3)
        throw new IllegalArgumentException("Invalid parameter 'lightSourcePosition' provides " + arrayOfInt.length + " instead of 3 entries."); 
      this.rearCanvas3D.setLightSource(new Point3D(arrayOfInt[0], arrayOfInt[1], arrayOfInt[2]));
    } 
  }
  
  public String getAppletInfo() {
    return "Rubik Player 5.2.1, © 2000-2005 W. Randelshofer. All rights reserved.";
  }
  
  public String[][] getParameterInfo() {
    return new String[][] { 
        { "alpha", "int", "Vertical orientation of the cube, -90..+90. Default: -25" }, { "beta", "int", "Horizontal orientation of the cube, -90..+90. Default: 45" }, { "backgroundColor", "int", "Background color. Default: 0xffffff" }, { "backgroundImage", "URL", "Background image. Default: none" }, { "colorTable", "[name=]int, ...", "RGB color look up table, 6..n entries. Each entry consists of an optional name and a hex value. Default: 0x003373,0xff4600,0xf8f8f8,0x00732f,0x8c000f,0xffd200" }, { "faces", "name, ...", "Maps colors from the color table to the faces of the cube; 6 integer values; front, right, down, back, left, up. Default: 0,1,2,3,4,5" }, { "stickers", "name, ...", "Maps colors from the color table to the stickers of the cube; 54 integer values; front, right, down, back, left, up. Default: 0,0,0,0,0,0,0,0,0, 1,1,1,1,1,1,1,1,1, 2,2,2,2,2,2,2,2,2, 3,3,3,3,3,3,3,3,3, 4,4,4,4,4,4,4,4,4, 5,5,5,5,5,5,5,5,5" }, { "scriptLanguage", "string", "Language of the Script: 'ScriptFRA','BandelowENG','RandelshoferGER','SupersetENG','TouchardDeledicqFRA','Castella'. Default: BandelowENG" }, { "script", "string", "Script. Default: no script." }, { "stickersFront", "(name|int), ...", "Maps colors from the color table to the stickers on the side of the cube; 9 integer values. Default: 0,0,0,0,0,0,0,0,0" }, 
        { "stickersRight", "(name|int), ...", "Maps colors from the color table to the stickers on the side of the cube; 9 integer values. Default: 1,1,1,1,1,1,1,1,1" }, { "stickersDown", "(name|int), ...", "Maps colors from the color table to the stickers on the side of the cube; 9 integer values. Default: 2,2,2,2,2,2,2,2,2" }, { "stickersBack", "(name|int), ...", "Maps colors from the color table to the stickers on the side of the cube; 9 integer values. Default: 3,3,3,3,3,3,3,3,3" }, { "stickersLeft", "(name|int), ...", "Maps colors from the color table to the stickers on the side of the cube; 9 integer values. Default: 4,4,4,4,4,4,4,4,4" }, { "stickersUp", "(name|int), ...", "Maps colors from the color table to the stickers on the side of the cube; 9 integer values. Default: 5,5,5,5,5,5,5,5,5" }, { "scriptType", "string", "The type of the script: 'Solver' or 'Generator'. Default: 'Solver'." }, { "scriptProgress", "int", "Position of the progress bar. Default: end of script if scriptType is 'Generator', 0 if script type is 'Solver'." }, { "initScript", "string", "This script is used to initialize the cube, and when the reset button is pressed. Default: no script." }, { "displayLines", "int", "Number of lines of the Script display: set to 0 to switch the display off. Default: 1" }, { "ambientLightIntensity", "double", "Intensity of ambient light. Default: 0.6" }, 
        { "lightSourceIntensity", "double", "Intensity of the light source: set to 0 to switch the light source off. Default: 1.0" }, { "lightSourcePosition", "int,int,int", "X, Y and Z coordinate of the light source. Default: -500, 500, 1000" }, { "rearView", "boolean", "Set this value to true, to turn the rear view on. Default: false" }, { "rearViewBackgroundColor", "int", "Background color. Default: use value of parameter 'backgroundColor'" }, { "rearViewBackgroundImage", "URL", "Background image. Default: use value of parameter 'backgroundImage'" }, { "rearViewScaleFactor", "float", "Scale factor of the rear view. Value between 0.1 and 1.0. Default: 0.75" }, { "rearViewRotation", "int,int,int", "Rotation of the rear view on the X, Y and Z axis in degrees. Default: 180,0,0" }, { "autoPlay", "boolean", "Set this value to true, to start playing the script automatically. Default: false" } };
  }
  
  public static void main(String[] paramArrayOfString) {
    Frame frame = new Frame("RubikPlayer");
    ScriptPlayer scriptPlayer = new ScriptPlayer();
    Transform3D transform3D = new Transform3D();
    transform3D.rotateY(0.7853981633974483D);
    transform3D.rotateX(-0.4363323129985824D);
    scriptPlayer.setTransform(transform3D);
    frame.add(scriptPlayer.getVisualComponent(), "Center");
    frame.add(scriptPlayer.getControlPanelComponent(), "South");
    frame.setSize(400, 400);
    frame.addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent param1WindowEvent) {
            System.exit(0);
          }
        });
    frame.show();
  }
  
  private void initComponents() {
    setLayout(new BorderLayout());
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\RubikPlayerApp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */