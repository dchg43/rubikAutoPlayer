package ch.randelshofer.rubik;

import java.util.EventObject;

public class RubikEvent extends EventObject {
  private int axis;
  
  private int layerMask;
  
  private int angle;
  
  public RubikEvent(Object paramObject, int paramInt1, int paramInt2, int paramInt3) {
    super(paramObject);
    this.axis = paramInt1;
    this.layerMask = paramInt2;
    this.angle = paramInt3;
  }
  
  public int getPartType() {
    return this.axis;
  }
  
  public int getPartLocation() {
    return this.layerMask;
  }
  
  public int getAxis() {
    return this.axis;
  }
  
  public int getLayerMask() {
    return this.layerMask;
  }
  
  public int getAngle() {
    return this.angle;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\RubikEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */