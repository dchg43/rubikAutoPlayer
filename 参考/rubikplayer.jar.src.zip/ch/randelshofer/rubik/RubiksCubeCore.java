package ch.randelshofer.rubik;

import ch.randelshofer.gui.event.EventListenerList;
import ch.randelshofer.util.Arrays;

public class RubiksCubeCore implements Cloneable {
  protected int[] cornerLoc = new int[8];
  
  protected int[] cornerOrient = new int[8];
  
  protected int[] edgeLoc = new int[12];
  
  protected int[] edgeOrient = new int[12];
  
  protected int[] sideLoc = new int[6];
  
  protected int[] sideOrient = new int[6];
  
  protected static final int[] SIDE_TRANSLATION = new int[] { 0, 1, 2, 3, 4, 5 };
  
  EventListenerList listenerList = new EventListenerList();
  
  private boolean quiet;
  
  protected static final int[][] EDGE_TRANSLATION = new int[][] { 
      { 0, 1, 5, 7 }, { 4, 5, 0, 3 }, { 0, 7, 2, 1 }, { 5, 5, 1, 1 }, { 1, 3, 0, 5 }, { 2, 5, 1, 7 }, { 3, 1, 5, 1 }, { 1, 5, 3, 3 }, { 3, 7, 2, 7 }, { 5, 3, 4, 1 }, 
      { 4, 3, 3, 5 }, { 2, 3, 4, 7 } };
  
  protected static final int[][] CORNER_TRANSLATION = new int[][] { { 5, 6, 0, 0, 4, 2 }, { 2, 0, 4, 8, 0, 6 }, { 5, 8, 1, 0, 0, 2 }, { 2, 2, 0, 8, 1, 6 }, { 5, 2, 3, 0, 1, 2 }, { 2, 8, 1, 8, 3, 6 }, { 5, 0, 4, 0, 3, 2 }, { 2, 6, 3, 8, 4, 6 } };
  
  private static final int[][] EDGE_SIDE_MAP = new int[][] { 
      { 4, 1 }, { 5, 2 }, { 1, 4 }, { 3, 0 }, { 2, 5 }, { 0, 3 }, { 1, 4 }, { 5, 2 }, { 4, 1 }, { 0, 3 }, 
      { 2, 5 }, { 3, 0 } };
  
  public RubiksCubeCore() {
    reset();
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null || !(paramObject instanceof RubiksCubeCore))
      return false; 
    RubiksCubeCore rubiksCubeCore = (RubiksCubeCore)paramObject;
    return (Arrays.equals(rubiksCubeCore.cornerLoc, this.cornerLoc) && Arrays.equals(rubiksCubeCore.cornerOrient, this.cornerOrient) && Arrays.equals(rubiksCubeCore.edgeLoc, this.edgeLoc) && Arrays.equals(rubiksCubeCore.edgeOrient, this.edgeOrient) && Arrays.equals(rubiksCubeCore.sideLoc, this.sideLoc) && Arrays.equals(rubiksCubeCore.sideOrient, this.sideOrient));
  }
  
  public int hashCode() {
    int i = 0;
    byte b;
    for (b = 0; b < this.cornerLoc.length; b++)
      i <<= 1 + this.cornerLoc[b]; 
    for (b = 0; b < this.edgeLoc.length; b++)
      i <<= 1 + this.edgeLoc[b]; 
    return i;
  }
  
  public void reset() {
    byte b;
    for (b = 0; b < 8; b++) {
      this.cornerLoc[b] = b;
      this.cornerOrient[b] = 0;
    } 
    for (b = 0; b < 12; b++) {
      this.edgeLoc[b] = b;
      this.edgeOrient[b] = 0;
    } 
    for (b = 0; b < 6; b++) {
      this.sideLoc[b] = b;
      this.sideOrient[b] = 0;
    } 
    fireRubikChanged(new RubikEvent(this, 0, 0, 0));
  }
  
  public boolean isSolved() {
    byte b;
    for (b = 0; b < 8; b++) {
      if (this.cornerLoc[b] != b)
        return false; 
      if (this.cornerOrient[b] != 0)
        return false; 
    } 
    for (b = 0; b < 12; b++) {
      if (this.edgeLoc[b] != b)
        return false; 
      if (this.edgeOrient[b] != 0)
        return false; 
    } 
    for (b = 0; b < 6; b++) {
      if (this.sideLoc[b] != b)
        return false; 
      if (this.sideOrient[b] != 0)
        return false; 
    } 
    return true;
  }
  
  public void twistSide(int paramInt, boolean paramBoolean) {
    switch (paramInt) {
      case 0:
        transform(2, 4, paramBoolean ? -1 : 1);
        break;
      case 1:
        transform(0, 4, paramBoolean ? -1 : 1);
        break;
      case 2:
        transform(1, 1, paramBoolean ? 1 : -1);
        break;
      case 3:
        transform(2, 1, paramBoolean ? 1 : -1);
        break;
      case 4:
        transform(0, 1, paramBoolean ? 1 : -1);
        break;
      case 5:
        transform(1, 4, paramBoolean ? -1 : 1);
        break;
    } 
  }
  
  public void twistEdge(int paramInt, boolean paramBoolean) {
    switch (paramInt) {
      case 0:
        transform(2, 2, paramBoolean ? -1 : 1);
        break;
      case 1:
        transform(0, 2, paramBoolean ? -1 : 1);
        break;
      case 2:
        transform(1, 2, paramBoolean ? 1 : -1);
        break;
      case 3:
        transform(2, 2, paramBoolean ? 1 : -1);
        break;
      case 4:
        transform(0, 2, paramBoolean ? 1 : -1);
        break;
      case 5:
        transform(1, 2, paramBoolean ? -1 : 1);
        break;
    } 
  }
  
  public void transform(int paramInt1, int paramInt2, int paramInt3) {
    synchronized (this) {
      if (paramInt1 < 0 || paramInt1 > 2)
        throw new IllegalArgumentException("axis: " + paramInt1); 
      if (paramInt2 < 0 || paramInt2 > 7)
        throw new IllegalArgumentException("layerMask: " + paramInt2); 
      if (paramInt3 < -2 || paramInt3 > 2)
        throw new IllegalArgumentException("angle: " + paramInt3); 
      if (paramInt3 == 0)
        return; 
      boolean bool = (paramInt3 == -2) ? true : ((paramInt3 == -1) ? false : paramInt3);
      if ((paramInt2 & 0x1) != 0)
        switch (paramInt1) {
          case 0:
            switch (bool) {
              case false:
                twistLeftClockwise();
                break;
              case true:
                twistLeftCounterClockwise();
                break;
              case true:
                twistLeftDouble();
                break;
            } 
            break;
          case 1:
            switch (bool) {
              case false:
                twistBottomClockwise();
                break;
              case true:
                twistBottomCounterClockwise();
                break;
              case true:
                twistBottomDouble();
                break;
            } 
            break;
          case 2:
            switch (bool) {
              case false:
                twistBackClockwise();
                break;
              case true:
                twistBackCounterClockwise();
                break;
              case true:
                twistBackDouble();
                break;
            } 
            break;
        }  
      if ((paramInt2 & 0x2) != 0)
        switch (paramInt1) {
          case 0:
            switch (bool) {
              case false:
                twistMiddleLeftClockwise();
                break;
              case true:
                twistMiddleLeftCounterClockwise();
                break;
              case true:
                twistMiddleLeftDouble();
                break;
            } 
            break;
          case 1:
            switch (bool) {
              case false:
                twistMiddleBottomClockwise();
                break;
              case true:
                twistMiddleBottomCounterClockwise();
                break;
              case true:
                twistMiddleBottomDouble();
                break;
            } 
            break;
          case 2:
            switch (bool) {
              case false:
                twistMiddleBackClockwise();
                break;
              case true:
                twistMiddleBackCounterClockwise();
                break;
              case true:
                twistMiddleBackDouble();
                break;
            } 
            break;
        }  
      if ((paramInt2 & 0x4) != 0)
        switch (paramInt1) {
          case 0:
            switch (bool) {
              case false:
                twistRightCounterClockwise();
                break;
              case true:
                twistRightClockwise();
                break;
              case true:
                twistRightDouble();
                break;
            } 
            break;
          case 1:
            switch (bool) {
              case false:
                twistTopCounterClockwise();
                break;
              case true:
                twistTopClockwise();
                break;
              case true:
                twistTopDouble();
                break;
            } 
            break;
          case 2:
            switch (bool) {
              case false:
                twistFrontCounterClockwise();
                break;
              case true:
                twistFrontClockwise();
                break;
              case true:
                twistFrontDouble();
                break;
            } 
            break;
        }  
    } 
    fireRubikTwisted(new RubikEvent(this, paramInt1, paramInt2, paramInt3));
  }
  
  public void transform(RubiksCubeCore paramRubiksCubeCore) {
    int[] arrayOfInt1 = (int[])this.cornerLoc.clone();
    int[] arrayOfInt2 = (int[])this.cornerOrient.clone();
    byte b;
    for (b = 0; b < paramRubiksCubeCore.cornerLoc.length; b++) {
      this.cornerLoc[b] = arrayOfInt1[paramRubiksCubeCore.cornerLoc[b]];
      this.cornerOrient[b] = (arrayOfInt2[paramRubiksCubeCore.cornerLoc[b]] + paramRubiksCubeCore.cornerOrient[b]) % 3;
    } 
    arrayOfInt1 = (int[])this.edgeLoc.clone();
    arrayOfInt2 = (int[])this.edgeOrient.clone();
    for (b = 0; b < paramRubiksCubeCore.edgeLoc.length; b++) {
      this.edgeLoc[b] = arrayOfInt1[paramRubiksCubeCore.edgeLoc[b]];
      this.edgeOrient[b] = (arrayOfInt2[paramRubiksCubeCore.edgeLoc[b]] + paramRubiksCubeCore.edgeOrient[b]) % 2;
    } 
    arrayOfInt1 = (int[])this.sideLoc.clone();
    arrayOfInt2 = (int[])this.sideOrient.clone();
    for (b = 0; b < paramRubiksCubeCore.sideLoc.length; b++) {
      this.sideLoc[b] = arrayOfInt1[paramRubiksCubeCore.sideLoc[b]];
      this.sideOrient[b] = (arrayOfInt2[paramRubiksCubeCore.sideLoc[b]] + paramRubiksCubeCore.sideOrient[b]) % 4;
    } 
    fireRubikChanged(new RubikEvent(this, 0, 0, 0));
  }
  
  public void setTo(RubiksCubeCore paramRubiksCubeCore) {
    System.arraycopy(paramRubiksCubeCore.sideLoc, 0, this.sideLoc, 0, this.sideLoc.length);
    System.arraycopy(paramRubiksCubeCore.sideOrient, 0, this.sideOrient, 0, this.sideOrient.length);
    System.arraycopy(paramRubiksCubeCore.edgeLoc, 0, this.edgeLoc, 0, this.edgeLoc.length);
    System.arraycopy(paramRubiksCubeCore.edgeOrient, 0, this.edgeOrient, 0, this.edgeOrient.length);
    System.arraycopy(paramRubiksCubeCore.cornerLoc, 0, this.cornerLoc, 0, this.cornerLoc.length);
    System.arraycopy(paramRubiksCubeCore.cornerOrient, 0, this.cornerOrient, 0, this.cornerOrient.length);
    fireRubikChanged(new RubikEvent(this, 0, 0, 0));
  }
  
  private void twistFrontDouble() {
    twistFrontClockwise();
    twistFrontClockwise();
  }
  
  private void twistFrontCounterClockwise() {
    twistFrontClockwise();
    twistFrontClockwise();
    twistFrontClockwise();
  }
  
  private void twistFrontClockwise() {
    int i = this.cornerLoc[0];
    this.cornerLoc[0] = this.cornerLoc[1];
    this.cornerLoc[1] = this.cornerLoc[3];
    this.cornerLoc[3] = this.cornerLoc[2];
    this.cornerLoc[2] = i;
    i = this.cornerOrient[0];
    this.cornerOrient[0] = (this.cornerOrient[1] + 1) % 3;
    this.cornerOrient[1] = (this.cornerOrient[3] + 2) % 3;
    this.cornerOrient[3] = (this.cornerOrient[2] + 1) % 3;
    this.cornerOrient[2] = (i + 2) % 3;
    i = this.edgeLoc[0];
    this.edgeLoc[0] = this.edgeLoc[1];
    this.edgeLoc[1] = this.edgeLoc[2];
    this.edgeLoc[2] = this.edgeLoc[4];
    this.edgeLoc[4] = i;
    i = this.edgeOrient[0];
    this.edgeOrient[0] = (this.edgeOrient[1] + 1) % 2;
    this.edgeOrient[1] = (this.edgeOrient[2] + 1) % 2;
    this.edgeOrient[2] = (this.edgeOrient[4] + 1) % 2;
    this.edgeOrient[4] = (i + 1) % 2;
    this.sideOrient[0] = (this.sideOrient[0] + 3) % 4;
  }
  
  private void twistRightDouble() {
    twistRightClockwise();
    twistRightClockwise();
  }
  
  private void twistRightCounterClockwise() {
    twistRightClockwise();
    twistRightClockwise();
    twistRightClockwise();
  }
  
  private void twistRightClockwise() {
    int i = this.cornerLoc[2];
    this.cornerLoc[2] = this.cornerLoc[3];
    this.cornerLoc[3] = this.cornerLoc[5];
    this.cornerLoc[5] = this.cornerLoc[4];
    this.cornerLoc[4] = i;
    i = this.cornerOrient[2];
    this.cornerOrient[2] = (this.cornerOrient[3] + 1) % 3;
    this.cornerOrient[3] = (this.cornerOrient[5] + 2) % 3;
    this.cornerOrient[5] = (this.cornerOrient[4] + 1) % 3;
    this.cornerOrient[4] = (i + 2) % 3;
    i = this.edgeLoc[3];
    this.edgeLoc[3] = this.edgeLoc[4];
    this.edgeLoc[4] = this.edgeLoc[5];
    this.edgeLoc[5] = this.edgeLoc[7];
    this.edgeLoc[7] = i;
    i = this.edgeOrient[3];
    this.edgeOrient[3] = (this.edgeOrient[4] + 1) % 2;
    this.edgeOrient[4] = (this.edgeOrient[5] + 1) % 2;
    this.edgeOrient[5] = (this.edgeOrient[7] + 1) % 2;
    this.edgeOrient[7] = (i + 1) % 2;
    this.sideOrient[1] = (this.sideOrient[1] + 3) % 4;
  }
  
  private void twistLeftDouble() {
    twistLeftClockwise();
    twistLeftClockwise();
  }
  
  private void twistLeftCounterClockwise() {
    twistLeftClockwise();
    twistLeftClockwise();
    twistLeftClockwise();
  }
  
  private void twistLeftClockwise() {
    int i = this.cornerLoc[0];
    this.cornerLoc[0] = this.cornerLoc[6];
    this.cornerLoc[6] = this.cornerLoc[7];
    this.cornerLoc[7] = this.cornerLoc[1];
    this.cornerLoc[1] = i;
    i = this.cornerOrient[0];
    this.cornerOrient[0] = (this.cornerOrient[6] + 2) % 3;
    this.cornerOrient[6] = (this.cornerOrient[7] + 1) % 3;
    this.cornerOrient[7] = (this.cornerOrient[1] + 2) % 3;
    this.cornerOrient[1] = (i + 1) % 3;
    i = this.edgeLoc[1];
    this.edgeLoc[1] = this.edgeLoc[9];
    this.edgeLoc[9] = this.edgeLoc[10];
    this.edgeLoc[10] = this.edgeLoc[11];
    this.edgeLoc[11] = i;
    i = this.edgeOrient[1];
    this.edgeOrient[1] = (this.edgeOrient[9] + 1) % 2;
    this.edgeOrient[9] = (this.edgeOrient[10] + 1) % 2;
    this.edgeOrient[10] = (this.edgeOrient[11] + 1) % 2;
    this.edgeOrient[11] = (i + 1) % 2;
    this.sideOrient[4] = (this.sideOrient[4] + 3) % 4;
  }
  
  private void twistTopDouble() {
    twistTopClockwise();
    twistTopClockwise();
  }
  
  private void twistTopCounterClockwise() {
    twistTopClockwise();
    twistTopClockwise();
    twistTopClockwise();
  }
  
  private void twistTopClockwise() {
    int i = this.cornerLoc[0];
    this.cornerLoc[0] = this.cornerLoc[2];
    this.cornerLoc[2] = this.cornerLoc[4];
    this.cornerLoc[4] = this.cornerLoc[6];
    this.cornerLoc[6] = i;
    i = this.cornerOrient[0];
    this.cornerOrient[0] = this.cornerOrient[2];
    this.cornerOrient[2] = this.cornerOrient[4];
    this.cornerOrient[4] = this.cornerOrient[6];
    this.cornerOrient[6] = i;
    i = this.edgeLoc[0];
    this.edgeLoc[0] = this.edgeLoc[3];
    this.edgeLoc[3] = this.edgeLoc[6];
    this.edgeLoc[6] = this.edgeLoc[9];
    this.edgeLoc[9] = i;
    i = this.edgeOrient[0];
    this.edgeOrient[0] = (this.edgeOrient[3] + 1) % 2;
    this.edgeOrient[3] = (this.edgeOrient[6] + 1) % 2;
    this.edgeOrient[6] = (this.edgeOrient[9] + 1) % 2;
    this.edgeOrient[9] = (i + 1) % 2;
    this.sideOrient[5] = (this.sideOrient[5] + 3) % 4;
  }
  
  private void twistBottomDouble() {
    twistBottomClockwise();
    twistBottomClockwise();
  }
  
  private void twistBottomCounterClockwise() {
    twistBottomClockwise();
    twistBottomClockwise();
    twistBottomClockwise();
  }
  
  private void twistBottomClockwise() {
    int i = this.cornerLoc[1];
    this.cornerLoc[1] = this.cornerLoc[7];
    this.cornerLoc[7] = this.cornerLoc[5];
    this.cornerLoc[5] = this.cornerLoc[3];
    this.cornerLoc[3] = i;
    i = this.cornerOrient[1];
    this.cornerOrient[1] = this.cornerOrient[7];
    this.cornerOrient[7] = this.cornerOrient[5];
    this.cornerOrient[5] = this.cornerOrient[3];
    this.cornerOrient[3] = i;
    i = this.edgeLoc[2];
    this.edgeLoc[2] = this.edgeLoc[11];
    this.edgeLoc[11] = this.edgeLoc[8];
    this.edgeLoc[8] = this.edgeLoc[5];
    this.edgeLoc[5] = i;
    i = this.edgeOrient[2];
    this.edgeOrient[2] = (this.edgeOrient[11] + 1) % 2;
    this.edgeOrient[11] = (this.edgeOrient[8] + 1) % 2;
    this.edgeOrient[8] = (this.edgeOrient[5] + 1) % 2;
    this.edgeOrient[5] = (i + 1) % 2;
    this.sideOrient[2] = (this.sideOrient[2] + 3) % 4;
  }
  
  private void twistMiddleBackDouble() {
    twistMiddleFrontDouble();
  }
  
  private void twistMiddleBackCounterClockwise() {
    twistMiddleFrontClockwise();
  }
  
  private void twistMiddleBackClockwise() {
    twistMiddleFrontCounterClockwise();
  }
  
  private void twistMiddleFrontDouble() {
    twistMiddleFrontClockwise();
    twistMiddleFrontClockwise();
  }
  
  private void twistMiddleFrontCounterClockwise() {
    twistMiddleFrontClockwise();
    twistMiddleFrontClockwise();
    twistMiddleFrontClockwise();
  }
  
  private void twistMiddleFrontClockwise() {
    int i = this.edgeLoc[3];
    this.edgeLoc[3] = this.edgeLoc[9];
    this.edgeLoc[9] = this.edgeLoc[11];
    this.edgeLoc[11] = this.edgeLoc[5];
    this.edgeLoc[5] = i;
    i = this.edgeOrient[3];
    this.edgeOrient[3] = (this.edgeOrient[9] + 1) % 2;
    this.edgeOrient[9] = (this.edgeOrient[11] + 1) % 2;
    this.edgeOrient[11] = (this.edgeOrient[5] + 1) % 2;
    this.edgeOrient[5] = (i + 1) % 2;
    i = this.sideLoc[1];
    this.sideLoc[1] = this.sideLoc[5];
    this.sideLoc[5] = this.sideLoc[4];
    this.sideLoc[4] = this.sideLoc[2];
    this.sideLoc[2] = i;
    i = this.sideOrient[1];
    this.sideOrient[1] = (this.sideOrient[5] + 1) % 4;
    this.sideOrient[5] = (this.sideOrient[4] + 3) % 4;
    this.sideOrient[4] = (this.sideOrient[2] + 1) % 4;
    this.sideOrient[2] = (i + 3) % 4;
  }
  
  private void twistMiddleBottomDouble() {
    twistMiddleTopDouble();
  }
  
  private void twistMiddleBottomCounterClockwise() {
    twistMiddleTopClockwise();
  }
  
  private void twistMiddleBottomClockwise() {
    twistMiddleTopCounterClockwise();
  }
  
  private void twistMiddleTopDouble() {
    twistMiddleTopClockwise();
    twistMiddleTopClockwise();
  }
  
  private void twistMiddleTopCounterClockwise() {
    twistMiddleTopClockwise();
    twistMiddleTopClockwise();
    twistMiddleTopClockwise();
  }
  
  private void twistMiddleTopClockwise() {
    int i = this.edgeLoc[1];
    this.edgeLoc[1] = this.edgeLoc[4];
    this.edgeLoc[4] = this.edgeLoc[7];
    this.edgeLoc[7] = this.edgeLoc[10];
    this.edgeLoc[10] = i;
    i = this.edgeOrient[1];
    this.edgeOrient[1] = (this.edgeOrient[4] + 1) % 2;
    this.edgeOrient[4] = (this.edgeOrient[7] + 1) % 2;
    this.edgeOrient[7] = (this.edgeOrient[10] + 1) % 2;
    this.edgeOrient[10] = (i + 1) % 2;
    i = this.sideLoc[0];
    this.sideLoc[0] = this.sideLoc[1];
    this.sideLoc[1] = this.sideLoc[3];
    this.sideLoc[3] = this.sideLoc[4];
    this.sideLoc[4] = i;
    i = this.sideOrient[0];
    this.sideOrient[0] = (this.sideOrient[1] + 1) % 4;
    this.sideOrient[1] = (this.sideOrient[3] + 1) % 4;
    this.sideOrient[3] = (this.sideOrient[4] + 1) % 4;
    this.sideOrient[4] = (i + 1) % 4;
  }
  
  private void twistMiddleLeftDouble() {
    twistMiddleRightDouble();
  }
  
  private void twistMiddleLeftCounterClockwise() {
    twistMiddleRightClockwise();
  }
  
  private void twistMiddleLeftClockwise() {
    twistMiddleRightCounterClockwise();
  }
  
  private void twistMiddleRightDouble() {
    twistMiddleRightClockwise();
    twistMiddleRightClockwise();
  }
  
  private void twistMiddleRightCounterClockwise() {
    twistMiddleRightClockwise();
    twistMiddleRightClockwise();
    twistMiddleRightClockwise();
  }
  
  private void twistMiddleRightClockwise() {
    int i = this.edgeLoc[0];
    this.edgeLoc[0] = this.edgeLoc[2];
    this.edgeLoc[2] = this.edgeLoc[8];
    this.edgeLoc[8] = this.edgeLoc[6];
    this.edgeLoc[6] = i;
    i = this.edgeOrient[0];
    this.edgeOrient[0] = (this.edgeOrient[2] + 1) % 2;
    this.edgeOrient[2] = (this.edgeOrient[8] + 1) % 2;
    this.edgeOrient[8] = (this.edgeOrient[6] + 1) % 2;
    this.edgeOrient[6] = (i + 1) % 2;
    i = this.sideLoc[0];
    this.sideLoc[0] = this.sideLoc[2];
    this.sideLoc[2] = this.sideLoc[3];
    this.sideLoc[3] = this.sideLoc[5];
    this.sideLoc[5] = i;
    i = this.sideOrient[0];
    this.sideOrient[0] = (this.sideOrient[2] + 1) % 4;
    this.sideOrient[2] = (this.sideOrient[3] + 1) % 4;
    this.sideOrient[3] = (this.sideOrient[5] + 1) % 4;
    this.sideOrient[5] = (i + 1) % 4;
  }
  
  private void twistBackDouble() {
    twistBackClockwise();
    twistBackClockwise();
  }
  
  private void twistBackCounterClockwise() {
    int i = this.cornerLoc[6];
    this.cornerLoc[6] = this.cornerLoc[7];
    this.cornerLoc[7] = this.cornerLoc[5];
    this.cornerLoc[5] = this.cornerLoc[4];
    this.cornerLoc[4] = i;
    i = this.cornerOrient[6];
    this.cornerOrient[6] = (this.cornerOrient[7] + 2) % 3;
    this.cornerOrient[7] = (this.cornerOrient[5] + 1) % 3;
    this.cornerOrient[5] = (this.cornerOrient[4] + 2) % 3;
    this.cornerOrient[4] = (i + 1) % 3;
    i = this.edgeLoc[10];
    this.edgeLoc[10] = this.edgeLoc[8];
    this.edgeLoc[8] = this.edgeLoc[7];
    this.edgeLoc[7] = this.edgeLoc[6];
    this.edgeLoc[6] = i;
    i = this.edgeOrient[10];
    this.edgeOrient[10] = (this.edgeOrient[8] + 1) % 2;
    this.edgeOrient[8] = (this.edgeOrient[7] + 1) % 2;
    this.edgeOrient[7] = (this.edgeOrient[6] + 1) % 2;
    this.edgeOrient[6] = (i + 1) % 2;
    this.sideOrient[3] = (this.sideOrient[3] + 1) % 4;
  }
  
  private void twistBackClockwise() {
    int i = this.cornerLoc[4];
    this.cornerLoc[4] = this.cornerLoc[5];
    this.cornerLoc[5] = this.cornerLoc[7];
    this.cornerLoc[7] = this.cornerLoc[6];
    this.cornerLoc[6] = i;
    i = this.cornerOrient[4];
    this.cornerOrient[4] = (this.cornerOrient[5] + 1) % 3;
    this.cornerOrient[5] = (this.cornerOrient[7] + 2) % 3;
    this.cornerOrient[7] = (this.cornerOrient[6] + 1) % 3;
    this.cornerOrient[6] = (i + 2) % 3;
    i = this.edgeLoc[6];
    this.edgeLoc[6] = this.edgeLoc[7];
    this.edgeLoc[7] = this.edgeLoc[8];
    this.edgeLoc[8] = this.edgeLoc[10];
    this.edgeLoc[10] = i;
    i = this.edgeOrient[6];
    this.edgeOrient[6] = (this.edgeOrient[7] + 1) % 2;
    this.edgeOrient[7] = (this.edgeOrient[8] + 1) % 2;
    this.edgeOrient[8] = (this.edgeOrient[10] + 1) % 2;
    this.edgeOrient[10] = (i + 1) % 2;
    this.sideOrient[3] = (this.sideOrient[3] + 3) % 4;
  }
  
  private void rotateFrontClockwise() {
    twistFrontClockwise();
    twistMiddleFrontClockwise();
    twistBackCounterClockwise();
  }
  
  private void rotateFrontCounterClockwise() {
    twistFrontCounterClockwise();
    twistMiddleFrontCounterClockwise();
    twistBackClockwise();
  }
  
  private void rotateFrontDouble() {
    twistFrontDouble();
    twistMiddleFrontDouble();
    twistBackDouble();
  }
  
  private void rotateBackClockwise() {
    rotateFrontCounterClockwise();
  }
  
  private void rotateBackCounterClockwise() {
    rotateFrontClockwise();
  }
  
  private void rotateBackDouble() {
    rotateFrontDouble();
  }
  
  private void rotateTopClockwise() {
    twistTopClockwise();
    twistMiddleTopClockwise();
    twistBottomCounterClockwise();
  }
  
  private void rotateTopCounterClockwise() {
    twistTopCounterClockwise();
    twistMiddleTopCounterClockwise();
    twistBottomClockwise();
  }
  
  private void rotateTopDouble() {
    twistTopDouble();
    twistMiddleTopDouble();
    twistBottomDouble();
  }
  
  private void rotateBottomClockwise() {
    rotateTopCounterClockwise();
  }
  
  private void rotateBottomCounterClockwise() {
    rotateTopClockwise();
  }
  
  private void rotateBottomDouble() {
    rotateTopDouble();
  }
  
  private void rotateRightClockwise() {
    twistRightClockwise();
    twistMiddleRightClockwise();
    twistLeftCounterClockwise();
  }
  
  private void rotateRightCounterClockwise() {
    twistRightCounterClockwise();
    twistMiddleRightCounterClockwise();
    twistLeftClockwise();
  }
  
  private void rotateRightDouble() {
    twistRightDouble();
    twistMiddleRightDouble();
    twistLeftDouble();
  }
  
  private void rotateLeftClockwise() {
    rotateRightCounterClockwise();
  }
  
  private void rotateLeftCounterClockwise() {
    rotateRightClockwise();
  }
  
  private void rotateLeftDouble() {
    rotateRightDouble();
  }
  
  public int[] getCornerLocations() {
    return this.cornerLoc;
  }
  
  public int[] getCornerOrientations() {
    return this.cornerOrient;
  }
  
  public void setCorners(int[] paramArrayOfint1, int[] paramArrayOfint2) {
    this.cornerLoc = paramArrayOfint1;
    this.cornerOrient = paramArrayOfint2;
    fireRubikChanged(new RubikEvent(this, 0, 0, 0));
  }
  
  public int getCornerAt(int paramInt) {
    return this.cornerLoc[paramInt];
  }
  
  public int getCornerLocation(int paramInt) {
    if (this.cornerLoc[paramInt] == paramInt)
      return paramInt; 
    int i;
    for (i = this.cornerLoc.length - 1; i >= 0 && this.cornerLoc[i] != paramInt; i--);
    return i;
  }
  
  public int getCornerOrientation(int paramInt) {
    return this.cornerOrient[getCornerLocation(paramInt)];
  }
  
  public int[] getEdgeLocations() {
    return this.edgeLoc;
  }
  
  public int[] getEdgeOrientations() {
    return this.edgeOrient;
  }
  
  public void setEdges(int[] paramArrayOfint1, int[] paramArrayOfint2) {
    this.edgeLoc = paramArrayOfint1;
    this.edgeOrient = paramArrayOfint2;
    fireRubikChanged(new RubikEvent(this, 0, 0, 0));
  }
  
  public int getEdgeAt(int paramInt) {
    return this.edgeLoc[paramInt];
  }
  
  public int getEdgeLocation(int paramInt) {
    if (this.edgeLoc[paramInt] == paramInt)
      return paramInt; 
    int i;
    for (i = this.edgeLoc.length - 1; i >= 0 && this.edgeLoc[i] != paramInt; i--);
    return i;
  }
  
  public int getEdgeOrientation(int paramInt) {
    return this.edgeOrient[getEdgeLocation(paramInt)];
  }
  
  public int[] getSideLocations() {
    return this.sideLoc;
  }
  
  public int[] getSideOrientations() {
    return this.sideOrient;
  }
  
  public void setSides(int[] paramArrayOfint1, int[] paramArrayOfint2) {
    this.sideLoc = paramArrayOfint1;
    this.sideOrient = paramArrayOfint2;
    fireRubikChanged(new RubikEvent(this, 0, 0, 0));
  }
  
  public int getSideAt(int paramInt) {
    return this.sideLoc[paramInt];
  }
  
  public int getSideLocation(int paramInt) {
    if (this.sideLoc[paramInt] == paramInt)
      return paramInt; 
    int i;
    for (i = this.sideLoc.length - 1; i >= 0 && this.sideLoc[i] != paramInt; i--);
    return i;
  }
  
  public int getSideOrientation(int paramInt) {
    return this.sideOrient[getSideLocation(paramInt)];
  }
  
  public int getCubeOrientation() {
    switch (this.sideLoc[0] * 6 + this.sideLoc[1]) {
      case 1:
        return 0;
      case 13:
        return 1;
      case 19:
        return 2;
      case 31:
        return 3;
      case 9:
        return 4;
      case 22:
        return 5;
      case 24:
        return 6;
      case 5:
        return 7;
      case 4:
        return 8;
      case 2:
        return 9;
      case 11:
        return 10;
      case 34:
        return 11;
      case 26:
        return 12;
      case 6:
        return 13;
      case 27:
        return 14;
      case 8:
        return 15;
      case 16:
        return 16;
      case 29:
        return 17;
      case 12:
        return 18;
      case 15:
        return 19;
      case 20:
        return 20;
      case 23:
        return 21;
      case 33:
        return 22;
      case 30:
        return 23;
    } 
    return -1;
  }
  
  public int getPartSide(int paramInt1, int paramInt2) {
    return (paramInt1 < 8) ? getCornerSide(paramInt1, paramInt2) : ((paramInt1 < 20) ? getEdgeSide(paramInt1 - 8, paramInt2) : ((paramInt1 < 26) ? getSideLocation(paramInt1 - 20) : paramInt2));
  }
  
  public int getCornerSide(int paramInt1, int paramInt2) {
    int i = getCornerLocation(paramInt1);
    return CORNER_TRANSLATION[i][(6 + paramInt2 * 2 - this.cornerOrient[i] * 2) % 6];
  }
  
  public int getEdgeSide(int paramInt1, int paramInt2) {
    int i = getEdgeLocation(paramInt1);
    switch (paramInt2) {
      case 0:
        return EDGE_TRANSLATION[i][(4 - this.edgeOrient[i] * 2) % 4];
      case 1:
        return EDGE_TRANSLATION[i][(6 - this.edgeOrient[i] * 2) % 4];
    } 
    throw new IllegalArgumentException("invalid orientation:" + paramInt2);
  }
  
  public int getEdgeLayerSide(int paramInt1, int paramInt2) {
    int i = getEdgeLocation(paramInt1);
    return EDGE_SIDE_MAP[i][(paramInt2 + this.edgeOrient[i]) % 2];
  }
  
  public void addRubikListener(RubikListener paramRubikListener) {
    this.listenerList.add(RubikListener.class, paramRubikListener);
  }
  
  public void removeRubikListener(RubikListener paramRubikListener) {
    this.listenerList.remove(RubikListener.class, paramRubikListener);
  }
  
  protected void fireRubikTwisted(RubikEvent paramRubikEvent) {
    if (!this.quiet) {
      Object[] arrayOfObject = this.listenerList.getListenerList();
      int i;
      for (i = arrayOfObject.length - 2; i >= 0; i -= 2) {
        if (arrayOfObject[i] == RubikListener.class)
          ((RubikListener)arrayOfObject[i + 1]).rubikTwisting(paramRubikEvent); 
      } 
      for (i = arrayOfObject.length - 2; i >= 0; i -= 2) {
        if (arrayOfObject[i] == RubikListener.class)
          ((RubikListener)arrayOfObject[i + 1]).rubikTwisted(paramRubikEvent); 
      } 
    } 
  }
  
  protected void fireRubikChanged(RubikEvent paramRubikEvent) {
    if (!this.quiet) {
      Object[] arrayOfObject = this.listenerList.getListenerList();
      for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
        if (arrayOfObject[i] == RubikListener.class)
          ((RubikListener)arrayOfObject[i + 1]).rubikChanged(paramRubikEvent); 
      } 
    } 
  }
  
  public void setQuiet(boolean paramBoolean) {
    if (paramBoolean != this.quiet) {
      this.quiet = paramBoolean;
      if (!this.quiet)
        fireRubikChanged(new RubikEvent(this, 0, 0, 0)); 
    } 
  }
  
  public Object clone() {
    try {
      RubiksCubeCore rubiksCubeCore = (RubiksCubeCore)super.clone();
      rubiksCubeCore.cornerLoc = (int[])this.cornerLoc.clone();
      rubiksCubeCore.cornerOrient = (int[])this.cornerOrient.clone();
      rubiksCubeCore.edgeLoc = (int[])this.edgeLoc.clone();
      rubiksCubeCore.edgeOrient = (int[])this.edgeOrient.clone();
      rubiksCubeCore.sideLoc = (int[])this.sideLoc.clone();
      rubiksCubeCore.sideOrient = (int[])this.sideOrient.clone();
      rubiksCubeCore.listenerList = new EventListenerList();
      return rubiksCubeCore;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new InternalError(cloneNotSupportedException.getMessage());
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\RubiksCubeCore.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */