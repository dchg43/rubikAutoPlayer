package ch.randelshofer.rubik.parserAWT;

import ch.randelshofer.geom3d.Transform3D;
import ch.randelshofer.gui.AbstractButton;
import ch.randelshofer.gui.BoundedRangeModel;
import ch.randelshofer.gui.Canvas3DAWT;
import ch.randelshofer.gui.Canvas3DJ2D;
import ch.randelshofer.gui.DefaultBoundedRangeModel;
import ch.randelshofer.gui.Icon;
import ch.randelshofer.gui.MovieControlAWT;
import ch.randelshofer.gui.PolygonIcon;
import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.gui.event.EventListenerList;
import ch.randelshofer.media.Player;
import ch.randelshofer.rubik.AbstractCube3DAWT;
import ch.randelshofer.rubik.MiniCube3DAWT;
import ch.randelshofer.rubik.RubiksCubeCore;
import ch.randelshofer.util.ConcurrentDispatcherAWT;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.Polygon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageProducer;
import java.util.Enumeration;
import java.util.EventListener;
import java.util.Vector;

public class ScriptPlayer implements Player, Runnable, ChangeListener, ActionListener {
  private Canvas3DAWT canvas = Canvas3DJ2D.createCanvas3D();
  
  private AbstractCube3DAWT cube3D = (AbstractCube3DAWT)new MiniCube3DAWT();
  
  private RubiksCubeCore model = new RubiksCubeCore();
  
  private DefaultBoundedRangeModel progress = new DefaultBoundedRangeModel(0, 0, 0, 0);
  
  private Panel controlPanel;
  
  private MovieControlAWT controls;
  
  private EventListenerList listenerList = new EventListenerList();
  
  private ScriptNode script;
  
  private Vector scriptVector = new Vector();
  
  private volatile int scriptIndex;
  
  private ChangeEvent changeEvent;
  
  private static final int STOPPED = 0;
  
  private static final int STARTING = 1;
  
  private static final int RUNNING = 2;
  
  private static final int STOPPING = 3;
  
  private int state = 0;
  
  private AbstractButton resetButton;
  
  private Transform3D transform = new Transform3D();
  
  private volatile boolean isProcessingCurrentSymbol;
  
  private static ConcurrentDispatcherAWT threadPool = new ConcurrentDispatcherAWT();
  
  public ScriptPlayer() {
    this.cube3D.setAnimated(true);
    this.cube3D.setModel(this.model);
    this.cube3D.addChangeListener((ChangeListener)this.canvas);
    this.canvas.setScene(this.cube3D.getScene());
    this.canvas.setBackground(Color.white);
    this.canvas.setSyncObject(this.model);
    this.canvas.setScaleFactor(0.02D);
    this.canvas.setToIdentity();
    this.progress.addChangeListener(this);
    this.controlPanel = new Panel();
    this.controlPanel.setLayout(new BorderLayout());
    this.controls = new MovieControlAWT();
    this.controls.setVisible(false);
    this.controls.setPlayer(this);
    this.controlPanel.add("Center", (Component)this.controls);
    this.resetButton = new AbstractButton();
    this.resetButton.setIcon((Icon)new PolygonIcon(new Polygon[] { new Polygon(new int[] { 2, 3, 3, 2 }, new int[] { 2, 2, 9, 9 }, 4), new Polygon(new int[] { 9, 9, 6, 6 }, new int[] { 2, 9, 6, 5 }, 4) }new Dimension(10, 10)));
    this.resetButton.addActionListener(this);
    this.resetButton.setPreferredSize(new Dimension(15, 15));
    this.controlPanel.add("West", (Component)this.resetButton);
  }
  
  public RubiksCubeCore getCubeModel() {
    return this.model;
  }
  
  public void setTransform(Transform3D paramTransform3D) {
    this.transform = paramTransform3D;
    this.canvas.setTransform(paramTransform3D);
  }
  
  public void setCubeModel(RubiksCubeCore paramRubiksCubeCore) {
    this.model = paramRubiksCubeCore;
    this.canvas.setSyncObject(paramRubiksCubeCore);
    this.cube3D.setModel(paramRubiksCubeCore);
  }
  
  public AbstractCube3DAWT getCube3D() {
    return this.cube3D;
  }
  
  public void setCube3D(AbstractCube3DAWT paramAbstractCube3DAWT) {
    if (this.cube3D != null) {
      this.cube3D.removeChangeListener((ChangeListener)this.canvas);
      this.cube3D.setModel(new RubiksCubeCore());
    } 
    this.cube3D = paramAbstractCube3DAWT;
    if (this.cube3D != null) {
      this.cube3D.setAnimated(true);
      this.cube3D.addChangeListener((ChangeListener)this.canvas);
      this.cube3D.setModel(getCubeModel());
      this.canvas.setScene(this.cube3D.getScene());
    } 
  }
  
  public ScriptNode getScript() {
    return this.script;
  }
  
  public synchronized void setScript(ScriptNode paramScriptNode) {
    stop();
    this.script = paramScriptNode;
    this.scriptVector.removeAllElements();
    this.scriptIndex = 0;
    this.controls.setVisible((paramScriptNode != null));
    if (paramScriptNode == null) {
      this.progress.setRangeProperties(0, 0, 0, 0, false);
    } else {
      Enumeration enumeration = paramScriptNode.resolvedEnumeration(false);
      while (enumeration.hasMoreElements()) {
        ScriptNode scriptNode = enumeration.nextElement();
        if ((scriptNode instanceof TwistNode && ((TwistNode)scriptNode).getSymbol() != 84) || scriptNode instanceof PermutationNode)
          this.scriptVector.addElement(scriptNode); 
      } 
      this.progress.setRangeProperties(0, 0, 0, this.scriptVector.size(), false);
    } 
    updateEnabled();
  }
  
  public void moveToCaret(int paramInt) {
    for (byte b = 0; b < this.scriptVector.size(); b++) {
      ScriptNode scriptNode = this.scriptVector.elementAt(b);
      if (scriptNode.getStartPosition() <= paramInt && scriptNode.getEndPosition() >= paramInt) {
        this.progress.setValue(b);
        return;
      } 
    } 
  }
  
  private void updateEnabled() {
    boolean bool = (this.script != null) ? true : false;
    if (bool) {
      this.controls.enable();
    } else {
      this.controls.disable();
    } 
  }
  
  public ImageProducer getImageProducer() {
    return null;
  }
  
  public BoundedRangeModel getBoundedRangeModel() {
    return (BoundedRangeModel)this.progress;
  }
  
  public void start() {
    boolean bool = false;
    synchronized (this) {
      if (this.state == 0) {
        this.state = 1;
        bool = true;
      } 
    } 
    if (bool) {
      this.cube3D.getDispatcher().dispatch(this, threadPool);
      fireStateChanged();
    } 
  }
  
  public void run() {
    synchronized (this) {
      if (this.state == 1) {
        this.state = 2;
      } else {
        return;
      } 
    } 
    fireStateChanged();
    if (this.progress.getMaximum() > 0) {
      if (this.progress.getValue() == this.progress.getMaximum()) {
        this.progress.setValue(0);
        this.model.setQuiet(true);
        while (this.scriptIndex > 0) {
          ScriptNode scriptNode = this.scriptVector.elementAt(--this.scriptIndex);
          scriptNode.applyInverseTo(this.model);
        } 
        this.model.setQuiet(false);
      } 
      while ((this.state == 2 && this.progress.getValue() != this.progress.getMaximum()) || this.scriptIndex != this.progress.getValue()) {
        this.isProcessingCurrentSymbol = true;
        fireStateChanged();
        int i = Math.min(this.progress.getValue() + 1, this.progress.getMaximum());
        if (this.scriptIndex == i - 1) {
          ScriptNode scriptNode = this.scriptVector.elementAt(this.scriptIndex++);
          scriptNode.applyTo(this.model);
        } else if (this.scriptIndex == i + 1) {
          ScriptNode scriptNode = this.scriptVector.elementAt(--this.scriptIndex);
          scriptNode.applyInverseTo(this.model);
        } else {
          this.model.setQuiet(true);
          while (this.scriptIndex < i) {
            ScriptNode scriptNode = this.scriptVector.elementAt(this.scriptIndex++);
            scriptNode.applyTo(this.model);
          } 
          while (this.scriptIndex > i) {
            ScriptNode scriptNode = this.scriptVector.elementAt(--this.scriptIndex);
            scriptNode.applyInverseTo(this.model);
          } 
          this.model.setQuiet(false);
        } 
        this.isProcessingCurrentSymbol = false;
        this.progress.setValue(this.progress.getValue() + 1);
        fireStateChanged();
      } 
    } 
    synchronized (this) {
      this.state = 0;
      notifyAll();
    } 
    fireStateChanged();
  }
  
  public synchronized void stop() {
    if (this.state == 2) {
      this.state = 3;
      while (this.state != 0) {
        try {
          wait();
        } catch (InterruptedException interruptedException) {}
      } 
    } else {
      this.state = 0;
      this.cube3D.getDispatcher().reassign();
      update();
    } 
  }
  
  public void reset() {
    stop();
    this.scriptIndex = 0;
    this.progress.setValue(0);
    this.model.reset();
    this.canvas.setTransform(this.transform);
    fireStateChanged();
  }
  
  public void removeChangeListener(ChangeListener paramChangeListener) {
    this.listenerList.remove(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public boolean isActive() {
    return (this.state != 0);
  }
  
  public void addChangeListener(ChangeListener paramChangeListener) {
    this.listenerList.add(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public Component getVisualComponent() {
    return (Component)this.canvas;
  }
  
  public Component getControlPanelComponent() {
    return this.controlPanel;
  }
  
  protected void fireStateChanged() {
    Object[] arrayOfObject = this.listenerList.getListenerList();
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == ChangeListener.class) {
        if (this.changeEvent == null)
          this.changeEvent = new ChangeEvent(this); 
        ((ChangeListener)arrayOfObject[i + 1]).stateChanged(this.changeEvent);
      } 
    } 
  }
  
  public ScriptNode getCurrentSymbol() {
    int i = this.scriptIndex;
    return (i < this.scriptVector.size()) ? this.scriptVector.elementAt(i) : null;
  }
  
  public void setResetButtonVisible(boolean paramBoolean) {
    this.resetButton.setVisible(paramBoolean);
  }
  
  public boolean isProcessingCurrentSymbol() {
    return this.isProcessingCurrentSymbol;
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent) {
    if (paramChangeEvent.getSource() == this.progress && !isActive())
      update(); 
  }
  
  private void update() {
    Runnable runnable = new Runnable(this) {
        private final ScriptPlayer this$0;
        
        public void run() {
          int i = this.this$0.progress.getValue();
          this.this$0.isProcessingCurrentSymbol = true;
          if (this.this$0.scriptIndex == i - 1) {
            this.this$0.fireStateChanged();
            ScriptNode scriptNode = this.this$0.scriptVector.elementAt(this.this$0.scriptIndex++);
            scriptNode.applyTo(this.this$0.model);
          } else if (this.this$0.scriptIndex == i + 1) {
            ScriptNode scriptNode = this.this$0.scriptVector.elementAt(--this.this$0.scriptIndex);
            this.this$0.fireStateChanged();
            scriptNode.applyInverseTo(this.this$0.model);
          } else {
            this.this$0.model.setQuiet(true);
            while (this.this$0.scriptIndex < i) {
              ScriptNode scriptNode = this.this$0.scriptVector.elementAt(this.this$0.scriptIndex++);
              scriptNode.applyTo(this.this$0.model);
            } 
            while (this.this$0.scriptIndex > i) {
              ScriptNode scriptNode = this.this$0.scriptVector.elementAt(--this.this$0.scriptIndex);
              scriptNode.applyInverseTo(this.this$0.model);
            } 
            this.this$0.model.setQuiet(false);
          } 
          this.this$0.isProcessingCurrentSymbol = false;
          this.this$0.fireStateChanged();
        }
      };
    if (this.cube3D.isAnimated()) {
      this.cube3D.getDispatcher().dispatch(runnable);
    } else {
      runnable.run();
    } 
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (paramActionEvent.getSource() == this.resetButton)
      reset(); 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\ScriptPlayer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */