package ch.randelshofer.rubik.parserAWT;

import java.util.Enumeration;

public class InversionNode extends ScriptNode {
  public InversionNode() {}
  
  public InversionNode(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public int getSymbol() {
    return 117;
  }
  
  public Enumeration resolvedEnumeration(boolean paramBoolean) {
    return super.resolvedEnumeration(!paramBoolean);
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\InversionNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */