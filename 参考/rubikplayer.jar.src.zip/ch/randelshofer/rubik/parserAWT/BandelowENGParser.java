package ch.randelshofer.rubik.parserAWT;

import java.util.Hashtable;
import java.util.StringTokenizer;

public class BandelowENGParser extends ScriptParser {
  private static final String COMPRESSED_TOKENS = "R;U;F;L;D;B;R';U';F';L';D';B';R2;U2;F2;L2;D2;B2;R2';U2';F2';L2';D2';B2';;;;;;;;;;;;;;;;;;;;;;;;;MR ML';MU MD';MF MB';ML MR';MD MU';MB MF';MR2 ML2';MU2 MD2';MF2 MB2';ML2 MR2';MD2 MU2';MB2 MF2';;;;;;;;;;;;;CR CL';CU CD';CF CB';CL CR';CD CU';CB CF';CR2 CL2';CU2 CD2';CF2 CB2';CL2 CR2';CD2 CU2';CB2 CF2';.;r;u;f;l;d;b;+;-;++;;';;( [ {;) ] };,;(;);;;;;;;;;/*;*/;//;";
  
  private static final String COMPRESSED_MACROS = "CFU CUF CDB CBD;CR CU2;CUB CBU CFD CDF;CL CU2;CRU CUR CLD CDL;CR2 CB;CUL CLU CRD CDR;CR2 CF;CRF CFR CLB CBL;CR2 CU;CLF CFL CBR CRB;CR2 CD;CUFL CFLU CLUF CDBR CBRD CRDB;CL CF;CURF CRVU CFUR CDLB CLBD CBDL;CR CU;CRUB CUBR CBRU CLDF CDFL CFLD;CR CB;CBUL CULB CLBU CFDR CDRF CRFD;CL CU;CLFO CULF CFUL CRBD CDRB CBDR;CR CD;CFRU CUFR CRUF CBLD CDBL CLDB;CL CB;CBUR CRBU CURB CFDL CLFD CDLF;CL CD;CLUB CBLU CUBL CRDF CFRD CDFR;CR CF";
  
  public BandelowENGParser() {
    super(getTokens(), getMacros(), 1, 1, -1, -1, -1, true);
  }
  
  private static String[] getTokens() {
    String[] arrayOfString = new String[113];
    byte b = 0;
    StringTokenizer stringTokenizer = new StringTokenizer("R;U;F;L;D;B;R';U';F';L';D';B';R2;U2;F2;L2;D2;B2;R2';U2';F2';L2';D2';B2';;;;;;;;;;;;;;;;;;;;;;;;;MR ML';MU MD';MF MB';ML MR';MD MU';MB MF';MR2 ML2';MU2 MD2';MF2 MB2';ML2 MR2';MD2 MU2';MB2 MF2';;;;;;;;;;;;;CR CL';CU CD';CF CB';CL CR';CD CU';CB CF';CR2 CL2';CU2 CD2';CF2 CB2';CL2 CR2';CD2 CU2';CB2 CF2';.;r;u;f;l;d;b;+;-;++;;';;( [ {;) ] };,;(;);;;;;;;;;/*;*/;//;", ";", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals(";")) {
        b++;
        continue;
      } 
      arrayOfString[b] = str;
    } 
    return arrayOfString;
  }
  
  private static Hashtable getMacros() {
    Hashtable hashtable = new Hashtable();
    StringTokenizer stringTokenizer = new StringTokenizer("CFU CUF CDB CBD;CR CU2;CUB CBU CFD CDF;CL CU2;CRU CUR CLD CDL;CR2 CB;CUL CLU CRD CDR;CR2 CF;CRF CFR CLB CBL;CR2 CU;CLF CFL CBR CRB;CR2 CD;CUFL CFLU CLUF CDBR CBRD CRDB;CL CF;CURF CRVU CFUR CDLB CLBD CBDL;CR CU;CRUB CUBR CBRU CLDF CDFL CFLD;CR CB;CBUL CULB CLBU CFDR CDRF CRFD;CL CU;CLFO CULF CFUL CRBD CDRB CBDR;CR CD;CFRU CUFR CRUF CBLD CDBL CLDB;CL CB;CBUR CRBU CURB CFDL CLFD CDLF;CL CD;CLUB CBLU CUBL CRDF CFRD CDFR;CR CF", ";", false);
    while (stringTokenizer.hasMoreTokens()) {
      StringTokenizer stringTokenizer1 = new StringTokenizer(stringTokenizer.nextToken());
      String str = stringTokenizer.nextToken();
      while (stringTokenizer1.hasMoreTokens())
        hashtable.put(stringTokenizer1.nextToken(), str); 
    } 
    return hashtable;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\BandelowENGParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */