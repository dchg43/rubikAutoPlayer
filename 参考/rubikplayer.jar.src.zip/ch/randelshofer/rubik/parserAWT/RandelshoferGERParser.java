package ch.randelshofer.rubik.parserAWT;

import java.util.Hashtable;
import java.util.StringTokenizer;

public class RandelshoferGERParser extends ScriptParser {
  private static final String COMPRESSED_TOKENS = "R;O;V;L;U;H;R-;O-;V-;L-;U-;H-;R2;O2;V2;L2;U2;H2;R2-;O2-;V2-;L2-;U2-;H2-;;;;;;;;;;;;;;;;;;;;;;;;;MR;MO;MV;ML;MU;MH;MR2;MO2;MV2;ML2;MU2;MH2;;;;;;;;;;;;;BR;BO;BV;BL;BU;BH;BR2;BO2;BV2;BL2;BU2;BH2;.;r;o;v;l;u;h;+;-;++;;-;;( [ {;) ] };,;(;);;;;;;;;;/*;*/;//;";
  
  public RandelshoferGERParser() {
    super(getTokens(), new Hashtable(), 1, 1, -1, -1, -1, true);
  }
  
  private static String[] getTokens() {
    String[] arrayOfString = new String[113];
    byte b = 0;
    StringTokenizer stringTokenizer = new StringTokenizer("R;O;V;L;U;H;R-;O-;V-;L-;U-;H-;R2;O2;V2;L2;U2;H2;R2-;O2-;V2-;L2-;U2-;H2-;;;;;;;;;;;;;;;;;;;;;;;;;MR;MO;MV;ML;MU;MH;MR2;MO2;MV2;ML2;MU2;MH2;;;;;;;;;;;;;BR;BO;BV;BL;BU;BH;BR2;BO2;BV2;BL2;BU2;BH2;.;r;o;v;l;u;h;+;-;++;;-;;( [ {;) ] };,;(;);;;;;;;;;/*;*/;//;", ";", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals(";")) {
        b++;
        continue;
      } 
      arrayOfString[b] = str;
    } 
    return arrayOfString;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\RandelshoferGERParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */