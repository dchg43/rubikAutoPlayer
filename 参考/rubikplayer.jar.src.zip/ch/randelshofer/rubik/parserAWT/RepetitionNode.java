package ch.randelshofer.rubik.parserAWT;

import ch.randelshofer.util.ReverseVectorEnumeration;
import ch.randelshofer.util.SingletonEnumeration;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Vector;

public class RepetitionNode extends ScriptNode {
  int repeatCount = 1;
  
  public RepetitionNode() {}
  
  public RepetitionNode(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public void setRepeatCount(int paramInt) {
    this.repeatCount = paramInt;
  }
  
  public int getRepeatCount() {
    return this.repeatCount;
  }
  
  public int getSymbol() {
    return 118;
  }
  
  public int getFullTurnCount() {
    return super.getFullTurnCount() * this.repeatCount;
  }
  
  public int getQuarterTurnCount() {
    return super.getQuarterTurnCount() * this.repeatCount;
  }
  
  public Enumeration resolvedEnumeration(boolean paramBoolean) {
    return new ResolvedEnumeration(this, paramBoolean, this.repeatCount);
  }
  
  public Enumeration enumerateChildrenReversed() {
    return (Enumeration)new ReverseVectorEnumeration(this.children);
  }
  
  private static class ResolvedEnumeration implements Enumeration {
    protected RepetitionNode root;
    
    protected Enumeration children;
    
    protected Enumeration subtree;
    
    protected Vector cachedChildren;
    
    boolean inverse;
    
    int repeatCount;
    
    public ResolvedEnumeration(RepetitionNode param1RepetitionNode, boolean param1Boolean, int param1Int) {
      this.root = param1RepetitionNode;
      this.inverse = param1Boolean;
      this.repeatCount = param1Int;
      this.cachedChildren = new Vector();
      this.children = param1Boolean ? this.root.enumerateChildrenReversed() : this.root.children();
      while (this.children.hasMoreElements())
        this.cachedChildren.addElement(this.children.nextElement()); 
      this.children = this.cachedChildren.elements();
      this.subtree = (Enumeration)new SingletonEnumeration(this.root.clone());
    }
    
    public boolean hasMoreElements() {
      return (this.subtree.hasMoreElements() || this.children.hasMoreElements() || this.repeatCount > 1);
    }
    
    public Object nextElement() {
      Object object;
      if (this.subtree.hasMoreElements()) {
        object = this.subtree.nextElement();
      } else if (this.children.hasMoreElements()) {
        this.subtree = ((ScriptNode)this.children.nextElement()).resolvedEnumeration(this.inverse);
        object = this.subtree.nextElement();
        if (!this.children.hasMoreElements() && this.repeatCount > 1) {
          this.repeatCount--;
          this.children = this.cachedChildren.elements();
        } 
      } else {
        throw new NoSuchElementException();
      } 
      return object;
    }
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\RepetitionNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */