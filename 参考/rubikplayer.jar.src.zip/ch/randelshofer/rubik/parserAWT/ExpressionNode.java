package ch.randelshofer.rubik.parserAWT;

public class ExpressionNode extends ScriptNode {
  public ExpressionNode() {}
  
  public ExpressionNode(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public int getSymbol() {
    return 115;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\ExpressionNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */