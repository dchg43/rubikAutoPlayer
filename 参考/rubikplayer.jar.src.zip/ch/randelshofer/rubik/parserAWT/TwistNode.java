package ch.randelshofer.rubik.parserAWT;

import ch.randelshofer.rubik.RubiksCubeCore;
import ch.randelshofer.util.SingletonEnumeration;
import java.util.Enumeration;

public class TwistNode extends ScriptNode {
  private int symbol = 84;
  
  public TwistNode() {
    setAllowsChildren(false);
  }
  
  public TwistNode(int paramInt) {
    setAllowsChildren(false);
  }
  
  public TwistNode(int paramInt1, int paramInt2, int paramInt3) {
    super(paramInt2, paramInt3);
    setAllowsChildren(false);
  }
  
  public int getSymbol() {
    return this.symbol;
  }
  
  public void setSymbol(int paramInt) {
    this.symbol = paramInt;
  }
  
  public void applyTo(RubiksCubeCore paramRubiksCubeCore) {
    applyTo(paramRubiksCubeCore, false);
  }
  
  public void applyTo(RubiksCubeCore paramRubiksCubeCore, boolean paramBoolean) {
    ScriptParser.applyTo(paramRubiksCubeCore, this.symbol, paramBoolean);
  }
  
  public void applyInverseTo(RubiksCubeCore paramRubiksCubeCore) {
    applyTo(paramRubiksCubeCore, true);
  }
  
  public int getFullTurnCount() {
    int i = ScriptParser.getLayerMask(this.symbol);
    return (i != 0 && i != 7) ? 1 : 0;
  }
  
  public int getQuarterTurnCount() {
    int i = ScriptParser.getLayerMask(this.symbol);
    int j = Math.abs(ScriptParser.getAngle(this.symbol));
    return (i != 0 && i != 7) ? ((i == 2) ? (j * 2) : j) : 0;
  }
  
  public void append(ScriptParser paramScriptParser, StringBuffer paramStringBuffer) {
    paramStringBuffer.append(paramScriptParser.getFirstToken(this.symbol));
  }
  
  public Enumeration resolvedEnumeration(boolean paramBoolean) {
    if (paramBoolean) {
      TwistNode twistNode = (TwistNode)clone();
      twistNode.inverse();
      return (Enumeration)new SingletonEnumeration(twistNode);
    } 
    return (Enumeration)new SingletonEnumeration(this);
  }
  
  public void transform(int paramInt) {
    this.symbol = ScriptParser.transformSymbol(paramInt, this.symbol);
  }
  
  public void inverse() {
    this.symbol = ScriptParser.inverseSymbol(this.symbol);
  }
  
  public void reflect() {
    this.symbol = ScriptParser.reflectSymbol(this.symbol);
  }
  
  public boolean isRotationSymbol() {
    return ScriptParser.isRotationSymbol(this.symbol);
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\TwistNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */