package ch.randelshofer.rubik.parserAWT;

import ch.randelshofer.gui.tree.DefaultMutableTreeNode;
import ch.randelshofer.io.ParseException;
import java.io.IOException;
import java.io.StringReader;
import java.util.Enumeration;

public class MacroNode extends ScriptNode {
  private String identifier;
  
  private String script;
  
  private ScriptParser parser;
  
  public void transform(int paramInt) {
    this.identifier = null;
    super.transform(paramInt);
  }
  
  public String getIdentifier() {
    return this.identifier;
  }
  
  public int getSymbol() {
    return 114;
  }
  
  public MacroNode(String paramString1, String paramString2, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    this.identifier = paramString1;
    this.script = paramString2;
    setAllowsChildren(true);
  }
  
  public void expand(ScriptParser paramScriptParser) throws IOException {
    if (getChildCount() > 0)
      return; 
    for (DefaultMutableTreeNode defaultMutableTreeNode = getParent(); defaultMutableTreeNode != null; defaultMutableTreeNode = defaultMutableTreeNode.getParent()) {
      if (defaultMutableTreeNode instanceof MacroNode && ((MacroNode)defaultMutableTreeNode).identifier.equals(this.identifier))
        throw new ParseException("Macro: Illegal Recursion", getStartPosition(), getEndPosition()); 
    } 
    int i = getStartPosition();
    int j = getEndPosition();
    paramScriptParser.parse(new StringReader(this.script), this);
    Enumeration enumeration = breadthFirstEnumeration();
    while (enumeration.hasMoreElements()) {
      ScriptNode scriptNode = enumeration.nextElement();
      scriptNode.setStartPosition(i);
      scriptNode.setEndPosition(j);
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\MacroNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */