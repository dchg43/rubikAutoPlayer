package ch.randelshofer.rubik.parserAWT;

import ch.randelshofer.gui.tree.DefaultMutableTreeNode;
import ch.randelshofer.rubik.RubiksCubeCore;
import ch.randelshofer.util.ReverseVectorEnumeration;
import ch.randelshofer.util.SingletonEnumeration;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Vector;

public class ScriptNode extends DefaultMutableTreeNode {
  protected int startpos;
  
  protected int endpos;
  
  private static final int[][] orientationToSymbolMap = new int[][] { 
      {}, { 72 }, { 78 }, { 75 }, { 73 }, { 79 }, { 76 }, { 74 }, { 80 }, { 77 }, 
      { 72, 73 }, { 72, 79 }, { 72, 76 }, { 78, 73 }, { 78, 76 }, { 75, 73 }, { 75, 79 }, { 75, 76 }, { 72, 74 }, { 72, 77 }, 
      { 78, 74 }, { 78, 77 }, { 75, 74 }, { 75, 77 } };
  
  public ScriptNode() {
    setAllowsChildren(true);
  }
  
  public ScriptNode(int paramInt1, int paramInt2) {
    this.startpos = paramInt1;
    this.endpos = paramInt2;
    setAllowsChildren(true);
  }
  
  public int getStartPosition() {
    return this.startpos;
  }
  
  public void setStartPosition(int paramInt) {
    this.startpos = paramInt;
  }
  
  public int getEndPosition() {
    return this.endpos;
  }
  
  public void setEndPosition(int paramInt) {
    this.endpos = paramInt;
  }
  
  public void applyTo(RubiksCubeCore paramRubiksCubeCore) {}
  
  public void applySubtreeTo(RubiksCubeCore paramRubiksCubeCore, boolean paramBoolean) {
    Enumeration enumeration = resolvedEnumeration(paramBoolean);
    while (enumeration.hasMoreElements())
      ((ScriptNode)enumeration.nextElement()).applyTo(paramRubiksCubeCore); 
  }
  
  public void applyInverseTo(RubiksCubeCore paramRubiksCubeCore) {}
  
  public int getSymbol() {
    return 113;
  }
  
  public void transform(int paramInt) {
    Enumeration enumeration = children();
    while (enumeration.hasMoreElements()) {
      ScriptNode scriptNode = enumeration.nextElement();
      scriptNode.transform(paramInt);
    } 
  }
  
  public void transformOrientation(int paramInt) {
    if (paramInt >= 1) {
      if ((orientationToSymbolMap[paramInt]).length == 2) {
        SequenceNode sequenceNode = new SequenceNode();
        sequenceNode.add(new TwistNode(orientationToSymbolMap[paramInt][0]));
        sequenceNode.add(new TwistNode(orientationToSymbolMap[paramInt][1]));
        insert(sequenceNode, 0);
      } else {
        insert(new TwistNode(orientationToSymbolMap[paramInt][0]), 0);
      } 
      insert(new TwistNode(84), 1);
    } 
  }
  
  public void inverse() {
    if (this.children != null) {
      Enumeration enumeration = enumerateChildrenReversed();
      this.children = new Vector();
      while (enumeration.hasMoreElements()) {
        ScriptNode scriptNode = enumeration.nextElement();
        scriptNode.inverse();
        this.children.addElement(scriptNode);
      } 
    } 
  }
  
  public void reflect() {
    if (this.children != null) {
      Enumeration enumeration = children();
      while (enumeration.hasMoreElements()) {
        ScriptNode scriptNode = enumeration.nextElement();
        scriptNode.reflect();
      } 
    } 
  }
  
  public Enumeration resolvedEnumeration(boolean paramBoolean) {
    return new ResolvedEnumeration(this, paramBoolean);
  }
  
  public Enumeration enumerateChildrenReversed() {
    return (Enumeration)new ReverseVectorEnumeration(this.children);
  }
  
  public int getFullTurnCount() {
    int i = 0;
    Enumeration enumeration = children();
    while (enumeration.hasMoreElements())
      i += ((ScriptNode)enumeration.nextElement()).getFullTurnCount(); 
    return i;
  }
  
  public int getQuarterTurnCount() {
    int i = 0;
    Enumeration enumeration = children();
    while (enumeration.hasMoreElements())
      i += ((ScriptNode)enumeration.nextElement()).getQuarterTurnCount(); 
    return i;
  }
  
  public ScriptNode cloneSubtree() {
    ScriptNode scriptNode = (ScriptNode)clone();
    Enumeration enumeration = children();
    while (enumeration.hasMoreElements()) {
      ScriptNode scriptNode1 = enumeration.nextElement();
      scriptNode.add(scriptNode1.cloneSubtree());
    } 
    return scriptNode;
  }
  
  private static class ResolvedEnumeration implements Enumeration {
    protected ScriptNode root;
    
    protected Enumeration children;
    
    protected Enumeration subtree;
    
    boolean inverse;
    
    public ResolvedEnumeration(ScriptNode param1ScriptNode, boolean param1Boolean) {
      this.root = param1ScriptNode;
      this.inverse = param1Boolean;
      this.children = param1Boolean ? this.root.enumerateChildrenReversed() : this.root.children();
      this.subtree = (Enumeration)new SingletonEnumeration(this.root.clone());
    }
    
    public boolean hasMoreElements() {
      return (this.subtree.hasMoreElements() || this.children.hasMoreElements());
    }
    
    public Object nextElement() {
      Object object;
      if (this.subtree.hasMoreElements()) {
        object = this.subtree.nextElement();
      } else if (this.children.hasMoreElements()) {
        this.subtree = ((ScriptNode)this.children.nextElement()).resolvedEnumeration(this.inverse);
        object = this.subtree.nextElement();
      } else {
        throw new NoSuchElementException();
      } 
      return object;
    }
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\ScriptNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */