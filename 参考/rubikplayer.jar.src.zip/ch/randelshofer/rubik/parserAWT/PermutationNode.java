package ch.randelshofer.rubik.parserAWT;

import ch.randelshofer.rubik.RubiksCubeCore;
import ch.randelshofer.util.SingletonEnumeration;
import java.util.Enumeration;
import java.util.Vector;

public class PermutationNode extends ScriptNode {
  private Vector sequence = new Vector();
  
  private int sign = -1;
  
  private int type = -1;
  
  public static final int SIDE_PERMUTATION = 1;
  
  public static final int EDGE_PERMUTATION = 2;
  
  public static final int CORNER_PERMUTATION = 3;
  
  public static final int UNDEFINED = -1;
  
  private static final int[][] SIDE_SYMBOLS = new int[][] { { 87 }, { 85 }, { 89 }, { 90 }, { 88 }, { 86 } };
  
  private static final int[][] EDGE_SYMBOLS = new int[][] { 
      { 87, 86 }, { 88, 87 }, { 87, 89 }, { 86, 85 }, { 85, 87 }, { 89, 85 }, { 90, 86 }, { 85, 90 }, { 90, 89 }, { 86, 88 }, 
      { 88, 90 }, { 89, 88 } };
  
  private static final int[][] CORNER_SYMBOLS = new int[][] { { 86, 87, 88 }, { 89, 88, 87 }, { 86, 85, 87 }, { 89, 87, 85 }, { 86, 90, 85 }, { 89, 85, 90 }, { 86, 88, 90 }, { 89, 90, 88 } };
  
  public PermutationNode() {
    setAllowsChildren(false);
  }
  
  public PermutationNode(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    setAllowsChildren(false);
  }
  
  public int getSymbol() {
    return 119;
  }
  
  public int getFullTurnCount() {
    return 0;
  }
  
  public int getQuarterTurnCount() {
    return 0;
  }
  
  public void addPermItem(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    byte b1;
    int j;
    int k;
    int m;
    byte b2;
    byte b3;
    if (this.type == -1)
      this.type = paramInt1; 
    if (this.type != paramInt1)
      throw new IllegalArgumentException("Permutation of different part types is not supported."); 
    switch (paramInt2) {
      case 92:
        b1 = 1;
        break;
      case 93:
        b1 = 2;
        break;
      case 91:
        b1 = 3;
        break;
      default:
        b1 = 0;
        break;
    } 
    if (b1 == 3)
      if (paramInt1 == 3) {
        b1 = 2;
      } else if (paramInt1 == 2) {
        b1 = 1;
      }  
    if (this.sequence.size() == 0) {
      this.sign = b1;
    } else if (paramInt1 != 1 && b1 != 0) {
      throw new IllegalArgumentException("Illegal sign.");
    } 
    PermutationItem permutationItem = new PermutationItem();
    byte b = -1;
    switch (paramInt1) {
      case 1:
        switch (paramArrayOfint[0]) {
          case 85:
            b = 1;
            break;
          case 86:
            b = 5;
            break;
          case 90:
            b = 3;
            break;
          case 88:
            b = 4;
            break;
          case 89:
            b = 2;
            break;
          case 87:
            b = 0;
            break;
        } 
        permutationItem.location = b;
        permutationItem.orientation = (this.sequence.size() == 0) ? 0 : b1;
        break;
      case 2:
        if (paramInt2 != 0 && paramInt2 != 91)
          throw new IllegalArgumentException("Illegal sign for edge part."); 
        i = Math.min(paramArrayOfint[0], paramArrayOfint[1]);
        j = Math.max(paramArrayOfint[0], paramArrayOfint[1]);
        k = paramArrayOfint[0];
        m = 0;
        if (i == 86 && j == 87) {
          b = 0;
          m = (k == 86) ? 1 : 0;
        } else if (i == 87 && j == 88) {
          b = 1;
          m = (k == 87) ? 1 : 0;
        } else if (i == 87 && j == 89) {
          b = 2;
          m = (k == 89) ? 1 : 0;
        } else if (i == 85 && j == 86) {
          b = 3;
          m = (k == 85) ? 1 : 0;
        } else if (i == 85 && j == 87) {
          b = 4;
          m = (k == 87) ? 1 : 0;
        } else if (i == 85 && j == 89) {
          b = 5;
          m = (k == 85) ? 1 : 0;
        } else if (i == 86 && j == 90) {
          b = 6;
          m = (k == 86) ? 1 : 0;
        } else if (i == 85 && j == 90) {
          b = 7;
          m = (k == 90) ? 1 : 0;
        } else if (i == 89 && j == 90) {
          b = 8;
          m = (k == 89) ? 1 : 0;
        } else if (i == 86 && j == 88) {
          b = 9;
          m = (k == 88) ? 1 : 0;
        } else if (i == 88 && j == 90) {
          b = 10;
          m = (k == 90) ? 1 : 0;
        } else if (i == 88 && j == 89) {
          b = 11;
          m = (k == 88) ? 1 : 0;
        } else {
          throw new IllegalArgumentException("Impossible edge part.");
        } 
        permutationItem.location = b;
        permutationItem.orientation = m ? 1 : 0;
        break;
      case 3:
        if (paramInt2 == 93)
          throw new IllegalArgumentException("Illegal sign for corner part."); 
        i = paramArrayOfint[0];
        j = paramArrayOfint[1];
        k = paramArrayOfint[2];
        if (i > j) {
          m = j;
          j = i;
          i = m;
        } 
        if (i > k) {
          m = k;
          k = i;
          i = m;
        } 
        if (j > k) {
          m = k;
          k = j;
          j = m;
        } 
        b2 = 0;
        if (i == 86 && j == 87 && k == 88) {
          b = 0;
          if (paramArrayOfint[0] == 86) {
            b2 = (paramArrayOfint[1] == 87) ? 0 : 3;
          } else if (paramArrayOfint[0] == 87) {
            b2 = (paramArrayOfint[1] == 88) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 86) ? 1 : 4;
          } 
        } else if (i == 87 && j == 88 && k == 89) {
          b = 1;
          if (paramArrayOfint[0] == 89) {
            b2 = (paramArrayOfint[1] == 88) ? 0 : 3;
          } else if (paramArrayOfint[0] == 88) {
            b2 = (paramArrayOfint[1] == 87) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 89) ? 1 : 4;
          } 
        } else if (i == 85 && j == 86 && k == 87) {
          b = 2;
          if (paramArrayOfint[0] == 86) {
            b2 = (paramArrayOfint[1] == 85) ? 0 : 3;
          } else if (paramArrayOfint[0] == 85) {
            b2 = (paramArrayOfint[1] == 87) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 86) ? 1 : 4;
          } 
        } else if (i == 85 && j == 87 && k == 89) {
          b = 3;
          if (paramArrayOfint[0] == 89) {
            b2 = (paramArrayOfint[1] == 87) ? 0 : 3;
          } else if (paramArrayOfint[0] == 87) {
            b2 = (paramArrayOfint[1] == 85) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 89) ? 1 : 4;
          } 
        } else if (i == 85 && j == 86 && k == 90) {
          if (paramArrayOfint[0] == 86) {
            b2 = (paramArrayOfint[1] == 90) ? 0 : 3;
          } else if (paramArrayOfint[0] == 90) {
            b2 = (paramArrayOfint[1] == 85) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 86) ? 1 : 4;
          } 
          b = 4;
        } else if (i == 85 && j == 89 && k == 90) {
          b = 5;
          if (paramArrayOfint[0] == 89) {
            b2 = (paramArrayOfint[1] == 85) ? 0 : 3;
          } else if (paramArrayOfint[0] == 85) {
            b2 = (paramArrayOfint[1] == 90) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 89) ? 1 : 4;
          } 
        } else if (i == 86 && j == 88 && k == 90) {
          b = 6;
          if (paramArrayOfint[0] == 86) {
            b2 = (paramArrayOfint[1] == 88) ? 0 : 3;
          } else if (paramArrayOfint[0] == 88) {
            b2 = (paramArrayOfint[1] == 90) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 86) ? 1 : 4;
          } 
        } else if (i == 88 && j == 89 && k == 90) {
          b = 7;
          if (paramArrayOfint[0] == 89) {
            b2 = (paramArrayOfint[1] == 90) ? 0 : 3;
          } else if (paramArrayOfint[0] == 90) {
            b2 = (paramArrayOfint[1] == 88) ? 2 : 5;
          } else {
            b2 = (paramArrayOfint[1] == 89) ? 1 : 4;
          } 
        } else {
          throw new IllegalArgumentException("Impossible corner part.");
        } 
        permutationItem.location = b;
        permutationItem.orientation = b2;
        for (b3 = 0; b3 < this.sequence.size(); b3++) {
          PermutationItem permutationItem1 = this.sequence.elementAt(b3);
          if (permutationItem1.orientation / 3 != permutationItem.orientation / 3)
            throw new IllegalArgumentException("Corner permutation cannot be clockwise and anticlockwise at the same time."); 
        } 
        break;
    } 
    for (int i = 0; i < this.sequence.size(); i++) {
      PermutationItem permutationItem1 = this.sequence.elementAt(i);
      if (permutationItem1.location == permutationItem.location)
        throw new IllegalArgumentException("Illegal multiple occurence of same part."); 
    } 
    this.sequence.addElement(permutationItem);
  }
  
  public int getPermItemCount() {
    return this.sequence.size();
  }
  
  public void applyTo(RubiksCubeCore paramRubiksCubeCore, boolean paramBoolean) {
    if (paramBoolean) {
      applyInverseTo(paramRubiksCubeCore);
    } else {
      applyTo(paramRubiksCubeCore);
    } 
  }
  
  public void applyTo(RubiksCubeCore paramRubiksCubeCore) {
    int[] arrayOfInt1 = null;
    int[] arrayOfInt2 = null;
    PermutationItem[] arrayOfPermutationItem = new PermutationItem[this.sequence.size()];
    int i;
    for (i = 0; i < arrayOfPermutationItem.length; i++)
      arrayOfPermutationItem[i] = this.sequence.elementAt(i); 
    byte b = 0;
    switch (this.type) {
      case 1:
        b = 4;
        arrayOfInt1 = paramRubiksCubeCore.getSideLocations();
        arrayOfInt2 = paramRubiksCubeCore.getSideOrientations();
        break;
      case 3:
        b = 3;
        arrayOfInt1 = paramRubiksCubeCore.getCornerLocations();
        arrayOfInt2 = paramRubiksCubeCore.getCornerOrientations();
        break;
      case 2:
        b = 2;
        arrayOfInt1 = paramRubiksCubeCore.getEdgeLocations();
        arrayOfInt2 = paramRubiksCubeCore.getEdgeOrientations();
        break;
    } 
    for (i = 0; i < arrayOfPermutationItem.length - 1; i++) {
      int n = ((arrayOfPermutationItem[i + 1]).orientation - (arrayOfPermutationItem[i]).orientation + arrayOfInt2[(arrayOfPermutationItem[i]).location]) % b;
      arrayOfInt2[(arrayOfPermutationItem[i]).location] = (n < 0) ? (b + n) : n;
    } 
    int j = (this.sign + (arrayOfPermutationItem[0]).orientation - (arrayOfPermutationItem[i]).orientation + arrayOfInt2[(arrayOfPermutationItem[i]).location]) % b;
    arrayOfInt2[(arrayOfPermutationItem[i]).location] = (j < 0) ? (b + j) : j;
    int k = arrayOfInt1[(arrayOfPermutationItem[arrayOfPermutationItem.length - 1]).location];
    int m = arrayOfInt2[(arrayOfPermutationItem[arrayOfPermutationItem.length - 1]).location];
    for (i = arrayOfPermutationItem.length - 1; i > 0; i--) {
      arrayOfInt1[(arrayOfPermutationItem[i]).location] = arrayOfInt1[(arrayOfPermutationItem[i - 1]).location];
      arrayOfInt2[(arrayOfPermutationItem[i]).location] = arrayOfInt2[(arrayOfPermutationItem[i - 1]).location];
    } 
    arrayOfInt1[(arrayOfPermutationItem[0]).location] = k;
    arrayOfInt2[(arrayOfPermutationItem[0]).location] = m;
    switch (this.type) {
      case 1:
        paramRubiksCubeCore.setSides(arrayOfInt1, arrayOfInt2);
        break;
      case 3:
        paramRubiksCubeCore.setCorners(arrayOfInt1, arrayOfInt2);
        break;
      case 2:
        paramRubiksCubeCore.setEdges(arrayOfInt1, arrayOfInt2);
        break;
    } 
  }
  
  public void applyInverseTo(RubiksCubeCore paramRubiksCubeCore) {
    int[] arrayOfInt1 = null;
    int[] arrayOfInt2 = null;
    PermutationItem[] arrayOfPermutationItem = new PermutationItem[this.sequence.size()];
    int i;
    for (i = 0; i < arrayOfPermutationItem.length; i++)
      arrayOfPermutationItem[i] = this.sequence.elementAt(i); 
    byte b = 0;
    switch (this.type) {
      case 1:
        b = 4;
        arrayOfInt1 = paramRubiksCubeCore.getSideLocations();
        arrayOfInt2 = paramRubiksCubeCore.getSideOrientations();
        break;
      case 3:
        b = 3;
        arrayOfInt1 = paramRubiksCubeCore.getCornerLocations();
        arrayOfInt2 = paramRubiksCubeCore.getCornerOrientations();
        break;
      case 2:
        b = 2;
        arrayOfInt1 = paramRubiksCubeCore.getEdgeLocations();
        arrayOfInt2 = paramRubiksCubeCore.getEdgeOrientations();
        break;
    } 
    for (i = arrayOfPermutationItem.length - 1; i > 0; i--) {
      int n = ((arrayOfPermutationItem[i - 1]).orientation - (arrayOfPermutationItem[i]).orientation + arrayOfInt2[(arrayOfPermutationItem[i]).location]) % b;
      arrayOfInt2[(arrayOfPermutationItem[i]).location] = (n < 0) ? (b + n) : n;
    } 
    int j = (-this.sign + (arrayOfPermutationItem[arrayOfPermutationItem.length - 1]).orientation - (arrayOfPermutationItem[i]).orientation + arrayOfInt2[(arrayOfPermutationItem[i]).location]) % b;
    arrayOfInt2[(arrayOfPermutationItem[i]).location] = (j < 0) ? (b + j) : j;
    int k = arrayOfInt1[(arrayOfPermutationItem[0]).location];
    int m = arrayOfInt2[(arrayOfPermutationItem[0]).location];
    for (i = 1; i < arrayOfPermutationItem.length; i++) {
      arrayOfInt1[(arrayOfPermutationItem[i - 1]).location] = arrayOfInt1[(arrayOfPermutationItem[i]).location];
      arrayOfInt2[(arrayOfPermutationItem[i - 1]).location] = arrayOfInt2[(arrayOfPermutationItem[i]).location];
    } 
    arrayOfInt1[(arrayOfPermutationItem[arrayOfPermutationItem.length - 1]).location] = k;
    arrayOfInt2[(arrayOfPermutationItem[arrayOfPermutationItem.length - 1]).location] = m;
    switch (this.type) {
      case 1:
        paramRubiksCubeCore.setSides(arrayOfInt1, arrayOfInt2);
        break;
      case 3:
        paramRubiksCubeCore.setCorners(arrayOfInt1, arrayOfInt2);
        break;
      case 2:
        paramRubiksCubeCore.setEdges(arrayOfInt1, arrayOfInt2);
        break;
    } 
  }
  
  public void inverse() {
    Vector vector = this.sequence;
    this.sequence = new Vector(vector.size());
    if (vector.size() > 0) {
      PermutationItem permutationItem1 = vector.elementAt(0);
      PermutationItem permutationItem2 = new PermutationItem();
      permutationItem2.orientation = permutationItem1.orientation;
      permutationItem2.location = permutationItem1.location;
      this.sequence.addElement(permutationItem2);
    } 
    int i;
    for (i = vector.size() - 1; i >= 1; i--) {
      PermutationItem permutationItem1 = vector.elementAt(i);
      PermutationItem permutationItem2 = new PermutationItem();
      permutationItem2.orientation = permutationItem1.orientation;
      permutationItem2.location = permutationItem1.location;
      this.sequence.addElement(permutationItem2);
    } 
    switch (this.type) {
      case 1:
        if (this.sign != 0) {
          this.sign = 4 - this.sign;
          for (i = 1; i < this.sequence.size(); i++) {
            PermutationItem permutationItem = this.sequence.elementAt(i);
            permutationItem.orientation = (this.sign + permutationItem.orientation) % 4;
          } 
        } 
        break;
      case 3:
        if (this.sign != 0) {
          this.sign = 3 - this.sign;
          for (i = 1; i < this.sequence.size(); i++) {
            PermutationItem permutationItem = this.sequence.elementAt(i);
            permutationItem.orientation = (this.sign + permutationItem.orientation) % 3;
          } 
        } 
        break;
      case 2:
        if (this.sign != 0)
          for (i = 1; i < this.sequence.size(); i++) {
            PermutationItem permutationItem = this.sequence.elementAt(i);
            permutationItem.orientation = this.sign ^ permutationItem.orientation;
          }  
        break;
    } 
  }
  
  public void reflect() {}
  
  public Enumeration resolvedEnumeration(boolean paramBoolean) {
    if (paramBoolean) {
      PermutationNode permutationNode = (PermutationNode)clone();
      permutationNode.inverse();
      return (Enumeration)new SingletonEnumeration(permutationNode);
    } 
    return (Enumeration)new SingletonEnumeration(this);
  }
  
  public void transform(int paramInt) {
    RubiksCubeCore rubiksCubeCore = new RubiksCubeCore();
    int i = ScriptParser.getAxis(paramInt);
    int j = ScriptParser.getLayerMask(paramInt);
    int k = ScriptParser.getAngle(paramInt);
    if (i == -1 || k == 0 || j == -1)
      return; 
    rubiksCubeCore.transform(i, j, k);
    applyTo(rubiksCubeCore);
    rubiksCubeCore.transform(i, j, -k);
    int[] arrayOfInt1 = null;
    int[] arrayOfInt2 = null;
    byte b1 = 0;
    switch (this.type) {
      case 3:
        b1 = 3;
        arrayOfInt1 = rubiksCubeCore.getCornerLocations();
        arrayOfInt2 = rubiksCubeCore.getCornerOrientations();
        break;
      case 2:
        b1 = 2;
        arrayOfInt1 = rubiksCubeCore.getEdgeLocations();
        arrayOfInt2 = rubiksCubeCore.getEdgeOrientations();
        break;
      case 1:
        b1 = 4;
        arrayOfInt1 = rubiksCubeCore.getSideLocations();
        arrayOfInt2 = rubiksCubeCore.getSideOrientations();
        break;
    } 
    this.sequence.removeAllElements();
    boolean[] arrayOfBoolean = new boolean[arrayOfInt1.length];
    byte b2;
    for (b2 = 0; b2 < arrayOfInt1.length && arrayOfInt1[b2] == b2 && arrayOfInt2[b2] == 0; b2++);
    PermutationItem permutationItem = new PermutationItem();
    permutationItem.location = b2;
    permutationItem.orientation = 0;
    this.sequence.addElement(permutationItem);
    arrayOfBoolean[b2] = true;
    int m = 0;
    byte b3;
    for (b3 = 0; arrayOfInt1[b3] != b2; b3++);
    while (!arrayOfBoolean[b3]) {
      arrayOfBoolean[b3] = true;
      m = (b1 + m + arrayOfInt2[b3]) % b1;
      permutationItem = new PermutationItem();
      permutationItem.location = b3;
      permutationItem.orientation = m;
      this.sequence.addElement(permutationItem);
      byte b;
      for (b = 0; arrayOfInt1[b] != b3; b++);
      b3 = b;
    } 
    this.sign = (b1 + m + arrayOfInt2[b2]) % b1;
  }
  
  public Object clone() {
    PermutationNode permutationNode = (PermutationNode)super.clone();
    permutationNode.sequence = new Vector();
    Enumeration enumeration = this.sequence.elements();
    while (enumeration.hasMoreElements())
      permutationNode.sequence.addElement(((PermutationItem)enumeration.nextElement()).clone()); 
    return permutationNode;
  }
  
  private static class PermutationItem implements Cloneable {
    public int orientation;
    
    public int location;
    
    private PermutationItem() {}
    
    public Object clone() {
      try {
        return super.clone();
      } catch (CloneNotSupportedException cloneNotSupportedException) {
        throw new InternalError(cloneNotSupportedException.getMessage());
      } 
    }
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\PermutationNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */