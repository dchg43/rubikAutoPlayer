package ch.randelshofer.rubik.parserAWT;

public class SequenceNode extends ScriptNode {
  public SequenceNode() {}
  
  public SequenceNode(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public int getSymbol() {
    return 116;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\SequenceNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */