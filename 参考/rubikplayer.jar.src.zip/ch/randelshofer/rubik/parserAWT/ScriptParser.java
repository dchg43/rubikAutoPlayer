package ch.randelshofer.rubik.parserAWT;

import ch.randelshofer.io.ParseException;
import ch.randelshofer.io.StreamPosTokenizer;
import ch.randelshofer.rubik.RubiksCubeCore;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class ScriptParser {
  public static final int POSITION_UNSUPPORTED = -1;
  
  public static final int POSITION_PREFIX = 0;
  
  public static final int POSITION_SUFFIX = 1;
  
  public static final int POSITION_HEADER = 2;
  
  private boolean DEBUG = false;
  
  private String[][] tokens;
  
  private Hashtable transformationMap = new Hashtable();
  
  private Hashtable permutationMap = new Hashtable();
  
  private Hashtable macroMap = new Hashtable();
  
  private int commutatorPos = -1;
  
  private int conjugatorPos = -1;
  
  private int invertorPos = -1;
  
  private int repetitorPos = -1;
  
  private int reflectorPos = -1;
  
  private boolean isSequenceSupported;
  
  private boolean isAmbiguousSeqBeginPermBegin;
  
  private boolean isAmbiguousSeqBeginCmtrBegin;
  
  private boolean isAmbiguousSeqBeginCngrBegin;
  
  private boolean isAmbiguousCngrBeginCmtrBegin;
  
  private boolean isAmbiguousCngrDelimCmtrDelim;
  
  private boolean isAmbiguousCngrBeginPermBegin;
  
  private boolean isAmbiguousCmtrBeginPermBegin;
  
  private boolean isAmbiguousSeqEndCmtrEnd;
  
  private boolean isAmbiguousSeqEndCngrEnd;
  
  private boolean isAmbiguousCngrEndCmtrEnd;
  
  public static final int R = 0;
  
  public static final int U = 1;
  
  public static final int F = 2;
  
  public static final int L = 3;
  
  public static final int D = 4;
  
  public static final int B = 5;
  
  public static final int Ri = 6;
  
  public static final int Ui = 7;
  
  public static final int Fi = 8;
  
  public static final int Li = 9;
  
  public static final int Di = 10;
  
  public static final int Bi = 11;
  
  public static final int R2 = 12;
  
  public static final int U2 = 13;
  
  public static final int F2 = 14;
  
  public static final int L2 = 15;
  
  public static final int D2 = 16;
  
  public static final int B2 = 17;
  
  public static final int R2i = 18;
  
  public static final int U2i = 19;
  
  public static final int F2i = 20;
  
  public static final int L2i = 21;
  
  public static final int D2i = 22;
  
  public static final int B2i = 23;
  
  public static final int TR = 24;
  
  public static final int TU = 25;
  
  public static final int TF = 26;
  
  public static final int TL = 27;
  
  public static final int TD = 28;
  
  public static final int TB = 29;
  
  public static final int TRi = 30;
  
  public static final int TUi = 31;
  
  public static final int TFi = 32;
  
  public static final int TLi = 33;
  
  public static final int TDi = 34;
  
  public static final int TBi = 35;
  
  public static final int TR2 = 36;
  
  public static final int TU2 = 37;
  
  public static final int TF2 = 38;
  
  public static final int TL2 = 39;
  
  public static final int TD2 = 40;
  
  public static final int TB2 = 41;
  
  public static final int TR2i = 42;
  
  public static final int TU2i = 43;
  
  public static final int TF2i = 44;
  
  public static final int TL2i = 45;
  
  public static final int TD2i = 46;
  
  public static final int TB2i = 47;
  
  public static final int MR = 48;
  
  public static final int MU = 49;
  
  public static final int FB = 50;
  
  public static final int ML = 51;
  
  public static final int MD = 52;
  
  public static final int BF = 53;
  
  public static final int MR2 = 54;
  
  public static final int MU2 = 55;
  
  public static final int MF2 = 56;
  
  public static final int ML2 = 57;
  
  public static final int MD2 = 58;
  
  public static final int MB2 = 59;
  
  public static final int SR = 60;
  
  public static final int SU = 61;
  
  public static final int SB = 62;
  
  public static final int SL = 63;
  
  public static final int SD = 64;
  
  public static final int SF = 65;
  
  public static final int SR2 = 66;
  
  public static final int SU2 = 67;
  
  public static final int SF2 = 68;
  
  public static final int SL2 = 69;
  
  public static final int SD2 = 70;
  
  public static final int SB2 = 71;
  
  public static final int CR = 72;
  
  public static final int CU = 73;
  
  public static final int CF = 74;
  
  public static final int CL = 75;
  
  public static final int CD = 76;
  
  public static final int CB = 77;
  
  public static final int CR2 = 78;
  
  public static final int CU2 = 79;
  
  public static final int CF2 = 80;
  
  public static final int CL2 = 81;
  
  public static final int CD2 = 82;
  
  public static final int CB2 = 83;
  
  public static final int NOP = 84;
  
  private static final int TWIST_FIRST_TOKEN = 0;
  
  private static final int TWIST_LAST_TOKEN = 84;
  
  private static final int FACE_FIRST_TOKEN = 0;
  
  private static final int FACE_LAST_TOKEN = 23;
  
  private static final int TWOLAYER_FIRST_TOKEN = 24;
  
  private static final int TWOLAYER_LAST_TOKEN = 47;
  
  private static final int MIDLAYER_FIRST_TOKEN = 48;
  
  private static final int MIDLAYER_LAST_TOKEN = 59;
  
  private static final int SLICE_FIRST_TOKEN = 60;
  
  private static final int SLICE_LAST_TOKEN = 71;
  
  private static final int ROTATION_FIRST_TOKEN = 72;
  
  private static final int ROTATION_LAST_TOKEN = 83;
  
  public static final int PR = 85;
  
  public static final int PU = 86;
  
  public static final int PF = 87;
  
  public static final int PL = 88;
  
  public static final int PD = 89;
  
  public static final int PB = 90;
  
  public static final int PPLUS = 91;
  
  public static final int PMINUS = 92;
  
  public static final int PPLUSPLUS = 93;
  
  private static final int PERMUTATION_FIRST_TOKEN = 85;
  
  private static final int PERMUTATION_LAST_TOKEN = 93;
  
  public static final int STATEMENT_DELIMITER = 94;
  
  public static final int INVERTOR = 95;
  
  public static final int REFLECTOR = 96;
  
  public static final int SEQUENCE_BEGIN = 97;
  
  public static final int SEQUENCE_END = 98;
  
  public static final int PERMUTATION_DELIMITER = 99;
  
  public static final int PERMUTATION_BEGIN = 100;
  
  public static final int PERMUTATION_END = 101;
  
  public static final int REPETITOR_BEGIN = 102;
  
  public static final int REPETITOR_END = 103;
  
  public static final int COMMUTATOR_BEGIN = 104;
  
  public static final int COMMUTATOR_END = 105;
  
  public static final int COMMUTATOR_DELIMITER = 106;
  
  public static final int CONJUGATOR_BEGIN = 107;
  
  public static final int CONJUGATOR_END = 108;
  
  public static final int CONJUGATOR_DELIMITER = 109;
  
  public static final int COMMENT_BEGIN = 110;
  
  public static final int COMMENT_END = 111;
  
  public static final int SINGLE_LINE_COMMENT_BEGIN = 112;
  
  public static final int TOKEN_COUNT = 113;
  
  public static final int SCRIPT_EXPRESSION = 113;
  
  public static final int MACRO_EXPRESSION = 114;
  
  public static final int STATEMENT_EXPRESSION = 115;
  
  public static final int SEQUENCE_EXPRESSION = 116;
  
  public static final int INVERSION_EXPRESSION = 117;
  
  public static final int REPETITION_EXPRESSION = 118;
  
  public static final int PERMUTATION_EXPRESSION = 119;
  
  public static final int COMMUTATION_EXPRESSION = 120;
  
  public static final int CONJUGATION_EXPRESSION = 121;
  
  public static final int REFLECTION_EXPRESSION = 122;
  
  private static String[] defaultTokens;
  
  private static final String COMPRESSED_TOKENS = "R;U;F;L;D;B;Ri;Ui;Fi;Li;Di;Bi;R2;U2;F2;L2;D2;B2;R2i;U2i;F2i;L2i;D2i;B2i;TR;TU;TF;TL;TD;TB;TRi;TUi;TFi;TLi;TDi;TBi;TR2;TU2;TF2;TL2;TD2;TB2;TR2i;TU2i;TF2i;TL2i;TD2i;TB2i;MR;MU;MF;ML;MD;MB;MR2;MU2;MF2;ML2;MD2;MB2;SR;SU;SF;SL;SD;SB;SR2;SU2;SF2;SL2;SD2;SB2;CR;CU;CF;CL;CD;CB;CR2;CU2;CF2;CL2;CD2;CB2;NOP;permR;permU;permB;permL;permD;permF;permPlus;permMinus;permPlusPlus;statementDelimiter;invertor;reflector;sequenceBegin;sequenceEnd;permutationDelimiter;permutationBegin;permutationEnd;repetitorBegin;repetitorEnd;commutatorBegin;commutatorEnd;commutatorDelimiter;conjugatorBegin;conjugatorEnd;conjugatorDelimiter;commentBegin;commentEnd;singleLineCommentBegin;";
  
  public ScriptParser() {
    this(getDefaultTokens(), 1, 1, -1, 0, 0);
  }
  
  public ScriptParser(String[] paramArrayOfString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    this(paramArrayOfString, null, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, true);
  }
  
  public ScriptParser(String[] paramArrayOfString, Hashtable paramHashtable, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean) {
    if (paramHashtable != null)
      this.macroMap = paramHashtable; 
    this.isSequenceSupported = paramBoolean;
    this.repetitorPos = paramInt1;
    this.invertorPos = paramInt2;
    this.reflectorPos = paramInt3;
    this.conjugatorPos = paramInt4;
    this.commutatorPos = paramInt5;
    this.tokens = new String[paramArrayOfString.length][0];
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b] != null) {
        Integer integer = new Integer(b);
        StringTokenizer stringTokenizer = new StringTokenizer(paramArrayOfString[b], " ", false);
        this.tokens[b] = new String[stringTokenizer.countTokens()];
        for (byte b1 = 0; b1 < (this.tokens[b]).length; b1++) {
          String str = stringTokenizer.nextToken();
          this.tokens[b][b1] = str;
          if (85 <= b && b <= 93) {
            if (str != null)
              this.permutationMap.put(str, integer); 
          } else if (str != null) {
            this.transformationMap.put(str, integer);
          } 
        } 
      } 
    } 
    this.isAmbiguousSeqBeginPermBegin = isAmbiguous(97, 100);
    this.isAmbiguousSeqBeginCmtrBegin = isAmbiguous(97, 104);
    this.isAmbiguousSeqBeginCngrBegin = isAmbiguous(97, 107);
    this.isAmbiguousCngrBeginCmtrBegin = isAmbiguous(104, 107);
    this.isAmbiguousCngrDelimCmtrDelim = isAmbiguous(106, 109);
    this.isAmbiguousCngrBeginPermBegin = isAmbiguous(107, 100);
    this.isAmbiguousCmtrBeginPermBegin = isAmbiguous(104, 100);
    this.isAmbiguousSeqEndCmtrEnd = isAmbiguous(98, 105);
    this.isAmbiguousSeqEndCngrEnd = isAmbiguous(98, 108);
    this.isAmbiguousCngrEndCmtrEnd = isAmbiguous(105, 108);
    if (((this.tokens[110]).length != 0 || (this.tokens[111]).length != 0) && ((this.tokens[110]).length == 0 || (this.tokens[111]).length == 0 || (this.tokens[110]).length != 1 || (this.tokens[111]).length != 1 || this.tokens[110][0].length() < 1 || this.tokens[110][0].length() > 2 || this.tokens[111][0].length() < 1 || this.tokens[111][0].length() > 2))
      throw new IllegalArgumentException("Illegal Comment Tokens " + this.tokens[110] + " " + this.tokens[111]); 
    if ((this.tokens[112]).length != 0 && ((this.tokens[112]).length != 1 || this.tokens[112][0].length() < 1 || this.tokens[112][0].length() > 2)) {
      StringBuffer stringBuffer = new StringBuffer();
      stringBuffer.append("Illegal Single Line Comment Token ");
      for (byte b1 = 0; b1 < (this.tokens[112]).length; b1++) {
        if (b1 > 0)
          stringBuffer.append(','); 
        stringBuffer.append('\'');
        stringBuffer.append(this.tokens[112][b1]);
        stringBuffer.append('\'');
      } 
      throw new IllegalArgumentException(stringBuffer.toString());
    } 
  }
  
  private boolean isAmbiguous(int paramInt1, int paramInt2) {
    String[] arrayOfString1 = this.tokens[paramInt1];
    String[] arrayOfString2 = this.tokens[paramInt2];
    if (arrayOfString1 != null && arrayOfString2 != null)
      for (byte b = 0; b < arrayOfString1.length; b++) {
        if (arrayOfString1[b].length() > 0)
          for (byte b1 = 0; b1 < arrayOfString2.length; b1++) {
            if (arrayOfString1[b].equals(arrayOfString2[b1]))
              return true; 
          }  
      }  
    return false;
  }
  
  public int getInvertorPosition() {
    return this.invertorPos;
  }
  
  public boolean isInversionSupported() {
    return (this.invertorPos != -1);
  }
  
  public boolean isSequenceSupported() {
    return this.isSequenceSupported;
  }
  
  public int getRepetitorPosition() {
    return this.repetitorPos;
  }
  
  public boolean isRepetitionSupported() {
    return (this.repetitorPos != -1);
  }
  
  public boolean isPermutationSupported() {
    return (this.permutationMap.size() > 0);
  }
  
  public ScriptNode parse(String paramString) throws IOException {
    return parse(new StringReader(paramString), null);
  }
  
  public ScriptNode parse(Reader paramReader) throws IOException {
    return parse(paramReader, null);
  }
  
  public ScriptNode parse(Reader paramReader, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG)
      System.out.println("BEGIN PARSE"); 
    StreamPosTokenizer streamPosTokenizer = new StreamPosTokenizer(paramReader);
    streamPosTokenizer.resetSyntax();
    streamPosTokenizer.wordChars(33, 65535);
    streamPosTokenizer.whitespaceChars(0, 32);
    streamPosTokenizer.eolIsSignificant(false);
    if ((this.tokens[110]).length != 0) {
      streamPosTokenizer.slashStarComments(true);
      streamPosTokenizer.setSlashStarTokens(this.tokens[110][0], this.tokens[111][0]);
    } 
    if ((this.tokens[112]).length != 0) {
      streamPosTokenizer.slashSlashComments(true);
      streamPosTokenizer.setSlashSlashToken(this.tokens[112][0]);
    } 
    ScriptNode scriptNode = new ScriptNode();
    if (paramScriptNode != null)
      paramScriptNode.add(scriptNode); 
    scriptNode.setStartPosition(0);
    while (streamPosTokenizer.nextToken() != -1) {
      streamPosTokenizer.pushBack();
      parseExpression(streamPosTokenizer, scriptNode);
    } 
    scriptNode.setEndPosition(streamPosTokenizer.getEndPosition());
    if (this.DEBUG)
      System.out.println("END PARSE"); 
    return scriptNode;
  }
  
  private void printVerbose(StreamPosTokenizer paramStreamPosTokenizer, String paramString, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG) {
      int i = paramScriptNode.getDepth();
      StringBuffer stringBuffer = new StringBuffer();
      while (i-- > 0)
        stringBuffer.append('.'); 
      stringBuffer.append(paramString);
      stringBuffer.append(' ');
      paramStreamPosTokenizer.nextToken();
      stringBuffer.append(paramStreamPosTokenizer.sval);
      paramStreamPosTokenizer.pushBack();
      System.out.println(stringBuffer.toString());
    } 
  }
  
  private ExpressionNode parseExpression(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "expression", paramScriptNode); 
    String str;
    Integer integer;
    if (paramStreamPosTokenizer.nextToken() == -3 && (integer = (Integer)this.transformationMap.get(str = parseGreedy(paramStreamPosTokenizer.sval))) != null && (integer.intValue() == 94 || integer.intValue() == 99)) {
      consumeGreedy(paramStreamPosTokenizer, str);
      return null;
    } 
    paramStreamPosTokenizer.pushBack();
    ExpressionNode expressionNode1 = new ExpressionNode();
    paramScriptNode.add(expressionNode1);
    expressionNode1.setStartPosition(paramStreamPosTokenizer.getStartPosition());
    ExpressionNode expressionNode2 = expressionNode1;
    ScriptNode scriptNode2 = expressionNode1;
    ScriptNode scriptNode1;
    while ((scriptNode1 = parsePrefix(paramStreamPosTokenizer, expressionNode2)) != null)
      scriptNode2 = scriptNode1; 
    ScriptNode scriptNode3 = parseStatement(paramStreamPosTokenizer, scriptNode2);
    expressionNode1.setEndPosition(scriptNode3.getEndPosition());
    ScriptNode scriptNode4 = (ScriptNode)expressionNode1.getChildAt(0);
    ExpressionNode expressionNode3 = expressionNode1;
    ScriptNode scriptNode5;
    while ((scriptNode5 = parseSuffix(paramStreamPosTokenizer, expressionNode1)) != null) {
      scriptNode5.add(scriptNode4);
      scriptNode4 = scriptNode5;
      expressionNode1.setEndPosition(scriptNode5.getEndPosition());
    } 
    return expressionNode1;
  }
  
  private ScriptNode parsePrefix(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "prefix", paramScriptNode); 
    String str2 = null;
    if (paramStreamPosTokenizer.nextToken() != -3) {
      paramStreamPosTokenizer.pushBack();
      return null;
    } 
    String str1;
    Integer integer = (Integer)this.transformationMap.get(str1 = parseGreedy(paramStreamPosTokenizer.sval));
    if (integer == null)
      str2 = parseGreedyInt(paramStreamPosTokenizer.sval); 
    paramStreamPosTokenizer.pushBack();
    if (integer == null && str2 == "\000")
      return null; 
    if (integer == null)
      return (this.repetitorPos == 0) ? parseRepetitor(paramStreamPosTokenizer, paramScriptNode) : null; 
    int i = integer.intValue();
    return (this.invertorPos == 0 && i == 95) ? parseInvertor(paramStreamPosTokenizer, paramScriptNode) : ((this.repetitorPos == 0 && i == 102) ? parseRepetitor(paramStreamPosTokenizer, paramScriptNode) : null);
  }
  
  private ScriptNode parseSuffix(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "suffix", paramScriptNode); 
    String str2 = null;
    if (paramStreamPosTokenizer.nextToken() != -3) {
      paramStreamPosTokenizer.pushBack();
      return null;
    } 
    String str1;
    Integer integer = (Integer)this.transformationMap.get(str1 = parseGreedy(paramStreamPosTokenizer.sval));
    if (integer == null)
      str2 = parseGreedyInt(paramStreamPosTokenizer.sval); 
    paramStreamPosTokenizer.pushBack();
    if (integer == null && str2 == "\000")
      return null; 
    if (integer == null)
      return (this.repetitorPos == 1) ? parseRepetitor(paramStreamPosTokenizer, paramScriptNode) : null; 
    int i = integer.intValue();
    return (this.invertorPos == 1 && i == 95) ? parseInvertor(paramStreamPosTokenizer, paramScriptNode) : ((this.repetitorPos == 1 && i == 102) ? parseRepetitor(paramStreamPosTokenizer, paramScriptNode) : null);
  }
  
  private ScriptNode parseInvertor(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "invertor", paramScriptNode); 
    InversionNode inversionNode = new InversionNode();
    paramScriptNode.add(inversionNode);
    inversionNode.setStartPosition(paramStreamPosTokenizer.getStartPosition());
    if (paramStreamPosTokenizer.nextToken() != -3)
      throw new ParseException("Invertor: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    String str;
    Integer integer = (Integer)this.transformationMap.get(str = parseGreedy(paramStreamPosTokenizer.sval));
    if (integer != null && integer.intValue() == 95) {
      inversionNode.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
      consumeGreedy(paramStreamPosTokenizer, str);
      return inversionNode;
    } 
    throw new ParseException("Invertor: Illegal token " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
  }
  
  private ScriptNode parseRepetitor(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    int j;
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "repetitor", paramScriptNode); 
    RepetitionNode repetitionNode = new RepetitionNode();
    paramScriptNode.add(repetitionNode);
    repetitionNode.setStartPosition(paramStreamPosTokenizer.getStartPosition());
    if (paramStreamPosTokenizer.nextToken() != -3)
      throw new ParseException("Repetitor: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    String str1;
    Integer integer = (Integer)this.transformationMap.get(str1 = parseGreedy(paramStreamPosTokenizer.sval));
    if (integer != null && integer.intValue() == 102) {
      consumeGreedy(paramStreamPosTokenizer, str1);
    } else {
      paramStreamPosTokenizer.pushBack();
    } 
    if (paramStreamPosTokenizer.nextToken() != -3)
      throw new ParseException("Repetitor: Repeat count missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    String str2;
    if ((str2 = parseGreedyInt(paramStreamPosTokenizer.sval)) == "\000")
      throw new ParseException("Repetitor: Invalid repeat count " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    try {
      j = Integer.parseInt(str2);
    } catch (NumberFormatException numberFormatException) {
      throw new ParseException("Repetitor: Internal Error " + numberFormatException.getMessage(), paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
    } 
    if (j < 1)
      throw new ParseException("Repetitor: Invalid repeat count " + j, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    repetitionNode.setRepeatCount(j);
    repetitionNode.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str2.length() - 1);
    consumeGreedy(paramStreamPosTokenizer, str2);
    if (paramStreamPosTokenizer.nextToken() != -3) {
      paramStreamPosTokenizer.pushBack();
      return repetitionNode;
    } 
    integer = (Integer)this.transformationMap.get(str1 = parseGreedy(paramStreamPosTokenizer.sval));
    if (integer == null) {
      paramStreamPosTokenizer.pushBack();
      return repetitionNode;
    } 
    int i = integer.intValue();
    if (i == 103) {
      consumeGreedy(paramStreamPosTokenizer, str1);
    } else {
      paramStreamPosTokenizer.pushBack();
    } 
    return repetitionNode;
  }
  
  private ScriptNode parseStatement(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "statement", paramScriptNode); 
    if (paramStreamPosTokenizer.nextToken() != -3)
      throw new ParseException("Statement: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    String str;
    Integer integer = (Integer)this.transformationMap.get(str = parseGreedy(paramStreamPosTokenizer.sval));
    if (integer == null) {
      if (this.macroMap.get(str) != null) {
        paramStreamPosTokenizer.pushBack();
        return parseMacro(paramStreamPosTokenizer, paramScriptNode);
      } 
      throw new ParseException("Statement: Unknown token " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
    } 
    int i = integer.intValue();
    if (0 <= i && i <= 84) {
      paramStreamPosTokenizer.pushBack();
      return parseTwist(paramStreamPosTokenizer, paramScriptNode);
    } 
    if (!this.isAmbiguousSeqBeginPermBegin && i == 97) {
      int j = paramStreamPosTokenizer.getStartPosition();
      consumeGreedy(paramStreamPosTokenizer, str);
      return parseSequence(paramStreamPosTokenizer, paramScriptNode, j, 0x1 | ((this.conjugatorPos == 2 && this.isAmbiguousSeqBeginCngrBegin) ? 2 : 0) | ((this.commutatorPos == 2 && this.isAmbiguousSeqBeginCmtrBegin) ? 4 : 0));
    } 
    if (i == 100 && !this.isAmbiguousSeqBeginPermBegin) {
      int j = paramStreamPosTokenizer.getStartPosition();
      consumeGreedy(paramStreamPosTokenizer, str);
      return parsePermutation(paramStreamPosTokenizer, paramScriptNode, j);
    } 
    if (i == 97 || i == 100 || (i == 107 && this.conjugatorPos == 2) || (i == 104 && this.commutatorPos == 2)) {
      int j = paramStreamPosTokenizer.getStartPosition();
      consumeGreedy(paramStreamPosTokenizer, str);
      if (paramStreamPosTokenizer.nextToken() != -3)
        throw new ParseException("Statement: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
      integer = (Integer)this.permutationMap.get(str = parseGreedy(paramStreamPosTokenizer.sval));
      paramStreamPosTokenizer.pushBack();
      return (integer != null && 85 <= integer.intValue() && integer.intValue() <= 93) ? parsePermutation(paramStreamPosTokenizer, paramScriptNode, j) : parseSequence(paramStreamPosTokenizer, paramScriptNode, j, 0x1 | ((this.conjugatorPos == 2 && this.isAmbiguousSeqBeginCngrBegin) ? 2 : 0) | ((this.commutatorPos == 2 && this.isAmbiguousSeqBeginCmtrBegin) ? 4 : 0));
    } 
    throw new ParseException("Statement: Illegal Token " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
  }
  
  private ScriptNode parseSequence(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode, int paramInt1, int paramInt2) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "sequence", paramScriptNode); 
    ScriptNode scriptNode1 = new ScriptNode();
    scriptNode1.setStartPosition(paramInt1);
    paramScriptNode.add(scriptNode1);
    ScriptNode scriptNode2 = null;
    ScriptNode scriptNode3 = scriptNode1;
    while (true) {
      String str;
      Integer integer;
      boolean bool;
      switch (paramStreamPosTokenizer.nextToken()) {
        case -3:
          str = parseGreedy(paramStreamPosTokenizer.sval);
          integer = (Integer)this.transformationMap.get(str);
          bool = (integer == null) ? true : integer.intValue();
          if (bool == 98 || bool == 101) {
            if (!this.isAmbiguousSeqEndCngrEnd)
              paramInt2 &= 0x5; 
            if (!this.isAmbiguousSeqEndCmtrEnd)
              paramInt2 &= 0x3; 
            scriptNode3.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
            consumeGreedy(paramStreamPosTokenizer, str);
            break;
          } 
          if (bool == 109 && this.conjugatorPos == 2) {
            if ((paramInt2 & 0x1) == 1 && !this.isAmbiguousSeqBeginCngrBegin)
              throw new ParseException("Sequence: Illegal delimiter.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
            if (!this.isAmbiguousCngrDelimCmtrDelim)
              paramInt2 = 2; 
            if (scriptNode2 == null) {
              scriptNode1.setEndPosition(paramStreamPosTokenizer.getStartPosition());
              scriptNode2 = new ScriptNode();
              scriptNode2.setStartPosition(paramStreamPosTokenizer.getEndPosition());
              paramScriptNode.add(scriptNode2);
              scriptNode3 = scriptNode2;
            } else {
              throw new ParseException("Conjugation: Delimiter must occur only once", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
            } 
            consumeGreedy(paramStreamPosTokenizer, str);
            continue;
          } 
          if (bool == 106 && this.commutatorPos == 2) {
            if ((paramInt2 & 0x1) == 1 && !this.isAmbiguousSeqBeginCmtrBegin)
              throw new ParseException("Sequence: Illegal delimiter.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
            if (!this.isAmbiguousCngrDelimCmtrDelim)
              paramInt2 = 4; 
            if (scriptNode2 == null) {
              scriptNode1.setEndPosition(paramStreamPosTokenizer.getStartPosition());
              scriptNode2 = new ScriptNode();
              scriptNode2.setStartPosition(paramStreamPosTokenizer.getEndPosition());
              paramScriptNode.add(scriptNode2);
              scriptNode3 = scriptNode2;
            } else {
              throw new ParseException("Commutation: Delimiter must occur only once", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
            } 
            consumeGreedy(paramStreamPosTokenizer, str);
            continue;
          } 
          if (bool == 108 && this.conjugatorPos == 2) {
            if (!this.isAmbiguousCngrEndCmtrEnd)
              paramInt2 &= 0x3; 
            if (!this.isAmbiguousSeqEndCngrEnd)
              paramInt2 &= 0x6; 
            scriptNode3.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
            consumeGreedy(paramStreamPosTokenizer, str);
            break;
          } 
          if (bool == 105 && this.commutatorPos == 2) {
            if (!this.isAmbiguousCngrEndCmtrEnd)
              paramInt2 &= 0x5; 
            if (!this.isAmbiguousSeqEndCmtrEnd)
              paramInt2 &= 0x6; 
            scriptNode3.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
            consumeGreedy(paramStreamPosTokenizer, str);
            break;
          } 
          paramStreamPosTokenizer.pushBack();
          parseExpression(paramStreamPosTokenizer, scriptNode3);
          continue;
        case -1:
          throw new ParseException("Sequence: Close bracket missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
      } 
      throw new ParseException("Sequence: Internal error.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
    } 
    scriptNode1.removeFromParent();
    if (scriptNode2 != null)
      scriptNode2.removeFromParent(); 
    switch (paramInt2) {
      case 1:
        if (scriptNode2 != null)
          throw new ParseException("Sequence: Illegal Sequence.", paramInt1, paramStreamPosTokenizer.getEndPosition()); 
        scriptNode3 = new SequenceNode(paramInt1, paramStreamPosTokenizer.getEndPosition());
        scriptNode3.add(scriptNode1);
        break;
    } 
    paramScriptNode.add(scriptNode3);
    return scriptNode3;
  }
  
  private ScriptNode parsePermutation(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode, int paramInt) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "permutation", paramScriptNode); 
    PermutationNode permutationNode = new PermutationNode();
    paramScriptNode.add(permutationNode);
    permutationNode.setStartPosition(paramInt);
    while (true) {
      String str;
      Integer integer;
      boolean bool;
      switch (paramStreamPosTokenizer.nextToken()) {
        case -3:
          str = parseGreedy(paramStreamPosTokenizer.sval);
          integer = (Integer)this.transformationMap.get(str);
          bool = (integer == null) ? true : integer.intValue();
          if (bool == 98 || bool == 101) {
            permutationNode.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
            consumeGreedy(paramStreamPosTokenizer, str);
            break;
          } 
          paramStreamPosTokenizer.pushBack();
          parsePermutationItem(paramStreamPosTokenizer, permutationNode);
          if (paramStreamPosTokenizer.nextToken() == -3) {
            str = parseGreedy(paramStreamPosTokenizer.sval);
            integer = (Integer)this.transformationMap.get(str);
            if (integer.intValue() == 99) {
              consumeGreedy(paramStreamPosTokenizer, str);
              continue;
            } 
            paramStreamPosTokenizer.pushBack();
            continue;
          } 
          paramStreamPosTokenizer.pushBack();
          continue;
        case -1:
          throw new ParseException("Permutation: Close bracket missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
        default:
          throw new ParseException("Permutation: Internal error.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
      } 
      if (permutationNode.getPermItemCount() == 0)
        throw new ParseException("Permutation: Illegal empty Permutation.", permutationNode.getStartPosition(), permutationNode.getEndPosition()); 
      return permutationNode;
    } 
  }
  
  private void parsePermutationItem(StreamPosTokenizer paramStreamPosTokenizer, PermutationNode paramPermutationNode) throws IOException {
    byte b2;
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "permutationItem", paramPermutationNode); 
    if (paramStreamPosTokenizer.nextToken() != -3)
      throw new ParseException("PermutationItem: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    int i = paramStreamPosTokenizer.getStartPosition();
    String str = parseGreedy(paramStreamPosTokenizer.sval);
    Integer integer = (Integer)this.permutationMap.get(str);
    byte b1 = (integer == null) ? -1 : integer.intValue();
    if (b1 == -1)
      throw new ParseException("PermutationItem: Illegal token " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    switch (b1) {
      case true:
      case true:
      case true:
        b2 = b1;
        consumeGreedy(paramStreamPosTokenizer, str);
        break;
      default:
        b2 = 0;
        paramStreamPosTokenizer.pushBack();
        break;
    } 
    int[] arrayOfInt = new int[3];
    byte b3 = 0;
    while (b3 < 3) {
      if (paramStreamPosTokenizer.nextToken() != -3)
        throw new ParseException("PermutationItem: Face token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
      str = parseGreedy(paramStreamPosTokenizer.sval);
      integer = (Integer)this.permutationMap.get(str);
      b1 = (integer == null) ? -1 : integer.intValue();
      if (b1 == -1)
        throw new ParseException("PermutationItem: Illegal or unknown token " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
      if (85 <= b1 && b1 <= 90) {
        if (this.DEBUG)
          printVerbose(paramStreamPosTokenizer, "permutationItem Face:" + str, paramPermutationNode); 
        arrayOfInt[b3++] = b1;
        consumeGreedy(paramStreamPosTokenizer, str);
      } else {
        throw new ParseException("PermutationItem: Illegal token " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
      } 
      if (paramStreamPosTokenizer.nextToken() != -3)
        throw new ParseException("PermutationItem: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
      str = parseGreedy(paramStreamPosTokenizer.sval);
      integer = (Integer)this.transformationMap.get(str);
      b1 = (integer == null) ? -1 : integer.intValue();
      paramStreamPosTokenizer.pushBack();
      switch (b1) {
        case 94:
        case 98:
        case 99:
        case 101:
          break;
      } 
    } 
    try {
      paramPermutationNode.addPermItem(b3, b2, arrayOfInt);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new ParseException(illegalArgumentException.getMessage(), i, paramStreamPosTokenizer.getEndPosition());
    } 
  }
  
  private ScriptNode parseTwist(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "transformation", paramScriptNode); 
    TwistNode twistNode = new TwistNode();
    paramScriptNode.add(twistNode);
    if (paramStreamPosTokenizer.nextToken() != -3)
      throw new ParseException("Twist: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition()); 
    twistNode.setStartPosition(paramStreamPosTokenizer.getStartPosition());
    String str = parseGreedy(paramStreamPosTokenizer.sval);
    Integer integer = (Integer)this.transformationMap.get(str);
    byte b = (integer == null) ? -1 : integer.intValue();
    if (0 <= b && b <= 84) {
      twistNode.setSymbol(b);
      twistNode.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
      consumeGreedy(paramStreamPosTokenizer, str);
    } else {
      throw new ParseException("Twist: Illegal token " + paramStreamPosTokenizer.sval, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
    } 
    return twistNode;
  }
  
  private ScriptNode parseMacro(StreamPosTokenizer paramStreamPosTokenizer, ScriptNode paramScriptNode) throws IOException {
    String str;
    Object object;
    if (this.DEBUG)
      printVerbose(paramStreamPosTokenizer, "macro", paramScriptNode); 
    switch (paramStreamPosTokenizer.nextToken()) {
      case -3:
        str = parseGreedy(paramStreamPosTokenizer.sval);
        object = this.macroMap.get(str);
        if (object != null) {
          MacroNode macroNode;
          if (object instanceof String) {
            macroNode = new MacroNode(str, (String)object, paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
            this.macroMap.put(str, macroNode);
          } else {
            macroNode = (MacroNode)((MacroNode)object).cloneSubtree();
            Enumeration enumeration = macroNode.preorderEnumeration();
            while (enumeration.hasMoreElements()) {
              ScriptNode scriptNode = enumeration.nextElement();
              scriptNode.setStartPosition(paramStreamPosTokenizer.getStartPosition());
              scriptNode.setEndPosition(paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
            } 
          } 
          paramScriptNode.add(macroNode);
          try {
            macroNode.expand(this);
          } catch (IOException iOException) {
            if (iOException instanceof ParseException) {
              ParseException parseException = (ParseException)iOException;
              throw new ParseException("Macro '" + str + "': " + iOException.getMessage() + " @" + parseException.getStartPosition() + ".." + parseException.getEndPosition(), paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
            } 
            throw new ParseException("Macro '" + str + "': " + iOException.getMessage(), paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
          } 
          consumeGreedy(paramStreamPosTokenizer, str);
          return macroNode;
        } 
        throw new ParseException("Macro: Unexpected or unknown Token.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getStartPosition() + str.length() - 1);
      case -1:
        throw new ParseException("Macro: Token missing.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
    } 
    throw new ParseException("Macro: Internal error.", paramStreamPosTokenizer.getStartPosition(), paramStreamPosTokenizer.getEndPosition());
  }
  
  private String parseGreedy(String paramString) {
    return (this.transformationMap.get(paramString) != null || this.permutationMap.get(paramString) != null || this.macroMap.get(paramString) != null) ? paramString : ((paramString.length() > 1) ? parseGreedy(paramString.substring(0, paramString.length() - 1)) : "\000");
  }
  
  private String parseGreedyInt(String paramString) {
    try {
      Integer.parseInt(paramString);
      return paramString;
    } catch (NumberFormatException numberFormatException) {
      return (paramString.length() > 1) ? parseGreedyInt(paramString.substring(0, paramString.length() - 1)) : "\000";
    } 
  }
  
  private void consumeGreedy(StreamPosTokenizer paramStreamPosTokenizer, String paramString) {
    if (paramString.length() < paramStreamPosTokenizer.sval.length()) {
      paramStreamPosTokenizer.pushBack();
      paramStreamPosTokenizer.setStartPosition(paramStreamPosTokenizer.getStartPosition() + paramString.length());
      paramStreamPosTokenizer.sval = paramStreamPosTokenizer.sval.substring(paramString.length());
    } 
  }
  
  public String getFirstToken(int paramInt) {
    return (0 <= paramInt && paramInt < this.tokens.length && this.tokens[paramInt] != null && (this.tokens[paramInt]).length > 0) ? this.tokens[paramInt][0] : null;
  }
  
  public int getSymbol(String paramString) {
    Integer integer = (Integer)this.transformationMap.get(paramString);
    if (integer == null)
      integer = (Integer)this.permutationMap.get(paramString); 
    return (integer == null) ? -1 : integer.intValue();
  }
  
  public static void applyTo(RubiksCubeCore paramRubiksCubeCore, int paramInt, boolean paramBoolean) {
    if (0 <= paramInt && paramInt < 84) {
      int i = getAngle(paramInt);
      paramRubiksCubeCore.transform(getAxis(paramInt), getLayerMask(paramInt), paramBoolean ? -i : i);
    } 
  }
  
  public static int getAxis(int paramInt) {
    return (0 <= paramInt && paramInt < 84) ? (paramInt % 3) : -1;
  }
  
  public static int getAngle(int paramInt) {
    if (0 <= paramInt && paramInt < 84) {
      int i = (paramInt / 3 % 2 == 0) ? 1 : -1;
      if (paramInt <= 47)
        i = (paramInt / 6 % 2 == 0) ? i : -i; 
      if ((12 <= paramInt && paramInt <= 23) || (36 <= paramInt && paramInt <= 47) || (54 <= paramInt && paramInt <= 59) || (66 <= paramInt && paramInt <= 71) || (78 <= paramInt && paramInt <= 83))
        i *= 2; 
      return i;
    } 
    return 0;
  }
  
  public static int getLayerMask(int paramInt) {
    return (0 <= paramInt && paramInt <= 83) ? ((paramInt <= 23) ? ((paramInt / 3 % 2 == 1) ? 1 : 4) : ((paramInt <= 47) ? ((paramInt / 3 % 2 == 1) ? 3 : 6) : ((paramInt <= 59) ? 2 : ((paramInt <= 71) ? 5 : 7)))) : 0;
  }
  
  public static int getSymbol(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 == -1 || paramInt2 == 0 || paramInt3 == 0)
      return 84; 
    int i = paramInt1;
    byte b1 = (paramInt3 == 2 || paramInt3 == -2) ? 1 : 0;
    byte b2 = (paramInt3 < 0) ? 1 : 0;
    switch (paramInt2) {
      case 1:
        return 3 + i + b1 * 12 + (1 - b2) * 6;
      case 2:
        return 48 + i + b1 * 6 + b2 * 3;
      case 3:
        return 27 + i + b1 * 12 + (1 - b2) * 6;
      case 4:
        return 0 + i + b1 * 12 + b2 * 6;
      case 5:
        return 60 + i + b1 * 12 + b2 * 6;
      case 6:
        return 24 + i + b1 * 12 + b2 * 6;
      case 7:
        return 72 + i + b1 * 6 + b2 * 3;
    } 
    return 84;
  }
  
  public static int inverseSymbol(int paramInt) {
    if (paramInt >= 0) {
      if (paramInt <= 47) {
        boolean bool = (paramInt / 6 % 2 == 0) ? true : false;
        return bool ? (paramInt + 6) : (paramInt - 6);
      } 
      if (paramInt <= 83) {
        boolean bool = ((paramInt - 48) / 3 % 2 == 0) ? true : false;
        return bool ? (paramInt + 3) : (paramInt - 3);
      } 
    } 
    return paramInt;
  }
  
  public static int reflectSymbol(int paramInt) {
    if (0 <= paramInt && paramInt <= 84) {
      int i = getAxis(paramInt);
      int j = getLayerMask(paramInt);
      int k = getAngle(paramInt);
      int m = (j & 0x4) >>> 2 | j & 0x2 | (j & 0x1) << 2;
      return getSymbol(i, m, k);
    } 
    return paramInt;
  }
  
  public static boolean isRotationSymbol(int paramInt) {
    return (72 <= paramInt && paramInt <= 83);
  }
  
  public static boolean isMidlayerSymbol(int paramInt) {
    return (48 <= paramInt && paramInt <= 59);
  }
  
  public static boolean isSliceSymbol(int paramInt) {
    return (60 <= paramInt && paramInt <= 71);
  }
  
  public static int transformSymbol(int paramInt1, int paramInt2) {
    if (paramInt1 == 96)
      return reflectSymbol(paramInt2); 
    if (paramInt1 == 95)
      return inverseSymbol(paramInt2); 
    if (paramInt2 >= 84 || paramInt1 >= 84)
      return paramInt2; 
    int i = getAxis(paramInt2);
    int j = getAxis(paramInt1);
    int k = getAngle(paramInt2);
    int m = getAngle(paramInt1);
    int n = getLayerMask(paramInt2);
    int i1 = -1;
    int i2 = -1;
    int i3 = -1;
    int i4 = (n & 0x4) >>> 2 | n & 0x2 | (n & 0x1) << 2;
    if (i == j || m == 0)
      return paramInt2; 
    switch (j) {
      case 0:
        switch (m) {
          case 1:
            i1 = (i == 1) ? 2 : 1;
            i3 = (i == 1) ? i4 : n;
            i2 = (i == 1) ? -k : k;
            break;
          case -1:
            i1 = (i == 2) ? 1 : 2;
            i3 = (i == 2) ? i4 : n;
            i2 = (i == 2) ? -k : k;
            break;
          case -2:
          case 2:
            i1 = i;
            i2 = -k;
            i3 = i4;
            break;
        } 
        break;
      case 1:
        switch (m) {
          case 1:
            i1 = (i == 2) ? 0 : 2;
            i3 = (i == 2) ? i4 : n;
            i2 = (i == 2) ? -k : k;
            break;
          case -1:
            i1 = (i == 0) ? 2 : 0;
            i3 = (i == 0) ? i4 : n;
            i2 = (i == 0) ? -k : k;
            break;
          case -2:
          case 2:
            i1 = i;
            i3 = i4;
            i2 = -k;
            break;
        } 
        break;
      case 2:
        switch (m) {
          case 1:
            i1 = (i == 0) ? 1 : 0;
            i3 = (i == 0) ? i4 : n;
            i2 = (i == 0) ? -k : k;
            break;
          case -1:
            i1 = (i == 1) ? 0 : 1;
            i3 = (i == 1) ? i4 : n;
            i2 = (i == 1) ? -k : k;
            break;
          case -2:
          case 2:
            i1 = i;
            i3 = i4;
            i2 = -k;
            break;
        } 
        break;
    } 
    return getSymbol(i1, i3, i2);
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(getClass().getName());
    stringBuffer.append('\n');
    for (byte b = 0; b < this.tokens.length; b++) {
      stringBuffer.append(b + ":");
      for (byte b1 = 0; b1 < (this.tokens[b]).length; b1++) {
        if (b1 != 0)
          stringBuffer.append(","); 
        stringBuffer.append(this.tokens[b][b1]);
      } 
      stringBuffer.append('\n');
    } 
    return stringBuffer.toString();
  }
  
  private static String[] getDefaultTokens() {
    if (defaultTokens == null) {
      defaultTokens = new String[113];
      StringTokenizer stringTokenizer = new StringTokenizer("R;U;F;L;D;B;Ri;Ui;Fi;Li;Di;Bi;R2;U2;F2;L2;D2;B2;R2i;U2i;F2i;L2i;D2i;B2i;TR;TU;TF;TL;TD;TB;TRi;TUi;TFi;TLi;TDi;TBi;TR2;TU2;TF2;TL2;TD2;TB2;TR2i;TU2i;TF2i;TL2i;TD2i;TB2i;MR;MU;MF;ML;MD;MB;MR2;MU2;MF2;ML2;MD2;MB2;SR;SU;SF;SL;SD;SB;SR2;SU2;SF2;SL2;SD2;SB2;CR;CU;CF;CL;CD;CB;CR2;CU2;CF2;CL2;CD2;CB2;NOP;permR;permU;permB;permL;permD;permF;permPlus;permMinus;permPlusPlus;statementDelimiter;invertor;reflector;sequenceBegin;sequenceEnd;permutationDelimiter;permutationBegin;permutationEnd;repetitorBegin;repetitorEnd;commutatorBegin;commutatorEnd;commutatorDelimiter;conjugatorBegin;conjugatorEnd;conjugatorDelimiter;commentBegin;commentEnd;singleLineCommentBegin;", ";", false);
      byte b = 0;
      while (stringTokenizer.hasMoreTokens()) {
        String str = stringTokenizer.nextToken();
        int i;
        defaultTokens[b++] = ((i = str.indexOf(' ')) == -1) ? str : str.substring(0, i);
      } 
    } 
    return defaultTokens;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\ScriptParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */