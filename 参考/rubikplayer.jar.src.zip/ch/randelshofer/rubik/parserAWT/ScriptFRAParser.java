package ch.randelshofer.rubik.parserAWT;

import java.util.Hashtable;
import java.util.StringTokenizer;

public class ScriptFRAParser extends ScriptParser {
  private static final String COMPRESSED_TOKENS = "Dh:Hg:Fm:Gb:Bd:Am:Db:Hd:F:Gh:Bg:A:DD:HH:FF:GG:BB:AA:::::::::::::::::::::::::::::::Mh:MCg:MFg:Mb:MCd:MFd:MM:MCC:MFF::::::::::::::::Ch:Cg:CRd:Cb:Cd:CRg:CC:CGG:CRR::::.:d:h:f:g:b:a:+:-:++:;:'::( [ {:) ] }:,:(:):;;;;;;/*;*/;//;";
  
  private static final String COMPRESSED_MACROS = "";
  
  public ScriptFRAParser() {
    super(getTokens(), getMacros(), 1, 1, -1, -1, -1, true);
  }
  
  private static String[] getTokens() {
    String[] arrayOfString = new String[113];
    byte b = 0;
    StringTokenizer stringTokenizer = new StringTokenizer("Dh:Hg:Fm:Gb:Bd:Am:Db:Hd:F:Gh:Bg:A:DD:HH:FF:GG:BB:AA:::::::::::::::::::::::::::::::Mh:MCg:MFg:Mb:MCd:MFd:MM:MCC:MFF::::::::::::::::Ch:Cg:CRd:Cb:Cd:CRg:CC:CGG:CRR::::.:d:h:f:g:b:a:+:-:++:;:'::( [ {:) ] }:,:(:):;;;;;;/*;*/;//;", ":", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals(":")) {
        b++;
        continue;
      } 
      arrayOfString[b] = str;
    } 
    return arrayOfString;
  }
  
  private static Hashtable getMacros() {
    Hashtable hashtable = new Hashtable();
    StringTokenizer stringTokenizer = new StringTokenizer("", ":", false);
    while (stringTokenizer.hasMoreTokens()) {
      StringTokenizer stringTokenizer1 = new StringTokenizer(stringTokenizer.nextToken());
      String str = stringTokenizer.nextToken();
      while (stringTokenizer1.hasMoreTokens())
        hashtable.put(stringTokenizer1.nextToken(), str); 
    } 
    return hashtable;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\ScriptFRAParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */