package ch.randelshofer.rubik.parserAWT;

import java.util.Hashtable;
import java.util.StringTokenizer;

public class HarrisENGParser extends ScriptParser {
  private static final String COMPRESSED_TOKENS = "R;U;F;L;D;B;R';U';F';L';D';B';R2;U2;F2;L2;D2;B2;R2';U2';F2';L2';D2';B2';r;u;f;l;d;b;r';u';f';l';d';b';r2;u2;f2;l2;d2;b2;r2';u2';f2';l2';d2';b2';M';E';S;M;E;S';M2';E2';S2;M2;E2;S2';m';e';s;m;e;s';m2';e2';s2;m2;e2;s2';x;y;z;x';y';z';x2;y2;z2;x2';y2';z2';.;;;;;;;;;;;';;( {;) };;;;*;;;;;;;;[;];;";
  
  public HarrisENGParser() {
    super(getTokens(), new Hashtable(), 1, 1, -1, -1, -1, true);
  }
  
  private static String[] getTokens() {
    String[] arrayOfString = new String[113];
    byte b = 0;
    StringTokenizer stringTokenizer = new StringTokenizer("R;U;F;L;D;B;R';U';F';L';D';B';R2;U2;F2;L2;D2;B2;R2';U2';F2';L2';D2';B2';r;u;f;l;d;b;r';u';f';l';d';b';r2;u2;f2;l2;d2;b2;r2';u2';f2';l2';d2';b2';M';E';S;M;E;S';M2';E2';S2;M2;E2;S2';m';e';s;m;e;s';m2';e2';s2;m2;e2;s2';x;y;z;x';y';z';x2;y2;z2;x2';y2';z2';.;;;;;;;;;;;';;( {;) };;;;*;;;;;;;;[;];;", ";", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals(";")) {
        b++;
        continue;
      } 
      arrayOfString[b] = str;
    } 
    return arrayOfString;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\HarrisENGParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */