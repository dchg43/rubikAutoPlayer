package ch.randelshofer.rubik.parserAWT;

import java.util.Hashtable;
import java.util.StringTokenizer;

public class TouchardDeledicqFRAParser extends ScriptParser {
  private static final String COMPRESSED_TOKENS = "D;H;A;G;B;P;D-;H-;A-;G-;B-;P-;D2;H2;A2;G2;B2;P2;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;Ds;Hs;As;Gs;Bs;Ps;D2s;H2s;A2s;G2s;B2s;P2s;;;;;;;;;;;;;.;;;;;;;;;;;-;;( [ {;) ] };;;;;;;;;;;;/*;*/;//;";
  
  private static final String COMPRESSED_MACROS = "";
  
  public TouchardDeledicqFRAParser() {
    super(getTokens(), getMacros(), 1, 1, -1, -1, -1, true);
  }
  
  private static String[] getTokens() {
    String[] arrayOfString = new String[113];
    byte b = 0;
    StringTokenizer stringTokenizer = new StringTokenizer("D;H;A;G;B;P;D-;H-;A-;G-;B-;P-;D2;H2;A2;G2;B2;P2;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;Ds;Hs;As;Gs;Bs;Ps;D2s;H2s;A2s;G2s;B2s;P2s;;;;;;;;;;;;;.;;;;;;;;;;;-;;( [ {;) ] };;;;;;;;;;;;/*;*/;//;", ";", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals(";")) {
        b++;
        continue;
      } 
      arrayOfString[b] = str;
    } 
    return arrayOfString;
  }
  
  private static Hashtable getMacros() {
    Hashtable hashtable = new Hashtable();
    StringTokenizer stringTokenizer = new StringTokenizer("", ";", false);
    while (stringTokenizer.hasMoreTokens()) {
      StringTokenizer stringTokenizer1 = new StringTokenizer(stringTokenizer.nextToken());
      String str = stringTokenizer.nextToken();
      while (stringTokenizer1.hasMoreTokens())
        hashtable.put(stringTokenizer1.nextToken(), str); 
    } 
    return hashtable;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\rubik\parserAWT\TouchardDeledicqFRAParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */