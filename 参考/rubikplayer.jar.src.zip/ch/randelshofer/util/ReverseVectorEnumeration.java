package ch.randelshofer.util;

import java.util.Enumeration;
import java.util.Vector;

public class ReverseVectorEnumeration implements Enumeration {
  private Vector vector;
  
  private int index;
  
  public ReverseVectorEnumeration(Vector paramVector) {
    this.vector = paramVector;
    this.index = paramVector.size() - 1;
  }
  
  public boolean hasMoreElements() {
    return (this.index >= 0);
  }
  
  public Object nextElement() {
    return this.vector.elementAt(this.index--);
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\ReverseVectorEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */