package ch.randelshofer.util;

import java.util.Vector;

public class PooledSequentialDispatcherAWT implements Runnable {
  private static ConcurrentDispatcherAWT threadPool = new ConcurrentDispatcherAWT();
  
  private volatile int state = 0;
  
  private static final int STOPPED = 0;
  
  private static final int STARTING = 1;
  
  private static final int RUNNING = 2;
  
  private static final int STOPPING = 3;
  
  private final Vector queue = new Vector();
  
  public static void dispatchConcurrently(Runnable paramRunnable) {
    threadPool.dispatch(paramRunnable);
  }
  
  public void dispatch(Runnable paramRunnable) {
    dispatch(paramRunnable, threadPool);
  }
  
  public void dispatch(Runnable paramRunnable, ConcurrentDispatcherAWT paramConcurrentDispatcherAWT) {
    synchronized (this.queue) {
      this.queue.addElement(paramRunnable);
      if (this.state == 0) {
        this.state = 1;
        paramConcurrentDispatcherAWT.dispatch(this);
      } 
    } 
  }
  
  public void reassign() {
    synchronized (this.queue) {
      stop();
      if (!this.queue.isEmpty()) {
        this.state = 1;
        threadPool.dispatch(this);
      } 
    } 
  }
  
  public void stop() {
    synchronized (this.queue) {
      if (this.state == 2) {
        this.state = 3;
        while (this.state != 0) {
          try {
            this.queue.wait();
          } catch (InterruptedException interruptedException) {}
        } 
      } else {
        this.state = 0;
      } 
    } 
  }
  
  public void run() {
    synchronized (this.queue) {
      if (this.state == 1) {
        this.state = 2;
      } else {
        return;
      } 
    } 
    while (true) {
      Runnable runnable;
      synchronized (this.queue) {
        if (this.queue.isEmpty() || this.state != 2) {
          this.state = 0;
          this.queue.notifyAll();
          break;
        } 
        runnable = (Runnable)this.queue.elementAt(0);
        this.queue.removeElementAt(0);
      } 
      try {
        ((Runnable)runnable).run();
      } catch (Throwable throwable) {
        throwable.printStackTrace();
      } 
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\PooledSequentialDispatcherAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */