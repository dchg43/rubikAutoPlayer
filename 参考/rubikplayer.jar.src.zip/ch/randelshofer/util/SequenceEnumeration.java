package ch.randelshofer.util;

import java.util.Enumeration;

public class SequenceEnumeration implements Enumeration {
  private Enumeration first;
  
  private Enumeration second;
  
  public SequenceEnumeration(Enumeration paramEnumeration1, Enumeration paramEnumeration2) {
    this.first = paramEnumeration1;
    this.second = paramEnumeration2;
  }
  
  public boolean hasMoreElements() {
    return (this.first.hasMoreElements() || this.second.hasMoreElements());
  }
  
  public synchronized Object nextElement() {
    return this.first.hasMoreElements() ? this.first.nextElement() : this.second.nextElement();
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\SequenceEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */