package ch.randelshofer.util;

public interface Comparable {
  int compareTo(Object paramObject);
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\Comparable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */