package ch.randelshofer.util;

import java.util.Enumeration;
import java.util.NoSuchElementException;

public class SingletonEnumeration implements Enumeration {
  private Object object;
  
  public SingletonEnumeration(Object paramObject) {
    this.object = paramObject;
  }
  
  public boolean hasMoreElements() {
    return (this.object != null);
  }
  
  public synchronized Object nextElement() {
    if (this.object == null)
      throw new NoSuchElementException(); 
    Object object = this.object;
    this.object = null;
    return object;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\SingletonEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */