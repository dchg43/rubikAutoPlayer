package ch.randelshofer.util;

public class Arrays {
  private static void sort1(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    if (paramInt2 < 7) {
      for (int i2 = paramInt1; i2 < paramInt2 + paramInt1; i2++) {
        for (int i3 = i2; i3 > paramInt1 && paramArrayOfint[i3 - 1] > paramArrayOfint[i3]; i3--)
          swap(paramArrayOfint, i3, i3 - 1); 
      } 
      return;
    } 
    int i = paramInt1 + paramInt2 / 2;
    if (paramInt2 > 7) {
      int i2 = paramInt1;
      int i3 = paramInt1 + paramInt2 - 1;
      if (paramInt2 > 40) {
        int i4 = paramInt2 / 8;
        i2 = med3(paramArrayOfint, i2, i2 + i4, i2 + 2 * i4);
        i = med3(paramArrayOfint, i - i4, i, i + i4);
        i3 = med3(paramArrayOfint, i3 - 2 * i4, i3 - i4, i3);
      } 
      i = med3(paramArrayOfint, i2, i, i3);
    } 
    int j = paramArrayOfint[i];
    int k = paramInt1;
    int m = k;
    int n = paramInt1 + paramInt2 - 1;
    int i1 = n;
    while (true) {
      if (m <= n && paramArrayOfint[m] <= j) {
        if (paramArrayOfint[m] == j)
          swap(paramArrayOfint, k++, m); 
        m++;
        continue;
      } 
      while (n >= m && paramArrayOfint[n] >= j) {
        if (paramArrayOfint[n] == j)
          swap(paramArrayOfint, n, i1--); 
        n--;
      } 
      if (m > n) {
        int i3 = paramInt1 + paramInt2;
        int i2 = Math.min(k - paramInt1, m - k);
        vecswap(paramArrayOfint, paramInt1, m - i2, i2);
        i2 = Math.min(i1 - n, i3 - i1 - 1);
        vecswap(paramArrayOfint, m, i3 - i2, i2);
        if ((i2 = m - k) > 1)
          sort1(paramArrayOfint, paramInt1, i2); 
        if ((i2 = i1 - n) > 1)
          sort1(paramArrayOfint, i3 - i2, i2); 
        return;
      } 
      swap(paramArrayOfint, m++, n--);
    } 
  }
  
  private static void swap(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    int i = paramArrayOfint[paramInt1];
    paramArrayOfint[paramInt1] = paramArrayOfint[paramInt2];
    paramArrayOfint[paramInt2] = i;
  }
  
  private static void vecswap(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3) {
    byte b = 0;
    while (b < paramInt3) {
      swap(paramArrayOfint, paramInt1, paramInt2);
      b++;
      paramInt1++;
      paramInt2++;
    } 
  }
  
  private static int med3(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3) {
    return (paramArrayOfint[paramInt1] < paramArrayOfint[paramInt2]) ? ((paramArrayOfint[paramInt2] < paramArrayOfint[paramInt3]) ? paramInt2 : ((paramArrayOfint[paramInt1] < paramArrayOfint[paramInt3]) ? paramInt3 : paramInt1)) : ((paramArrayOfint[paramInt2] > paramArrayOfint[paramInt3]) ? paramInt2 : ((paramArrayOfint[paramInt1] > paramArrayOfint[paramInt3]) ? paramInt3 : paramInt1));
  }
  
  public static void sort(Object[] paramArrayOfObject) {
    Object[] arrayOfObject = (Object[])paramArrayOfObject.clone();
    mergeSort(arrayOfObject, paramArrayOfObject, 0, paramArrayOfObject.length);
  }
  
  public static void sort(Object[] paramArrayOfObject, int paramInt1, int paramInt2) {
    rangeCheck(paramArrayOfObject.length, paramInt1, paramInt2);
    Object[] arrayOfObject = (Object[])paramArrayOfObject.clone();
    mergeSort(arrayOfObject, paramArrayOfObject, paramInt1, paramInt2);
  }
  
  private static void mergeSort(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, int paramInt1, int paramInt2) {
    int i = paramInt2 - paramInt1;
    if (i < 7) {
      for (int i1 = paramInt1; i1 < paramInt2; i1++) {
        for (int i2 = i1; i2 > paramInt1 && ((Comparable)paramArrayOfObject2[i2 - 1]).compareTo(paramArrayOfObject2[i2]) > 0; i2--)
          swap(paramArrayOfObject2, i2, i2 - 1); 
      } 
      return;
    } 
    int j = (paramInt1 + paramInt2) / 2;
    mergeSort(paramArrayOfObject2, paramArrayOfObject1, paramInt1, j);
    mergeSort(paramArrayOfObject2, paramArrayOfObject1, j, paramInt2);
    if (((Comparable)paramArrayOfObject1[j - 1]).compareTo(paramArrayOfObject1[j]) <= 0) {
      System.arraycopy(paramArrayOfObject1, paramInt1, paramArrayOfObject2, paramInt1, i);
      return;
    } 
    int k = paramInt1;
    int m = paramInt1;
    int n = j;
    while (k < paramInt2) {
      if (n >= paramInt2 || (m < j && ((Comparable)paramArrayOfObject1[m]).compareTo(paramArrayOfObject1[n]) <= 0)) {
        paramArrayOfObject2[k] = paramArrayOfObject1[m++];
      } else {
        paramArrayOfObject2[k] = paramArrayOfObject1[n++];
      } 
      k++;
    } 
  }
  
  private static void swap(Object[] paramArrayOfObject, int paramInt1, int paramInt2) {
    Object object = paramArrayOfObject[paramInt1];
    paramArrayOfObject[paramInt1] = paramArrayOfObject[paramInt2];
    paramArrayOfObject[paramInt2] = object;
  }
  
  private static void rangeCheck(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 > paramInt3)
      throw new IllegalArgumentException("fromIndex(" + paramInt2 + ") > toIndex(" + paramInt3 + ")"); 
    if (paramInt2 < 0)
      throw new ArrayIndexOutOfBoundsException(paramInt2); 
    if (paramInt3 > paramInt1)
      throw new ArrayIndexOutOfBoundsException(paramInt3); 
  }
  
  public static boolean equals(int[] paramArrayOfint1, int[] paramArrayOfint2) {
    if (paramArrayOfint1 == paramArrayOfint2)
      return true; 
    if (paramArrayOfint1 == null || paramArrayOfint2 == null)
      return false; 
    int i = paramArrayOfint1.length;
    if (paramArrayOfint2.length != i)
      return false; 
    for (byte b = 0; b < i; b++) {
      if (paramArrayOfint1[b] != paramArrayOfint2[b])
        return false; 
    } 
    return true;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\Arrays.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */