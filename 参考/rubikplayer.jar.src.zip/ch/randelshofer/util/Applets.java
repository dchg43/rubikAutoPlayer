package ch.randelshofer.util;

import java.applet.Applet;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class Applets {
  public static String getParameter(Applet paramApplet, String paramString1, String paramString2) {
    String str = paramApplet.getParameter(paramString1);
    return (str != null) ? str : paramString2;
  }
  
  public static boolean getParameter(Applet paramApplet, String paramString, boolean paramBoolean) {
    String str = paramApplet.getParameter(paramString);
    return (str != null) ? str.equals("true") : paramBoolean;
  }
  
  public static String[] getParameters(Applet paramApplet, String paramString, String[] paramArrayOfString) {
    String str = paramApplet.getParameter(paramString);
    if (str != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(str, ", ");
      String[] arrayOfString = new String[stringTokenizer.countTokens()];
      for (byte b = 0; b < arrayOfString.length; b++)
        arrayOfString[b] = stringTokenizer.nextToken(); 
      return arrayOfString;
    } 
    return paramArrayOfString;
  }
  
  public static int getParameter(Applet paramApplet, String paramString, int paramInt) {
    String str = paramApplet.getParameter(paramString);
    if (str != null)
      try {
        return decode(str).intValue();
      } catch (NumberFormatException numberFormatException) {} 
    return paramInt;
  }
  
  public static int[] getParameters(Applet paramApplet, String paramString, int[] paramArrayOfint) {
    String str = paramApplet.getParameter(paramString);
    if (str != null)
      try {
        StringTokenizer stringTokenizer = new StringTokenizer(str, ", ");
        int[] arrayOfInt = new int[stringTokenizer.countTokens()];
        for (byte b = 0; b < arrayOfInt.length; b++)
          arrayOfInt[b] = decode(stringTokenizer.nextToken()).intValue(); 
        return arrayOfInt;
      } catch (NumberFormatException numberFormatException) {} 
    return paramArrayOfint;
  }
  
  public static double getParameter(Applet paramApplet, String paramString, double paramDouble) {
    String str = paramApplet.getParameter(paramString);
    if (str != null)
      try {
        return Double.valueOf(str).doubleValue();
      } catch (NumberFormatException numberFormatException) {} 
    return paramDouble;
  }
  
  public static Hashtable getIndexedKeyValueParameters(Applet paramApplet, String paramString, Hashtable paramHashtable) {
    String str = paramApplet.getParameter(paramString);
    if (str != null) {
      Hashtable hashtable = new Hashtable();
      StringTokenizer stringTokenizer = new StringTokenizer(str, ", ");
      int i = stringTokenizer.countTokens();
      for (byte b = 0; b < i; b++) {
        String str2;
        String str3;
        String str1 = stringTokenizer.nextToken();
        int j = str1.indexOf('=');
        if (j < 1) {
          str2 = null;
          str3 = str1;
        } else {
          str2 = str1.substring(0, j);
          str3 = str1.substring(j + 1);
        } 
        String str4 = Integer.toString(b);
        if (str2 != null)
          hashtable.put(str2, str3); 
        if (!hashtable.contains(str4))
          hashtable.put(str4, str3); 
      } 
      return hashtable;
    } 
    return paramHashtable;
  }
  
  public static Integer decode(String paramString) throws NumberFormatException {
    Integer integer;
    byte b1 = 10;
    byte b2 = 0;
    boolean bool = false;
    if (paramString.startsWith("-")) {
      bool = true;
      b2++;
    } 
    if (paramString.startsWith("0x", b2) || paramString.startsWith("0X", b2)) {
      b2 += 2;
      b1 = 16;
    } else if (paramString.startsWith("#", b2)) {
      b2++;
      b1 = 16;
    } else if (paramString.startsWith("0", b2) && paramString.length() > 1 + b2) {
      b2++;
      b1 = 8;
    } 
    if (paramString.startsWith("-", b2))
      throw new NumberFormatException("Negative sign in wrong position"); 
    try {
      integer = Integer.valueOf(paramString.substring(b2), b1);
      integer = bool ? new Integer(-integer.intValue()) : integer;
    } catch (NumberFormatException numberFormatException) {
      String str = bool ? new String("-" + paramString.substring(b2)) : paramString.substring(b2);
      integer = Integer.valueOf(str, b1);
    } 
    return integer;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\Applets.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */