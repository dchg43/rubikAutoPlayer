package ch.randelshofer.util;

import java.util.Enumeration;
import java.util.NoSuchElementException;

public class EmptyEnumeration implements Enumeration {
  public static final EmptyEnumeration EMPTY_ENUMERATION = new EmptyEnumeration();
  
  public boolean hasMoreElements() {
    return false;
  }
  
  public Object nextElement() {
    throw new NoSuchElementException();
  }
  
  public static EmptyEnumeration getInstance() {
    return EMPTY_ENUMERATION;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\EmptyEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */