package ch.randelshofer.util;

import java.util.Vector;

public class ConcurrentDispatcherAWT implements Runnable {
  private int priority;
  
  private final Vector queue = new Vector();
  
  private int threadCount;
  
  private int threadMax;
  
  public static int ENQUEUE_WHEN_BLOCKED = 0;
  
  public static int RUN_WHEN_BLOCKED = 1;
  
  private int blockingPolicy = ENQUEUE_WHEN_BLOCKED;
  
  public ConcurrentDispatcherAWT() {
    this(5, 5);
  }
  
  public ConcurrentDispatcherAWT(int paramInt1, int paramInt2) {
    this.priority = paramInt1;
    this.threadMax = paramInt2;
  }
  
  public void setMaxThreads(int paramInt) {
    this.threadMax = paramInt;
  }
  
  public void dispatch(Runnable paramRunnable) {
    synchronized (this.queue) {
      if (this.threadCount < this.threadMax) {
        this.queue.addElement(paramRunnable);
        Thread thread = new Thread(this, this + " Processor");
        this.threadCount++;
        try {
          thread.setDaemon(false);
        } catch (SecurityException securityException) {}
        try {
          thread.setPriority(this.priority);
        } catch (SecurityException securityException) {}
        thread.start();
        return;
      } 
      if (this.blockingPolicy == ENQUEUE_WHEN_BLOCKED) {
        this.queue.addElement(paramRunnable);
        return;
      } 
    } 
    paramRunnable.run();
  }
  
  public void run() {
    while (true) {
      Runnable runnable;
      synchronized (this.queue) {
        if (this.queue.isEmpty()) {
          this.threadCount--;
          break;
        } 
        runnable = (Runnable)this.queue.elementAt(0);
        this.queue.removeElementAt(0);
      } 
      try {
        ((Runnable)runnable).run();
      } catch (Throwable throwable) {
        throwable.printStackTrace();
      } 
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofe\\util\ConcurrentDispatcherAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */