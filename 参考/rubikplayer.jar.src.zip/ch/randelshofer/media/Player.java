package ch.randelshofer.media;

import ch.randelshofer.gui.BoundedRangeModel;
import ch.randelshofer.gui.event.ChangeListener;
import java.awt.Component;
import java.awt.image.ImageProducer;

public interface Player {
  void start();
  
  void stop();
  
  boolean isActive();
  
  BoundedRangeModel getBoundedRangeModel();
  
  ImageProducer getImageProducer();
  
  Component getVisualComponent();
  
  Component getControlPanelComponent();
  
  void addChangeListener(ChangeListener paramChangeListener);
  
  void removeChangeListener(ChangeListener paramChangeListener);
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\media\Player.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */