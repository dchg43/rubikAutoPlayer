package ch.randelshofer.beans;

import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.gui.event.EventListenerList;
import java.util.EventListener;

public class AbstractStateModel {
  protected EventListenerList listenerList;
  
  protected ChangeEvent changeEvent;
  
  public void addChangeListener(ChangeListener paramChangeListener) {
    if (this.listenerList == null)
      this.listenerList = new EventListenerList(); 
    this.listenerList.add(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public void removeChangeListener(ChangeListener paramChangeListener) {
    if (this.listenerList == null)
      this.listenerList = new EventListenerList(); 
    this.listenerList.remove(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  protected void fireStateChanged() {
    if (this.listenerList != null) {
      Object[] arrayOfObject = this.listenerList.getListenerList();
      for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
        if (arrayOfObject[i] == ChangeListener.class) {
          if (this.changeEvent == null)
            this.changeEvent = new ChangeEvent(this); 
          ((ChangeListener)arrayOfObject[i + 1]).stateChanged(this.changeEvent);
        } 
      } 
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\beans\AbstractStateModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */