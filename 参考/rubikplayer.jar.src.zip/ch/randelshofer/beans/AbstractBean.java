package ch.randelshofer.beans;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;

public class AbstractBean implements Serializable {
  protected PropertyChangeSupport propertySupport = new PropertyChangeSupport(this);
  
  public void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {
    this.propertySupport.addPropertyChangeListener(paramPropertyChangeListener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {
    this.propertySupport.removePropertyChangeListener(paramPropertyChangeListener);
  }
  
  protected void firePropertyChange(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    this.propertySupport.firePropertyChange(paramString, paramBoolean1 ? Boolean.TRUE : Boolean.FALSE, paramBoolean2 ? Boolean.TRUE : Boolean.FALSE);
  }
  
  protected void firePropertyChange(String paramString, int paramInt1, int paramInt2) {
    this.propertySupport.firePropertyChange(paramString, new Integer(paramInt1), new Integer(paramInt2));
  }
  
  protected void firePropertyChange(String paramString, Object paramObject1, Object paramObject2) {
    this.propertySupport.firePropertyChange(paramString, paramObject1, paramObject2);
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\beans\AbstractBean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */