package ch.randelshofer.gui;

import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Graphics;

public class MovieSliderAWT extends Canvas implements ChangeListener {
  private static final int THUMB_WIDTH = 8;
  
  private static final int THUMB_HEIGHT = 13;
  
  private static final int HALF_THUMB_WIDTH = 4;
  
  private BoundedRangeModel model_ = new DefaultBoundedRangeModel();
  
  protected int thumbPos_ = 0;
  
  private int progressPos_;
  
  private BoundedRangeModel progressModel_ = new DefaultBoundedRangeModel(1, 0, 0, 1);
  
  public MovieSliderAWT() {
    this.model_.addChangeListener(this);
    setBackground(Color.lightGray);
  }
  
  public synchronized void setModel(BoundedRangeModel paramBoundedRangeModel) {
    if (this.model_ != null)
      this.model_.removeChangeListener(this); 
    this.model_ = (paramBoundedRangeModel == null) ? new DefaultBoundedRangeModel() : paramBoundedRangeModel;
    if (this.model_ != null)
      this.model_.addChangeListener(this); 
    repaint();
  }
  
  public BoundedRangeModel getModel() {
    return this.model_;
  }
  
  public Dimension preferredSize() {
    return new Dimension(50, 15);
  }
  
  public Dimension minimumSize() {
    return new Dimension(18, 15);
  }
  
  public boolean mouseDown(Event paramEvent, int paramInt1, int paramInt2) {
    if (isEnabled())
      moveThumb(paramInt1); 
    return true;
  }
  
  public boolean mouseDrag(Event paramEvent, int paramInt1, int paramInt2) {
    if (isEnabled())
      moveThumb(paramInt1); 
    return true;
  }
  
  public boolean mouseUp(Event paramEvent, int paramInt1, int paramInt2) {
    if (isEnabled())
      moveThumb(paramInt1); 
    return true;
  }
  
  protected void moveThumb(int paramInt) {
    int i = computeProgressPos();
    if (paramInt <= 4)
      paramInt = 5; 
    if (paramInt >= i - 4)
      paramInt = i - 4 - 1; 
    int j = Math.max(1, 2 * (this.model_.getMaximum() - this.model_.getMinimum()));
    float f = (paramInt - 4 - 1 + i / j) / (i - 10);
    this.model_.setValue((int)(f * (this.model_.getMaximum() - this.model_.getMinimum())));
  }
  
  protected int computeThumbPos() {
    BoundedRangeModel boundedRangeModel = this.model_;
    if (boundedRangeModel == null)
      return 4; 
    int i = computeProgressPos() - 4 + 2;
    float f = Math.max(0.0F, boundedRangeModel.getValue() / (boundedRangeModel.getMaximum() - boundedRangeModel.getMinimum()));
    return (int)(i * f) + 4;
  }
  
  public synchronized void setProgressModel(BoundedRangeModel paramBoundedRangeModel) {
    if (this.progressModel_ != null)
      this.progressModel_.removeChangeListener(this); 
    this.progressModel_ = paramBoundedRangeModel;
    if (this.progressModel_ != null)
      this.progressModel_.addChangeListener(this); 
  }
  
  public BoundedRangeModel getProgressModel() {
    return this.progressModel_;
  }
  
  public void paint(Graphics paramGraphics) {
    this.thumbPos_ = computeThumbPos();
    this.progressPos_ = computeProgressPos();
    paint(paramGraphics, this.thumbPos_, this.progressPos_);
  }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2) {
    Dimension dimension = size();
    int i = dimension.width;
    int j = dimension.height;
    paramInt1 = Math.min(Math.max(paramInt1, 0), i);
    if (!isEnabled())
      paramGraphics.setColor(Color.gray); 
    paramGraphics.drawRect(0, 0, i - 1, j - 1);
    paramGraphics.drawRect(4, 4, i - 8 - 1, j - 9);
    if (isEnabled()) {
      paramGraphics.setColor(Color.white);
      paramGraphics.drawLine(1, 1, i - 2, 1);
      paramGraphics.drawLine(1, 2, 1, j - 2);
      paramGraphics.drawLine(5, 5, i - 4 - 3, 5);
      paramGraphics.drawLine(5, 6, 5, j - 6);
      if (paramInt2 > 0) {
        paramGraphics.setColor(Color.gray);
        paramGraphics.fillRect(6, 6, paramInt2 - 4, j - 11);
      } 
      paramGraphics.setColor(Color.white);
      paramGraphics.drawRect(paramInt1 - 4 + 1, 1, 6, j - 3);
      paramGraphics.setColor(getForeground());
    } 
    paramGraphics.drawRect(paramInt1 - 4, 0, 8, j - 1);
    paramGraphics.drawRect(paramInt1 - 4 + 2, 2, 4, j - 5);
  }
  
  protected int computeProgressPos() {
    BoundedRangeModel boundedRangeModel = this.progressModel_;
    int i = (size()).width - 8 - 3;
    if (boundedRangeModel == null)
      return 6; 
    float f = boundedRangeModel.getValue() / (boundedRangeModel.getMaximum() - boundedRangeModel.getMinimum());
    return (int)(i * f) + 4;
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent) {
    if (computeProgressPos() != this.progressPos_ || computeThumbPos() != this.thumbPos_)
      repaint(); 
  }
  
  public void setEnabled(boolean paramBoolean) {
    if (paramBoolean != isEnabled()) {
      super.setEnabled(paramBoolean);
      repaint();
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\MovieSliderAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */