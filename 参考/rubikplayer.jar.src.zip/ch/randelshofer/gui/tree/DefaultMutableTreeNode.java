package ch.randelshofer.gui.tree;

import ch.randelshofer.util.EmptyEnumeration;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Stack;
import java.util.Vector;

public class DefaultMutableTreeNode implements Cloneable, Serializable {
  protected DefaultMutableTreeNode parent = null;
  
  protected Vector children;
  
  protected transient Object userObject;
  
  protected boolean allowsChildren;
  
  public DefaultMutableTreeNode() {
    this(null);
  }
  
  public DefaultMutableTreeNode(Object paramObject) {
    this(paramObject, true);
  }
  
  public DefaultMutableTreeNode(Object paramObject, boolean paramBoolean) {
    this.allowsChildren = paramBoolean;
    this.userObject = paramObject;
  }
  
  public void insert(DefaultMutableTreeNode paramDefaultMutableTreeNode, int paramInt) {
    if (!this.allowsChildren)
      throw new IllegalStateException("node does not allow children"); 
    if (paramDefaultMutableTreeNode == null)
      throw new IllegalArgumentException("new child is null"); 
    if (isNodeAncestor(paramDefaultMutableTreeNode))
      throw new IllegalArgumentException("new child is an ancestor"); 
    DefaultMutableTreeNode defaultMutableTreeNode = paramDefaultMutableTreeNode.getParent();
    if (defaultMutableTreeNode != null)
      defaultMutableTreeNode.remove(paramDefaultMutableTreeNode); 
    paramDefaultMutableTreeNode.setParent(this);
    if (this.children == null)
      this.children = new Vector(); 
    this.children.insertElementAt(paramDefaultMutableTreeNode, paramInt);
  }
  
  public void remove(int paramInt) {
    DefaultMutableTreeNode defaultMutableTreeNode = getChildAt(paramInt);
    this.children.removeElementAt(paramInt);
    defaultMutableTreeNode.setParent(null);
  }
  
  public void setParent(DefaultMutableTreeNode paramDefaultMutableTreeNode) {
    this.parent = paramDefaultMutableTreeNode;
  }
  
  public DefaultMutableTreeNode getParent() {
    return this.parent;
  }
  
  public DefaultMutableTreeNode getChildAt(int paramInt) {
    if (this.children == null)
      throw new ArrayIndexOutOfBoundsException("node has no children"); 
    return this.children.elementAt(paramInt);
  }
  
  public int getChildCount() {
    return (this.children == null) ? 0 : this.children.size();
  }
  
  public int getIndex(DefaultMutableTreeNode paramDefaultMutableTreeNode) {
    if (paramDefaultMutableTreeNode == null)
      throw new IllegalArgumentException("argument is null"); 
    return !isNodeChild(paramDefaultMutableTreeNode) ? -1 : this.children.indexOf(paramDefaultMutableTreeNode);
  }
  
  public Enumeration children() {
    return (Enumeration)((this.children == null) ? EmptyEnumeration.EMPTY_ENUMERATION : this.children.elements());
  }
  
  public void setAllowsChildren(boolean paramBoolean) {
    if (paramBoolean != this.allowsChildren) {
      this.allowsChildren = paramBoolean;
      if (!this.allowsChildren)
        removeAllChildren(); 
    } 
  }
  
  public boolean getAllowsChildren() {
    return this.allowsChildren;
  }
  
  public void setUserObject(Object paramObject) {
    this.userObject = paramObject;
  }
  
  public Object getUserObject() {
    return this.userObject;
  }
  
  public void removeFromParent() {
    DefaultMutableTreeNode defaultMutableTreeNode = getParent();
    if (defaultMutableTreeNode != null)
      defaultMutableTreeNode.remove(this); 
  }
  
  public void remove(DefaultMutableTreeNode paramDefaultMutableTreeNode) {
    if (paramDefaultMutableTreeNode == null)
      throw new IllegalArgumentException("argument is null"); 
    if (!isNodeChild(paramDefaultMutableTreeNode))
      throw new IllegalArgumentException("argument is not a child"); 
    remove(getIndex(paramDefaultMutableTreeNode));
  }
  
  public void removeAllChildren() {
    for (int i = getChildCount() - 1; i >= 0; i--)
      remove(i); 
  }
  
  public void add(DefaultMutableTreeNode paramDefaultMutableTreeNode) {
    if (paramDefaultMutableTreeNode != null && paramDefaultMutableTreeNode.getParent() == this) {
      insert(paramDefaultMutableTreeNode, getChildCount() - 1);
    } else {
      insert(paramDefaultMutableTreeNode, getChildCount());
    } 
  }
  
  public boolean isNodeAncestor(DefaultMutableTreeNode paramDefaultMutableTreeNode) {
    if (paramDefaultMutableTreeNode == null)
      return false; 
    DefaultMutableTreeNode defaultMutableTreeNode = this;
    while (true) {
      if (defaultMutableTreeNode == paramDefaultMutableTreeNode)
        return true; 
      if ((defaultMutableTreeNode = defaultMutableTreeNode.getParent()) == null)
        return false; 
    } 
  }
  
  public boolean isNodeDescendant(DefaultMutableTreeNode paramDefaultMutableTreeNode) {
    return (paramDefaultMutableTreeNode == null) ? false : paramDefaultMutableTreeNode.isNodeAncestor(this);
  }
  
  public int getDepth() {
    DefaultMutableTreeNode defaultMutableTreeNode = null;
    Enumeration enumeration = breadthFirstEnumeration();
    while (enumeration.hasMoreElements())
      defaultMutableTreeNode = (DefaultMutableTreeNode)enumeration.nextElement(); 
    if (defaultMutableTreeNode == null)
      throw new Error("nodes should be null"); 
    return ((DefaultMutableTreeNode)defaultMutableTreeNode).getLevel() - getLevel();
  }
  
  public int getLevel() {
    byte b = 0;
    DefaultMutableTreeNode defaultMutableTreeNode = this;
    while ((defaultMutableTreeNode = defaultMutableTreeNode.getParent()) != null)
      b++; 
    return b;
  }
  
  public Enumeration preorderEnumeration() {
    return new PreorderEnumeration(this, this);
  }
  
  public Enumeration breadthFirstEnumeration() {
    return new BreadthFirstEnumeration(this, this);
  }
  
  public boolean isNodeChild(DefaultMutableTreeNode paramDefaultMutableTreeNode) {
    boolean bool;
    if (paramDefaultMutableTreeNode == null) {
      bool = false;
    } else if (getChildCount() == 0) {
      bool = false;
    } else {
      bool = (paramDefaultMutableTreeNode.getParent() == this) ? true : false;
    } 
    return bool;
  }
  
  public String toString() {
    return (this.userObject == null) ? null : this.userObject.toString();
  }
  
  public Object clone() {
    DefaultMutableTreeNode defaultMutableTreeNode = null;
    try {
      defaultMutableTreeNode = (DefaultMutableTreeNode)super.clone();
      defaultMutableTreeNode.children = null;
      defaultMutableTreeNode.parent = null;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new Error(cloneNotSupportedException.toString());
    } 
    return defaultMutableTreeNode;
  }
  
  final class BreadthFirstEnumeration implements Enumeration {
    protected Queue queue;
    
    private final DefaultMutableTreeNode this$0;
    
    public BreadthFirstEnumeration(DefaultMutableTreeNode this$0, DefaultMutableTreeNode param1DefaultMutableTreeNode1) {
      this.this$0 = this$0;
      Vector vector = new Vector(1);
      vector.addElement(param1DefaultMutableTreeNode1);
      this.queue = new Queue(this);
      this.queue.enqueue(vector.elements());
    }
    
    public boolean hasMoreElements() {
      return (!this.queue.isEmpty() && ((Enumeration)this.queue.firstObject()).hasMoreElements());
    }
    
    public Object nextElement() {
      Enumeration enumeration = (Enumeration)this.queue.firstObject();
      DefaultMutableTreeNode defaultMutableTreeNode = enumeration.nextElement();
      Enumeration enumeration1 = defaultMutableTreeNode.children();
      if (!enumeration.hasMoreElements())
        this.queue.dequeue(); 
      if (enumeration1.hasMoreElements())
        this.queue.enqueue(enumeration1); 
      return defaultMutableTreeNode;
    }
    
    final class Queue {
      QNode head;
      
      QNode tail;
      
      private final DefaultMutableTreeNode.BreadthFirstEnumeration this$1;
      
      Queue(DefaultMutableTreeNode.BreadthFirstEnumeration this$0) {
        this.this$1 = this$0;
      }
      
      public void enqueue(Object param2Object) {
        if (this.head == null) {
          this.head = this.tail = new QNode(this, param2Object, null);
        } else {
          this.tail.next = new QNode(this, param2Object, null);
          this.tail = this.tail.next;
        } 
      }
      
      public Object dequeue() {
        if (this.head == null)
          throw new NoSuchElementException("No more elements"); 
        Object object = this.head.object;
        QNode qNode = this.head;
        this.head = this.head.next;
        if (this.head == null) {
          this.tail = null;
        } else {
          qNode.next = null;
        } 
        return object;
      }
      
      public Object firstObject() {
        if (this.head == null)
          throw new NoSuchElementException("No more elements"); 
        return this.head.object;
      }
      
      public boolean isEmpty() {
        return (this.head == null);
      }
      
      final class QNode {
        public Object object;
        
        public QNode next;
        
        private final DefaultMutableTreeNode.BreadthFirstEnumeration.Queue this$2;
        
        public QNode(DefaultMutableTreeNode.BreadthFirstEnumeration.Queue this$0, Object param3Object, QNode param3QNode) {
          this.this$2 = this$0;
          this.object = param3Object;
          this.next = param3QNode;
        }
      }
    }
  }
  
  final class PreorderEnumeration implements Enumeration {
    protected Stack stack;
    
    private final DefaultMutableTreeNode this$0;
    
    public PreorderEnumeration(DefaultMutableTreeNode this$0, DefaultMutableTreeNode param1DefaultMutableTreeNode1) {
      this.this$0 = this$0;
      Vector vector = new Vector(1);
      vector.addElement(param1DefaultMutableTreeNode1);
      this.stack = new Stack();
      this.stack.push(vector.elements());
    }
    
    public boolean hasMoreElements() {
      return (!this.stack.empty() && ((Enumeration)this.stack.peek()).hasMoreElements());
    }
    
    public Object nextElement() {
      Enumeration enumeration = this.stack.peek();
      DefaultMutableTreeNode defaultMutableTreeNode = enumeration.nextElement();
      Enumeration enumeration1 = defaultMutableTreeNode.children();
      if (!enumeration.hasMoreElements())
        this.stack.pop(); 
      if (enumeration1.hasMoreElements())
        this.stack.push(enumeration1); 
      return defaultMutableTreeNode;
    }
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\tree\DefaultMutableTreeNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */