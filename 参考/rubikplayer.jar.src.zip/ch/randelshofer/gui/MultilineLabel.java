package ch.randelshofer.gui;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.util.StringTokenizer;
import java.util.Vector;

public class MultilineLabel extends Canvas {
  private String text = "";
  
  private String[] lines;
  
  private Insets insets = new Insets(2, 3, 3, 3);
  
  private int selectionStart;
  
  private int selectionEnd;
  
  private Color selectionBackground = new Color(181, 213, 255);
  
  private int minRows;
  
  public MultilineLabel() {
    initComponents();
    setBackground(Color.white);
    setForeground(Color.black);
  }
  
  public void setSelectionBackground(Color paramColor) {
    this.selectionBackground = paramColor;
    repaint();
  }
  
  public int viewToModel(int paramInt1, int paramInt2) {
    FontMetrics fontMetrics = getFontMetrics(getFont());
    int i = (paramInt2 - this.insets.top) / fontMetrics.getHeight();
    if (i < 0 || this.lines == null)
      return 0; 
    if (i >= this.lines.length)
      return this.text.length(); 
    int j = 0;
    byte b;
    for (b = 0; b < i; b++)
      j += this.lines[b].length(); 
    for (b = 1; b <= this.lines[i].length(); b++) {
      int k = fontMetrics.stringWidth(this.lines[i].substring(0, b));
      if (k + this.insets.left > paramInt1)
        return j + b - 1; 
    } 
    return j + this.lines[i].length();
  }
  
  public void setText(String paramString) {
    this.text = paramString;
    invalidate();
  }
  
  private void wrapText() {
    String str = this.text;
    if (str == null)
      return; 
    int i = (getSize()).width - this.insets.left - this.insets.right;
    FontMetrics fontMetrics = getFontMetrics(getFont());
    Vector vector = new Vector();
    StringTokenizer stringTokenizer = new StringTokenizer(str, " \n", true);
    StringBuffer stringBuffer = new StringBuffer();
    while (stringTokenizer.hasMoreTokens()) {
      String str1 = stringTokenizer.nextToken();
      if (str1.equals("\n")) {
        stringBuffer.append(str1);
        vector.addElement(stringBuffer.toString());
        stringBuffer.setLength(0);
        continue;
      } 
      if (fontMetrics.stringWidth(stringBuffer + str1) <= i) {
        stringBuffer.append(str1);
        continue;
      } 
      if (str1.equals(" ")) {
        stringBuffer.append(str1);
        vector.addElement(stringBuffer.toString());
        stringBuffer.setLength(0);
        continue;
      } 
      vector.addElement(stringBuffer.toString());
      stringBuffer.setLength(0);
      stringBuffer.append(str1);
    } 
    if (stringBuffer.length() > 0)
      vector.addElement(stringBuffer.toString()); 
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto((Object[])arrayOfString);
    this.lines = arrayOfString;
  }
  
  public String getText() {
    return this.text;
  }
  
  public synchronized void select(int paramInt1, int paramInt2) {
    this.selectionStart = Math.min(this.text.length(), Math.max(0, paramInt1));
    this.selectionEnd = Math.min(this.text.length(), Math.max(paramInt1, paramInt2));
    repaint();
  }
  
  public void invalidate() {
    this.lines = null;
    super.invalidate();
  }
  
  public void setInsets(Insets paramInsets) {
    this.insets = (Insets)paramInsets.clone();
    invalidate();
  }
  
  public Insets getInsets() {
    return (Insets)this.insets.clone();
  }
  
  public Dimension getPreferredSize() {
    Dimension dimension = new Dimension();
    Insets insets = getInsets();
    if (this.lines == null)
      wrapText(); 
    FontMetrics fontMetrics = getFontMetrics(getFont());
    for (byte b = 0; b < this.lines.length; b++)
      dimension.width = Math.max(dimension.width, fontMetrics.stringWidth(this.lines[b])); 
    dimension.height = fontMetrics.getHeight() * Math.max(this.minRows, this.lines.length);
    dimension.width += insets.left + insets.right;
    dimension.height += insets.top + insets.bottom;
    return dimension;
  }
  
  public void setMinRows(int paramInt) {
    this.minRows = paramInt;
    invalidate();
  }
  
  public void paint(Graphics paramGraphics) {
    Dimension dimension = getSize();
    paramGraphics.setColor(Color.black);
    paramGraphics.drawRect(0, -1, dimension.width - 1, dimension.height);
    if (this.text == null)
      return; 
    if (this.lines == null) {
      Container container;
      invalidate();
      wrapText();
      MultilineLabel multilineLabel = this;
      while (multilineLabel.getParent() != null && !multilineLabel.getParent().isValid())
        container = multilineLabel.getParent(); 
      container.validate();
      return;
    } 
    String[] arrayOfString = this.lines;
    if (arrayOfString == null)
      return; 
    Insets insets = getInsets();
    FontMetrics fontMetrics = getFontMetrics(getFont());
    if (this.selectionEnd > this.selectionStart) {
      paramGraphics.setColor(this.selectionBackground);
      int j = 0;
      int k = insets.top;
      int m = fontMetrics.getHeight();
      for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
        int n = j + arrayOfString[b1].length();
        if (n >= this.selectionStart && j <= this.selectionEnd) {
          int i1 = Math.max(0, this.selectionStart - j);
          int i2 = insets.left + fontMetrics.stringWidth(arrayOfString[b1].substring(0, i1));
          int i3 = fontMetrics.stringWidth(arrayOfString[b1].substring(i1, Math.max(0, Math.min(arrayOfString[b1].length(), this.selectionEnd - j))));
          paramGraphics.fillRect(i2, k, i3, m);
        } 
        j = n;
        k += m;
      } 
    } 
    paramGraphics.setColor(getForeground());
    int i = insets.top + fontMetrics.getAscent();
    for (byte b = 0; b < arrayOfString.length; b++) {
      String str = arrayOfString[b];
      if (str.length() > 0 && str.charAt(str.length() - 1) == '\n')
        str = str.substring(0, str.length() - 1); 
      paramGraphics.drawString(str, insets.left, i);
      i += fontMetrics.getHeight();
    } 
  }
  
  private void initComponents() {}
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\MultilineLabel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */