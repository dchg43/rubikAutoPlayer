package ch.randelshofer.gui;

import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.gui.event.EventListenerList;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.ItemSelectable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.EventListener;

public class AbstractButton extends Canvas implements ItemSelectable {
  private ChangeEvent changeEvent_;
  
  private Dimension preferredSize_;
  
  private Dimension minimumSize_;
  
  private boolean isPressed_;
  
  private boolean isSelected_;
  
  private boolean isArmed_;
  
  private EventListenerList listenerList_ = new EventListenerList();
  
  private String actionCommand_;
  
  private Icon selectedIcon_;
  
  private Icon unselectedIcon_;
  
  protected ButtonGroup group;
  
  public void setPressed(boolean paramBoolean) {
    if (paramBoolean != this.isPressed_) {
      this.isPressed_ = paramBoolean;
      if (!paramBoolean)
        fireActionPerformed(new ActionEvent(this, 1001, getActionCommand())); 
      fireStateChanged();
      repaint();
    } 
  }
  
  public void setGroup(ButtonGroup paramButtonGroup) {
    this.group = paramButtonGroup;
  }
  
  public boolean isPressed() {
    return this.isPressed_;
  }
  
  public void setSelected(boolean paramBoolean) {
    if (paramBoolean != this.isSelected_) {
      this.isSelected_ = paramBoolean;
      fireItemStateChanged(new ItemEvent(this, 701, this, paramBoolean ? 1 : 2));
      fireStateChanged();
      repaint();
    } 
  }
  
  public boolean isSelected() {
    return this.isSelected_;
  }
  
  public void setArmed(boolean paramBoolean) {
    if (paramBoolean != this.isArmed_) {
      this.isArmed_ = paramBoolean;
      fireStateChanged();
      repaint();
    } 
  }
  
  public boolean isArmed() {
    return this.isArmed_;
  }
  
  public void setActionCommand(String paramString) {
    this.actionCommand_ = paramString;
  }
  
  public String getActionCommand() {
    return this.actionCommand_;
  }
  
  public void setSelectedIcon(Icon paramIcon) {
    this.selectedIcon_ = paramIcon;
  }
  
  public void setUnselectedIcon(Icon paramIcon) {
    this.unselectedIcon_ = paramIcon;
  }
  
  public void setIcon(Icon paramIcon) {
    setUnselectedIcon(paramIcon);
  }
  
  public Icon getIcon() {
    return getUnselectedIcon();
  }
  
  public Icon getUnselectedIcon() {
    return this.unselectedIcon_;
  }
  
  public Icon getSelectedIcon() {
    return this.selectedIcon_;
  }
  
  public void paint(Graphics paramGraphics) {
    Dimension dimension = size();
    int i = dimension.width;
    int j = dimension.height;
    if (!isEnabled())
      paramGraphics.setColor(Color.gray); 
    paramGraphics.drawRect(0, 0, i - 1, j - 1);
    if (this.isPressed_ && this.isArmed_) {
      paramGraphics.setColor(Color.gray.darker());
      paramGraphics.fillRect(1, 1, i - 3, j - 3);
      paramGraphics.setColor(Color.darkGray);
      paramGraphics.drawLine(1, 1, i - 2, 1);
      paramGraphics.drawLine(1, 1, 1, j - 2);
      paramGraphics.setColor(Color.gray);
      paramGraphics.drawLine(2, j - 2, i - 2, j - 2);
      paramGraphics.drawLine(i - 2, j - 2, i - 2, 2);
    } else {
      paramGraphics.setColor((this.isSelected_ && this.group != null) ? new Color(160, 160, 160) : Color.lightGray);
      paramGraphics.fillRect(1, 1, i - 2, j - 2);
      if (isEnabled()) {
        paramGraphics.setColor(this.isSelected_ ? Color.gray : Color.white);
        paramGraphics.drawLine(1, 1, i - 3, 1);
        paramGraphics.drawLine(1, 1, 1, j - 3);
        if (!this.isSelected_ && this.group != null) {
          paramGraphics.setColor(Color.gray);
          paramGraphics.drawLine(1, j - 2, i - 2, j - 2);
          paramGraphics.drawLine(i - 2, j - 2, i - 2, 2);
        } 
      } 
    } 
    Icon icon = (this.isSelected_ && this.selectedIcon_ != null) ? this.selectedIcon_ : this.unselectedIcon_;
    if (icon != null) {
      paramGraphics.setColor(getForeground());
      icon.paintIcon(this, paramGraphics, 2, 1);
    } 
  }
  
  public Dimension getPreferredSize() {
    return preferredSize();
  }
  
  public Dimension preferredSize() {
    if (this.preferredSize_ == null) {
      Icon icon = getIcon();
      return (icon != null) ? new Dimension(icon.getIconWidth() + 4, icon.getIconHeight() + 4) : super.preferredSize();
    } 
    return this.preferredSize_;
  }
  
  public void setPreferredSize(Dimension paramDimension) {
    this.preferredSize_ = paramDimension;
  }
  
  public Dimension getMinimumSize() {
    return minimumSize();
  }
  
  public Dimension minimumSize() {
    return (this.minimumSize_ == null) ? super.minimumSize() : this.minimumSize_;
  }
  
  public void setMinimumSize(Dimension paramDimension) {
    this.minimumSize_ = paramDimension;
  }
  
  public boolean mouseEnter(Event paramEvent, int paramInt1, int paramInt2) {
    setArmed(true);
    repaint();
    return true;
  }
  
  public boolean mouseExit(Event paramEvent, int paramInt1, int paramInt2) {
    setArmed(false);
    repaint();
    return true;
  }
  
  public boolean mouseDown(Event paramEvent, int paramInt1, int paramInt2) {
    setArmed(true);
    setPressed(true);
    repaint();
    return true;
  }
  
  public boolean mouseUp(Event paramEvent, int paramInt1, int paramInt2) {
    setPressed(false);
    repaint();
    return true;
  }
  
  public void addChangeListener(ChangeListener paramChangeListener) {
    this.listenerList_.add(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public void removeChangeListener(ChangeListener paramChangeListener) {
    this.listenerList_.remove(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public void addActionListener(ActionListener paramActionListener) {
    this.listenerList_.add(ActionListener.class, paramActionListener);
  }
  
  public void removeActionListener(ActionListener paramActionListener) {
    this.listenerList_.remove(ActionListener.class, paramActionListener);
  }
  
  public void addItemListener(ItemListener paramItemListener) {
    this.listenerList_.add(ItemListener.class, paramItemListener);
  }
  
  public void removeItemListener(ItemListener paramItemListener) {
    this.listenerList_.remove(ItemListener.class, paramItemListener);
  }
  
  protected void fireActionPerformed(ActionEvent paramActionEvent) {
    Object[] arrayOfObject = this.listenerList_.getListenerList();
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == ActionListener.class)
        ((ActionListener)arrayOfObject[i + 1]).actionPerformed(paramActionEvent); 
    } 
  }
  
  protected void fireItemStateChanged(ItemEvent paramItemEvent) {
    Object[] arrayOfObject = this.listenerList_.getListenerList();
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == ItemListener.class)
        ((ItemListener)arrayOfObject[i + 1]).itemStateChanged(paramItemEvent); 
    } 
  }
  
  protected void fireStateChanged() {
    Object[] arrayOfObject = this.listenerList_.getListenerList();
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == ChangeListener.class) {
        if (this.changeEvent_ == null)
          this.changeEvent_ = new ChangeEvent(this); 
        ((ChangeListener)arrayOfObject[i + 1]).stateChanged(this.changeEvent_);
      } 
    } 
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent) {
    repaint();
    fireStateChanged();
  }
  
  public Object[] getSelectedObjects() {
    return null;
  }
  
  public void setEnabled(boolean paramBoolean) {
    if (paramBoolean != isEnabled()) {
      super.setEnabled(paramBoolean);
      repaint();
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\AbstractButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */