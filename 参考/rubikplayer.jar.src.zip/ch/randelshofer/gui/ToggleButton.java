package ch.randelshofer.gui;

import ch.randelshofer.gui.event.ChangeListener;
import java.awt.Event;

public class ToggleButton extends AbstractButton implements ChangeListener {
  public boolean mouseUp(Event paramEvent, int paramInt1, int paramInt2) {
    if (isEnabled() && isArmed()) {
      boolean bool = !isSelected() ? true : false;
      if (bool || this.group == null)
        setSelected(bool); 
    } 
    super.mouseUp(paramEvent, paramInt1, paramInt2);
    return true;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\ToggleButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */