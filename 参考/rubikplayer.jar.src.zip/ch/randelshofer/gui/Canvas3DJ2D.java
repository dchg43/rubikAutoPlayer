package ch.randelshofer.gui;

import ch.randelshofer.geom3d.Face3D;
import ch.randelshofer.geom3d.Transform3D;
import ch.randelshofer.util.Arrays;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Vector;

public class Canvas3DJ2D extends Canvas3DAWT {
  private static Boolean isGraphics2DAvailable = null;
  
  private static Class graphics2DClass;
  
  private static Method setRenderingHintMethod;
  
  private static Method setStrokeMethod;
  
  private static Method fillMethod;
  
  private static Method drawMethod;
  
  private static Class renderingHintsClass;
  
  private static Class renderingHintsKeyClass;
  
  private static Object keyAntialiasing;
  
  private static Object valueAntialiasOn;
  
  private static Object keyFractionalmetrics;
  
  private static Object valueFractionalmetricsOn;
  
  private static Method containsMethod;
  
  private static Class strokeClass;
  
  private static Class basicStrokeClass;
  
  private static Object capButt;
  
  private static Object joinBevel;
  
  private static Constructor basicStrokeConstructor;
  
  private static Class generalPathClass;
  
  private static Method moveToMethod;
  
  private static Method lineToMethod;
  
  private static Method closePathMethod;
  
  private static void createGraphics2DMethods() {
    if (isGraphics2DAvailable == null)
      try {
        graphics2DClass = Class.forName("java.awt.Graphics2D");
        generalPathClass = Class.forName("java.awt.geom.GeneralPath");
        renderingHintsClass = Class.forName("java.awt.RenderingHints");
        renderingHintsKeyClass = Class.forName("java.awt.RenderingHints$Key");
        strokeClass = Class.forName("java.awt.Stroke");
        basicStrokeClass = Class.forName("java.awt.BasicStroke");
        keyAntialiasing = renderingHintsClass.getField("KEY_ANTIALIASING").get(null);
        valueAntialiasOn = renderingHintsClass.getField("VALUE_ANTIALIAS_ON").get(null);
        keyFractionalmetrics = renderingHintsClass.getField("KEY_FRACTIONALMETRICS").get(null);
        valueFractionalmetricsOn = renderingHintsClass.getField("VALUE_FRACTIONALMETRICS_ON").get(null);
        capButt = basicStrokeClass.getField("CAP_BUTT").get(null);
        joinBevel = basicStrokeClass.getField("JOIN_BEVEL").get(null);
        setRenderingHintMethod = graphics2DClass.getMethod("setRenderingHint", new Class[] { renderingHintsKeyClass, Object.class });
        setStrokeMethod = graphics2DClass.getMethod("setStroke", new Class[] { strokeClass });
        fillMethod = graphics2DClass.getMethod("fill", new Class[] { Shape.class });
        drawMethod = graphics2DClass.getMethod("draw", new Class[] { Shape.class });
        basicStrokeConstructor = basicStrokeClass.getConstructor(new Class[] { float.class, int.class, int.class });
        containsMethod = Shape.class.getMethod("contains", new Class[] { double.class, double.class });
        moveToMethod = generalPathClass.getMethod("moveTo", new Class[] { float.class, float.class });
        lineToMethod = generalPathClass.getMethod("lineTo", new Class[] { float.class, float.class });
        closePathMethod = generalPathClass.getMethod("closePath", new Class[0]);
        isGraphics2DAvailable = Boolean.TRUE;
      } catch (Exception exception) {
        isGraphics2DAvailable = Boolean.FALSE;
        exception.printStackTrace();
      }  
  }
  
  public static Canvas3DAWT createCanvas3D() {
    createGraphics2DMethods();
    return (isGraphics2DAvailable == Boolean.TRUE) ? new Canvas3DJ2D() : new Canvas3DAWT();
  }
  
  private static void setGraphicHints(Graphics paramGraphics) {
    try {
      setRenderingHintMethod.invoke(paramGraphics, new Object[] { keyAntialiasing, valueAntialiasOn });
      setRenderingHintMethod.invoke(paramGraphics, new Object[] { keyFractionalmetrics, valueFractionalmetricsOn });
      Object object = basicStrokeConstructor.newInstance(new Object[] { new Float(1.0F), capButt, joinBevel });
      setStrokeMethod.invoke(paramGraphics, new Object[] { object });
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  protected void createBackGraphics(Dimension paramDimension) {
    this.backImg = createImage(paramDimension.width, paramDimension.height);
    this.backGfx = this.backImg.getGraphics();
    setGraphicHints(this.backGfx);
  }
  
  protected void paint3D(Graphics paramGraphics) {
    try {
      Insets insets = this.paintInsets;
      Object[] arrayOfObject1 = new Object[2];
      Object[] arrayOfObject2 = new Object[1];
      Object[] arrayOfObject3 = new Object[0];
      Dimension dimension = getSize();
      Transform3D transform3D = this.transformModel.getTransform();
      float f1 = (insets.left + (dimension.width - insets.left - insets.right) / 2);
      float f2 = (insets.top + (dimension.height - insets.top - insets.bottom) / 2);
      float f3 = (float)(Math.min((dimension.width - insets.left - insets.right) / 2, (dimension.height - insets.top - insets.bottom) / 2) * this.scaleFactor);
      float f4 = -f3;
      Vector vector = new Vector();
      this.activeFaces.removeAllElements();
      this.scene.addVisibleFaces(vector, transform3D, this.observer);
      Face3D[] arrayOfFace3D = new Face3D[vector.size()];
      vector.copyInto((Object[])arrayOfFace3D);
      Arrays.sort((Object[])arrayOfFace3D);
      int[] arrayOfInt1 = new int[5];
      int[] arrayOfInt2 = new int[5];
      float f5 = (float)this.observer.x;
      float f6 = (float)this.observer.y;
      float f7 = (float)this.observer.z;
      for (byte b = 0; b < arrayOfFace3D.length; b++) {
        Face3D face3D = arrayOfFace3D[b];
        if (face3D != null) {
          float[] arrayOfFloat = face3D.getCoords();
          int[] arrayOfInt = face3D.getVertices();
          Object object = generalPathClass.newInstance();
          int i = arrayOfInt[0] * 3;
          float f = arrayOfFloat[arrayOfInt[0] * 3 + 2] - f7;
          if (f != 0.0F) {
            arrayOfObject1[0] = new Float(f1 + (f5 - (f7 * arrayOfFloat[i] - f5) / f) * f3);
            arrayOfObject1[1] = new Float(f2 + (f6 - (f7 * arrayOfFloat[i + 1] - f6) / f) * f4);
            moveToMethod.invoke(object, arrayOfObject1);
          } else {
            arrayOfObject1[0] = new Float(f1 + f5 * f3);
            arrayOfObject1[1] = new Float(f2 + f6 * f4);
            moveToMethod.invoke(object, arrayOfObject1);
          } 
          for (byte b1 = 1; b1 < arrayOfInt.length; b1++) {
            i = arrayOfInt[b1] * 3;
            f = arrayOfFloat[arrayOfInt[b1] * 3 + 2] - f7;
            if (f != 0.0F) {
              arrayOfObject1[0] = new Float(f1 + (f5 - (f7 * arrayOfFloat[i] - f5) / f) * f3);
              arrayOfObject1[1] = new Float(f2 + (f6 - (f7 * arrayOfFloat[i + 1] - f6) / f) * f4);
              lineToMethod.invoke(object, arrayOfObject1);
            } else {
              arrayOfObject1[0] = new Float(f1 + f5 * f3);
              arrayOfObject1[1] = new Float(f2 + f6 * f4);
              lineToMethod.invoke(object, arrayOfObject1);
            } 
          } 
          closePathMethod.invoke(object, arrayOfObject3);
          Color color;
          if ((color = face3D.getFillColor()) != null) {
            double d;
            if (this.lightSource == null) {
              d = 1.0D;
            } else {
              d = face3D.getBrightness(this.lightSource, this.lightSourceIntensity, this.ambientLightIntensity);
            } 
            paramGraphics.setColor(new Color(Math.min(255, (int)(color.getRed() * d)), Math.min(255, (int)(color.getGreen() * d)), Math.min(255, (int)(color.getBlue() * d))));
            arrayOfObject2[0] = object;
            fillMethod.invoke(paramGraphics, arrayOfObject2);
          } 
          if ((color = face3D.getBorderColor()) != null) {
            paramGraphics.setColor(color);
            arrayOfObject2[0] = object;
            drawMethod.invoke(paramGraphics, arrayOfObject2);
          } 
          if (!this.isAdjusting && face3D.getAction() != null) {
            this.activeFaces.addElement(object);
            this.activeFaces.addElement(face3D);
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent) {
    try {
      if (isEnabled() && !this.isPopupTrigger) {
        int i = paramMouseEvent.getX();
        int j = paramMouseEvent.getY();
        this.prevx = i;
        this.prevy = j;
        Object[] arrayOfObject = { new Double(i), new Double(j) };
        for (int k = this.activeFaces.size() - 2; k >= 0; k -= 2) {
          Shape shape = this.activeFaces.elementAt(k);
          Face3D face3D = this.activeFaces.elementAt(k + 1);
          if (containsMethod.invoke(shape, arrayOfObject).equals(Boolean.TRUE)) {
            face3D.handleEvent(paramMouseEvent);
            break;
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  private void initComponents() {}
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\Canvas3DJ2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */