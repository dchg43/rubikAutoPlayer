package ch.randelshofer.gui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;

public class RatioLayout implements LayoutManager {
  private float ratio = 0.5F;
  
  public RatioLayout(float paramFloat) {
    this.ratio = paramFloat;
  }
  
  public RatioLayout() {}
  
  public void setRatio(float paramFloat) {
    this.ratio = paramFloat;
  }
  
  public void addLayoutComponent(String paramString, Component paramComponent) {}
  
  public void layoutContainer(Container paramContainer) {
    Dimension dimension = paramContainer.getSize();
    int i = (int)(dimension.width * this.ratio);
    byte b = 0;
    int j = Math.min(paramContainer.getComponentCount(), 2);
    while (b < j) {
      Component component = paramContainer.getComponent(b);
      if (b == 0) {
        component.setBounds(0, 0, i, dimension.height);
      } else {
        component.setBounds(i, 0, dimension.width - i, dimension.height);
      } 
      b++;
    } 
  }
  
  public Dimension minimumLayoutSize(Container paramContainer) {
    Dimension dimension = new Dimension();
    byte b = 0;
    int i = Math.min(paramContainer.getComponentCount(), 2);
    while (b < i) {
      Dimension dimension1 = paramContainer.getComponent(b).getMinimumSize();
      dimension.height = Math.max(dimension.height, dimension1.height);
      dimension.width += dimension1.width;
      b++;
    } 
    return dimension;
  }
  
  public Dimension preferredLayoutSize(Container paramContainer) {
    Dimension dimension = new Dimension();
    byte b = 0;
    int i = Math.min(paramContainer.getComponentCount(), 2);
    while (b < i) {
      Dimension dimension1 = paramContainer.getComponent(b).getPreferredSize();
      dimension.height = Math.max(dimension.height, dimension1.height);
      dimension.width += dimension1.width;
      b++;
    } 
    return dimension;
  }
  
  public void removeLayoutComponent(Component paramComponent) {}
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\RatioLayout.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */