package ch.randelshofer.gui;

import java.awt.Component;
import java.awt.Graphics;

public interface Icon {
  void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2);
  
  int getIconWidth();
  
  int getIconHeight();
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\Icon.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */