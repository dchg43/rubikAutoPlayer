package ch.randelshofer.gui.event;

import java.util.EventListener;

public class EventListenerList {
  private static final Object[] NULL_ARRAY = new Object[0];
  
  protected Object[] listenerList = NULL_ARRAY;
  
  public Object[] getListenerList() {
    return this.listenerList;
  }
  
  public int getListenerCount() {
    return this.listenerList.length / 2;
  }
  
  public int getListenerCount(Class paramClass) {
    byte b1 = 0;
    Object[] arrayOfObject = this.listenerList;
    for (byte b2 = 0; b2 < arrayOfObject.length; b2 += 2) {
      if (paramClass == (Class)arrayOfObject[b2])
        b1++; 
    } 
    return b1;
  }
  
  public synchronized void add(Class paramClass, EventListener paramEventListener) {
    if (!paramClass.isInstance(paramEventListener))
      throw new IllegalArgumentException("Listener " + paramEventListener + " is not of type " + paramClass); 
    if (paramEventListener == null)
      throw new IllegalArgumentException("Listener " + paramEventListener + " is null"); 
    if (this.listenerList == NULL_ARRAY) {
      this.listenerList = new Object[] { paramClass, paramEventListener };
    } else {
      int i = this.listenerList.length;
      Object[] arrayOfObject = new Object[i + 2];
      System.arraycopy(this.listenerList, 0, arrayOfObject, 0, i);
      arrayOfObject[i] = paramClass;
      arrayOfObject[i + 1] = paramEventListener;
      this.listenerList = arrayOfObject;
    } 
  }
  
  public synchronized void remove(Class paramClass, EventListener paramEventListener) {
    if (!paramClass.isInstance(paramEventListener))
      throw new IllegalArgumentException("Listener " + paramEventListener + " is not of type " + paramClass); 
    if (paramEventListener == null)
      throw new IllegalArgumentException("Listener " + paramEventListener + " is null"); 
    int i = -1;
    for (int j = this.listenerList.length - 2; j >= 0; j -= 2) {
      if (this.listenerList[j] == paramClass && this.listenerList[j + 1].equals(paramEventListener) == true) {
        i = j;
        break;
      } 
    } 
    if (i != -1) {
      Object[] arrayOfObject = new Object[this.listenerList.length - 2];
      System.arraycopy(this.listenerList, 0, arrayOfObject, 0, i);
      if (i < arrayOfObject.length)
        System.arraycopy(this.listenerList, i + 2, arrayOfObject, i, arrayOfObject.length - i); 
      this.listenerList = (arrayOfObject.length == 0) ? NULL_ARRAY : arrayOfObject;
    } 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\event\EventListenerList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */