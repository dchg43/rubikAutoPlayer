package ch.randelshofer.gui.event;

import java.util.EventObject;

public class ChangeEvent extends EventObject {
  public ChangeEvent(Object paramObject) {
    super(paramObject);
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\event\ChangeEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */