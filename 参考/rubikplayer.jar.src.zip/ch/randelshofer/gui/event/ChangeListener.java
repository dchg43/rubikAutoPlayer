package ch.randelshofer.gui.event;

import java.util.EventListener;

public interface ChangeListener extends EventListener {
  void stateChanged(ChangeEvent paramChangeEvent);
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\event\ChangeListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */