package ch.randelshofer.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;

public class ButtonGroup implements Serializable, ItemListener {
  protected Vector buttons = new Vector();
  
  AbstractButton selection = null;
  
  public void add(AbstractButton paramAbstractButton) {
    if (paramAbstractButton == null)
      return; 
    this.buttons.addElement(paramAbstractButton);
    paramAbstractButton.setGroup(this);
    if (this.selection == null && paramAbstractButton.isSelected())
      this.selection = paramAbstractButton; 
    paramAbstractButton.addItemListener(this);
  }
  
  public void remove(AbstractButton paramAbstractButton) {
    if (paramAbstractButton == null)
      return; 
    this.buttons.removeElement(paramAbstractButton);
    paramAbstractButton.setGroup(null);
    if (paramAbstractButton == this.selection)
      this.selection = null; 
    paramAbstractButton.removeItemListener(this);
  }
  
  public Enumeration getElements() {
    return this.buttons.elements();
  }
  
  public AbstractButton getSelection() {
    return this.selection;
  }
  
  public void setSelected(AbstractButton paramAbstractButton, boolean paramBoolean) {
    if (paramBoolean && paramAbstractButton != this.selection) {
      AbstractButton abstractButton = this.selection;
      this.selection = paramAbstractButton;
      if (abstractButton != null)
        abstractButton.setSelected(false); 
    } 
  }
  
  public boolean isSelected(AbstractButton paramAbstractButton) {
    return (paramAbstractButton == this.selection);
  }
  
  public int getButtonCount() {
    return (this.buttons == null) ? 0 : this.buttons.size();
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent) {
    if (paramItemEvent.getStateChange() == 1)
      setSelected((AbstractButton)paramItemEvent.getSource(), true); 
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\ButtonGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */