package ch.randelshofer.gui;

import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.gui.event.EventListenerList;
import java.util.EventListener;

public class DefaultBoundedRangeModel implements BoundedRangeModel {
  protected transient ChangeEvent changeEvent_ = null;
  
  protected EventListenerList listenerList_ = new EventListenerList();
  
  private int value_ = 0;
  
  private int extent_ = 0;
  
  private int min_ = 0;
  
  private int max_ = 100;
  
  private boolean isAdjusting_ = false;
  
  public DefaultBoundedRangeModel() {}
  
  public DefaultBoundedRangeModel(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt4 >= paramInt3 && paramInt1 >= paramInt3 && paramInt1 + paramInt2 <= paramInt4) {
      this.value_ = paramInt1;
      this.extent_ = paramInt2;
      this.min_ = paramInt3;
      this.max_ = paramInt4;
    } else {
      throw new IllegalArgumentException("invalid range properties");
    } 
  }
  
  public int getValue() {
    return this.value_;
  }
  
  public int getExtent() {
    return this.extent_;
  }
  
  public int getMinimum() {
    return this.min_;
  }
  
  public int getMaximum() {
    return this.max_;
  }
  
  public void setValue(int paramInt) {
    int i = Math.max(paramInt, this.min_);
    if (i + this.extent_ > this.max_)
      i = this.max_ - this.extent_; 
    setRangeProperties(i, this.extent_, this.min_, this.max_, this.isAdjusting_);
  }
  
  public void setExtent(int paramInt) {
    int i = Math.max(0, paramInt);
    if (this.value_ + i > this.max_)
      i = this.max_ - this.value_; 
    setRangeProperties(this.value_, i, this.min_, this.max_, this.isAdjusting_);
  }
  
  public void setMinimum(int paramInt) {
    int i = Math.max(paramInt, this.max_);
    int j = Math.max(paramInt, this.value_);
    int k = Math.min(i - j, this.extent_);
    setRangeProperties(j, k, paramInt, i, this.isAdjusting_);
  }
  
  public void setMaximum(int paramInt) {
    int i = Math.min(paramInt, this.min_);
    int j = Math.min(paramInt, this.value_);
    int k = Math.min(paramInt - j, this.extent_);
    setRangeProperties(j, k, i, paramInt, this.isAdjusting_);
  }
  
  public void setValueIsAdjusting(boolean paramBoolean) {
    setRangeProperties(this.value_, this.extent_, this.min_, this.max_, paramBoolean);
  }
  
  public boolean getValueIsAdjusting() {
    return this.isAdjusting_;
  }
  
  public void setRangeProperties(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    if (paramInt3 > paramInt4)
      paramInt3 = paramInt4; 
    if (paramInt1 > paramInt4)
      paramInt4 = paramInt1; 
    if (paramInt1 < paramInt3)
      paramInt3 = paramInt1; 
    if (paramInt2 + paramInt1 > paramInt4)
      paramInt2 = paramInt4 - paramInt1; 
    if (paramInt2 < 0)
      paramInt2 = 0; 
    boolean bool = (paramInt1 != this.value_ || paramInt2 != this.extent_ || paramInt3 != this.min_ || paramInt4 != this.max_ || paramBoolean != this.isAdjusting_) ? true : false;
    if (bool) {
      this.value_ = paramInt1;
      this.extent_ = paramInt2;
      this.min_ = paramInt3;
      this.max_ = paramInt4;
      this.isAdjusting_ = paramBoolean;
      fireStateChanged();
    } 
  }
  
  public void addChangeListener(ChangeListener paramChangeListener) {
    this.listenerList_.add(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  public void removeChangeListener(ChangeListener paramChangeListener) {
    this.listenerList_.remove(ChangeListener.class, (EventListener)paramChangeListener);
  }
  
  protected void fireStateChanged() {
    Object[] arrayOfObject = this.listenerList_.getListenerList();
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == ChangeListener.class) {
        if (this.changeEvent_ == null)
          this.changeEvent_ = new ChangeEvent(this); 
        ((ChangeListener)arrayOfObject[i + 1]).stateChanged(this.changeEvent_);
      } 
    } 
  }
  
  public String toString() {
    String str = "value_=" + getValue() + ", " + "extent_=" + getExtent() + ", " + "min_=" + getMinimum() + ", " + "max_=" + getMaximum() + ", " + "adj=" + getValueIsAdjusting();
    return getClass().getName() + "[" + str + "]";
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\DefaultBoundedRangeModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */