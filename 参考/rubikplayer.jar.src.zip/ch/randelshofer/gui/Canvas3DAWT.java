package ch.randelshofer.gui;

import ch.randelshofer.geom3d.DefaultTransform3DModel;
import ch.randelshofer.geom3d.Face3D;
import ch.randelshofer.geom3d.Point3D;
import ch.randelshofer.geom3d.SceneNode;
import ch.randelshofer.geom3d.Transform3D;
import ch.randelshofer.geom3d.Transform3DModel;
import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.util.Arrays;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.MediaTracker;
import java.awt.Polygon;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Vector;

public class Canvas3DAWT extends Canvas implements ChangeListener, MouseListener, MouseMotionListener {
  private Dimension preferredSize = new Dimension(200, 200);
  
  protected SceneNode scene;
  
  protected Graphics backGfx;
  
  protected Image backImg;
  
  protected Dimension backSize = new Dimension(0, 0);
  
  protected Transform3DModel transformModel;
  
  protected int prevx;
  
  protected int prevy;
  
  private Object lock = new Object();
  
  protected Point3D observer = new Point3D(0.0D, 0.0D, 260.0D);
  
  protected Point3D lightSource = new Point3D(-500.0D, 500.0D, 1000.0D);
  
  protected double ambientLightIntensity = 0.6D;
  
  protected double lightSourceIntensity = 1.0D;
  
  private Image backgroundImage;
  
  private boolean isArmed = true;
  
  protected boolean isAdjusting;
  
  private int unpaintedStates = 1;
  
  private boolean isMouseDrag = false;
  
  protected double scaleFactor = 1.0D;
  
  protected Vector activeFaces = new Vector();
  
  protected boolean isPopupTrigger;
  
  private boolean isRotateOnMouseDrag = false;
  
  protected Insets paintInsets = new Insets(0, 0, 0, 0);
  
  private PropertyChangeSupport changeSupport;
  
  public Canvas3DAWT() {
    addMouseListener(this);
    setBackground(Color.white);
    setRotateOnMouseDrag(true);
    setTransformModel((Transform3DModel)new DefaultTransform3DModel());
  }
  
  public void setTransformModel(Transform3DModel paramTransform3DModel) {
    Transform3DModel transform3DModel = this.transformModel;
    if (transform3DModel != null)
      transform3DModel.removeChangeListener(this); 
    this.transformModel = paramTransform3DModel;
    paramTransform3DModel.addChangeListener(this);
    stateChanged(null);
    firePropertyChange("transformModel", transform3DModel, paramTransform3DModel);
  }
  
  public Transform3DModel getTransformModel() {
    return this.transformModel;
  }
  
  public void setRotateOnMouseDrag(boolean paramBoolean) {
    if (paramBoolean != this.isRotateOnMouseDrag) {
      this.isRotateOnMouseDrag = paramBoolean;
      if (paramBoolean) {
        addMouseMotionListener(this);
      } else {
        removeMouseMotionListener(this);
      } 
    } 
  }
  
  public void setPaintInsets(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.paintInsets == null) {
      this.paintInsets = new Insets(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      this.paintInsets.top = paramInt1;
      this.paintInsets.left = paramInt2;
      this.paintInsets.bottom = paramInt3;
      this.paintInsets.right = paramInt4;
    } 
  }
  
  public void setSyncObject(Object paramObject) {
    this.lock = paramObject;
  }
  
  public void update(Graphics paramGraphics) {
    paint(paramGraphics);
  }
  
  public void paint(Graphics paramGraphics) {
    Dimension dimension = size();
    if (this.backGfx == null || this.backSize.width != dimension.width || this.backSize.height != dimension.height) {
      if (dimension.width <= 0 || dimension.height <= 0)
        return; 
      createBackGraphics(dimension);
      this.backSize = dimension;
      this.unpaintedStates = 1;
    } 
    synchronized (this.lock) {
      if (this.unpaintedStates > 0) {
        this.unpaintedStates = 0;
        paintBackground(this.backGfx);
        paint3D(this.backGfx);
      } 
    } 
    paramGraphics.drawImage(this.backImg, 0, 0, this);
  }
  
  protected void createBackGraphics(Dimension paramDimension) {
    this.backImg = createImage(paramDimension.width, paramDimension.height);
    this.backGfx = this.backImg.getGraphics();
  }
  
  public void setToIdentity() {
    this.transformModel.setToIdentity();
  }
  
  public void setObserver(float paramFloat) {
    this.observer = new Point3D(0.0D, 0.0D, paramFloat);
  }
  
  public void setAmbientLightIntensity(double paramDouble) {
    this.ambientLightIntensity = paramDouble;
  }
  
  public void setLightSourceIntensity(double paramDouble) {
    this.lightSourceIntensity = paramDouble;
  }
  
  public void setLightSource(Point3D paramPoint3D) {
    this.lightSource = paramPoint3D;
  }
  
  public void setBackgroundImage(Image paramImage) {
    this.backgroundImage = paramImage;
    MediaTracker mediaTracker = new MediaTracker(this);
    mediaTracker.addImage(paramImage, 0);
    mediaTracker.checkID(0, true);
  }
  
  public void setTransform(Transform3D paramTransform3D) {
    this.transformModel.setTransform(paramTransform3D);
  }
  
  public Transform3D getTransform() {
    return this.transformModel.getTransform();
  }
  
  public boolean imageUpdate(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    this.unpaintedStates++;
    if ((paramInt1 & 0x40) != 0 && paramImage == this.backgroundImage)
      this.backgroundImage = null; 
    return super.imageUpdate(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void setScaleFactor(double paramDouble) {
    this.scaleFactor = paramDouble;
    stateChanged(null);
  }
  
  public double getScaleFactor() {
    return this.scaleFactor;
  }
  
  public void setScene(SceneNode paramSceneNode) {
    this.scene = paramSceneNode;
    stateChanged(null);
  }
  
  private void paintBackground(Graphics paramGraphics) {
    paramGraphics.setColor(getBackground());
    paramGraphics.fillRect(0, 0, this.backSize.width, this.backSize.height);
    if (this.backgroundImage != null)
      paramGraphics.drawImage(this.backgroundImage, 0, 0, this.backSize.width, this.backSize.height, this); 
  }
  
  protected void paint3D(Graphics paramGraphics) {
    if (this.scene == null)
      return; 
    Transform3D transform3D = this.transformModel.getTransform();
    int i = (size()).width / 2;
    int j = (size()).height / 2;
    double d1 = Math.min(i, j) * this.scaleFactor;
    double d2 = -d1;
    Vector vector = new Vector();
    this.activeFaces.removeAllElements();
    this.scene.addVisibleFaces(vector, transform3D, this.observer);
    Face3D[] arrayOfFace3D = new Face3D[vector.size()];
    vector.copyInto((Object[])arrayOfFace3D);
    Arrays.sort((Object[])arrayOfFace3D);
    int[] arrayOfInt1 = new int[5];
    int[] arrayOfInt2 = new int[5];
    double d3 = this.observer.x;
    double d4 = this.observer.y;
    double d5 = this.observer.z;
    for (byte b = 0; b < arrayOfFace3D.length; b++) {
      Face3D face3D = arrayOfFace3D[b];
      float[] arrayOfFloat = face3D.getCoords();
      int[] arrayOfInt = face3D.getVertices();
      if (arrayOfInt1.length < arrayOfInt.length + 1) {
        arrayOfInt1 = new int[arrayOfInt.length + 1];
        arrayOfInt2 = new int[arrayOfInt.length + 1];
      } 
      for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
        int k = arrayOfInt[b1] * 3;
        double d = arrayOfFloat[arrayOfInt[b1] * 3 + 2] - d5;
        if (d != 0.0D) {
          arrayOfInt1[b1] = i + (int)((d3 - (d5 * arrayOfFloat[k] - d3) / d) * d1);
          arrayOfInt2[b1] = j + (int)((d4 - (d5 * arrayOfFloat[k + 1] - d4) / d) * d2);
        } else {
          arrayOfInt1[b1] = i + (int)(d3 * d1);
          arrayOfInt2[b1] = j + (int)(d4 * d2);
        } 
      } 
      Color color;
      if ((color = face3D.getFillColor()) != null) {
        double d;
        if (this.lightSource == null) {
          d = 1.0D;
        } else {
          d = face3D.getBrightness(this.lightSource, this.lightSourceIntensity, this.ambientLightIntensity);
        } 
        paramGraphics.setColor(new Color(Math.min(255, (int)(color.getRed() * d)), Math.min(255, (int)(color.getGreen() * d)), Math.min(255, (int)(color.getBlue() * d))));
        paramGraphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt.length);
      } 
      if ((color = face3D.getBorderColor()) != null) {
        paramGraphics.setColor(color);
        arrayOfInt1[arrayOfInt.length] = arrayOfInt1[0];
        arrayOfInt2[arrayOfInt.length] = arrayOfInt2[0];
        paramGraphics.drawPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt.length + 1);
      } 
      if (face3D.getAction() != null) {
        this.activeFaces.addElement(new Polygon(arrayOfInt1, arrayOfInt2, arrayOfInt.length));
        this.activeFaces.addElement(face3D);
      } 
    } 
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent) {
    if (isEnabled() && !this.isPopupTrigger) {
      int i = paramMouseEvent.getX();
      int j = paramMouseEvent.getY();
      this.prevx = i;
      this.prevy = j;
      for (int k = this.activeFaces.size() - 2; k >= 0; k -= 2) {
        Polygon polygon = this.activeFaces.elementAt(k);
        Face3D face3D = this.activeFaces.elementAt(k + 1);
        if (polygon.contains(i, j)) {
          face3D.handleEvent(paramMouseEvent);
          break;
        } 
      } 
    } 
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent) {
    this.isArmed = true;
  }
  
  public void mouseExited(MouseEvent paramMouseEvent) {
    this.isArmed = false;
  }
  
  public void mousePressed(MouseEvent paramMouseEvent) {
    this.isPopupTrigger = paramMouseEvent.isPopupTrigger();
    if (isEnabled() && !this.isPopupTrigger) {
      this.isAdjusting = true;
      this.prevx = paramMouseEvent.getX();
      this.prevy = paramMouseEvent.getY();
    } 
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent) {
    if (this.isAdjusting) {
      this.isAdjusting = false;
      stateChanged(null);
    } 
    this.isPopupTrigger |= paramMouseEvent.isPopupTrigger();
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent) {
    this.isPopupTrigger = false;
    if (this.isAdjusting && this.isArmed && isEnabled()) {
      int i = paramMouseEvent.getX();
      int j = paramMouseEvent.getY();
      Dimension dimension = getSize();
      double d1 = (this.prevy - j) * 6.283185307179586D / dimension.width;
      double d2 = (this.prevx - i) * 6.283185307179586D / dimension.height;
      this.transformModel.rotate(d1, d2, 0.0D);
      this.prevx = i;
      this.prevy = j;
    } 
  }
  
  public void mouseMoved(MouseEvent paramMouseEvent) {
    this.isPopupTrigger = false;
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent) {
    this.unpaintedStates++;
    if (this.unpaintedStates == 1 || this.unpaintedStates > 10)
      repaint(); 
  }
  
  public void setPreferredSize(Dimension paramDimension) {
    this.preferredSize = paramDimension;
  }
  
  public Dimension getPreferredSize() {
    return (this.preferredSize != null) ? this.preferredSize : super.getPreferredSize();
  }
  
  public synchronized void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {
    if (paramPropertyChangeListener == null)
      return; 
    if (this.changeSupport == null)
      this.changeSupport = new PropertyChangeSupport(this); 
    this.changeSupport.addPropertyChangeListener(paramPropertyChangeListener);
  }
  
  public synchronized void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {
    if (paramPropertyChangeListener == null || this.changeSupport == null)
      return; 
    this.changeSupport.removePropertyChangeListener(paramPropertyChangeListener);
  }
  
  protected void firePropertyChange(String paramString, Object paramObject1, Object paramObject2) {
    PropertyChangeSupport propertyChangeSupport = this.changeSupport;
    if (propertyChangeSupport == null)
      return; 
    propertyChangeSupport.firePropertyChange(paramString, paramObject1, paramObject2);
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\Canvas3DAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */