package ch.randelshofer.gui;

import ch.randelshofer.gui.event.ChangeEvent;
import ch.randelshofer.gui.event.ChangeListener;
import ch.randelshofer.media.Player;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class MovieControlAWT extends Panel implements ActionListener, ItemListener, ChangeListener {
  private Player player_;
  
  private MovieSliderAWT slider_;
  
  private AbstractButton forwardButton_;
  
  private AbstractButton rewindButton_;
  
  private ToggleButton startButton_;
  
  private BoundedRangeModel boundedRangeModel_;
  
  public MovieControlAWT() {
    setForeground(Color.black);
    Dimension dimension1 = new Dimension(15, 15);
    Dimension dimension2 = new Dimension(13, 13);
    GridBagLayout gridBagLayout = new GridBagLayout();
    setLayout(gridBagLayout);
    this.startButton_ = new ToggleButton();
    this.startButton_.setUnselectedIcon(new PolygonIcon(new Polygon(new int[] { 4, 7, 7, 4 }, new int[] { 2, 5, 6, 9 }, 4), dimension2));
    this.startButton_.setSelectedIcon(new PolygonIcon(new Polygon[] { new Polygon(new int[] { 3, 4, 4, 3 }, new int[] { 2, 2, 9, 9 }, 4), new Polygon(new int[] { 7, 8, 8, 7 }, new int[] { 2, 2, 9, 9 }, 4) }dimension2));
    this.startButton_.addItemListener(this);
    this.startButton_.setPreferredSize(dimension1);
    this.startButton_.setMinimumSize(dimension1);
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagLayout.setConstraints(this.startButton_, gridBagConstraints);
    add(this.startButton_);
    this.slider_ = new MovieSliderAWT();
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridx = 1;
    gridBagConstraints.fill = 2;
    gridBagConstraints.weightx = 1.0D;
    gridBagLayout.setConstraints(this.slider_, gridBagConstraints);
    add(this.slider_);
    this.rewindButton_ = new AbstractButton();
    this.rewindButton_.setIcon(new PolygonIcon(new Polygon[] { new Polygon(new int[] { 4, 4, 1, 1 }, new int[] { 2, 9, 6, 5 }, 4), new Polygon(new int[] { 7, 8, 8, 7 }, new int[] { 2, 2, 9, 9 }, 4) }dimension2));
    this.rewindButton_.setPreferredSize(dimension1);
    this.rewindButton_.setMinimumSize(dimension1);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridx = 2;
    gridBagLayout.setConstraints(this.rewindButton_, gridBagConstraints);
    add(this.rewindButton_);
    this.rewindButton_.addActionListener(this);
    this.forwardButton_ = new AbstractButton();
    this.forwardButton_.setIcon(new PolygonIcon(new Polygon[] { new Polygon(new int[] { 2, 3, 3, 2 }, new int[] { 2, 2, 9, 9 }, 4), new Polygon(new int[] { 6, 9, 9, 6 }, new int[] { 2, 5, 6, 9 }, 4) }dimension2));
    this.forwardButton_.setPreferredSize(dimension1);
    this.forwardButton_.setMinimumSize(dimension1);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridx = 3;
    gridBagLayout.setConstraints(this.forwardButton_, gridBagConstraints);
    add(this.forwardButton_);
    this.forwardButton_.addActionListener(this);
  }
  
  public synchronized void setPlayer(Player paramPlayer) {
    if (this.player_ != null)
      this.player_.removeChangeListener(this); 
    this.player_ = paramPlayer;
    this.boundedRangeModel_ = (this.player_ == null) ? null : this.player_.getBoundedRangeModel();
    this.slider_.setModel(this.boundedRangeModel_);
    if (this.player_ != null) {
      this.startButton_.setSelected(this.player_.isActive());
      this.player_.addChangeListener(this);
    } 
  }
  
  public void doLayout() {
    super.doLayout();
    Point point = this.startButton_.getLocation();
    this.startButton_.setLocation(point.x - 1, point.y);
    point = this.rewindButton_.getLocation();
    this.rewindButton_.setLocation(point.x + 1, point.y);
    Rectangle rectangle = this.slider_.getBounds();
    this.slider_.setBounds(rectangle.x - 2, rectangle.y, rectangle.width + 4, rectangle.height);
  }
  
  public void setProgressModel(BoundedRangeModel paramBoundedRangeModel) {
    this.slider_.setProgressModel(paramBoundedRangeModel);
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    Object object = paramActionEvent.getSource();
    if (this.boundedRangeModel_ != null) {
      int i = this.boundedRangeModel_.getValue();
      if (object == this.forwardButton_) {
        this.boundedRangeModel_.setValue((i == this.boundedRangeModel_.getMaximum()) ? this.boundedRangeModel_.getMinimum() : (i + 1));
      } else if (object == this.rewindButton_) {
        this.boundedRangeModel_.setValue((i == this.boundedRangeModel_.getMinimum()) ? this.boundedRangeModel_.getMaximum() : (i - 1));
      } 
    } 
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent) {
    if (this.player_ == null)
      return; 
    if (this.startButton_.isSelected() != this.player_.isActive())
      if (this.startButton_.isSelected()) {
        this.player_.start();
      } else {
        this.player_.stop();
      }  
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent) {
    this.startButton_.setSelected(this.player_.isActive());
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\MovieControlAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */