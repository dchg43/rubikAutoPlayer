package ch.randelshofer.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Polygon;

public class PolygonIcon implements Icon {
  private Polygon[] polygons;
  
  private Dimension size;
  
  private Color color;
  
  public PolygonIcon(Polygon[] paramArrayOfPolygon, Dimension paramDimension) {
    this.polygons = paramArrayOfPolygon;
    this.size = paramDimension;
  }
  
  public PolygonIcon(Polygon paramPolygon, Dimension paramDimension) {
    this.polygons = new Polygon[] { paramPolygon };
    this.size = paramDimension;
  }
  
  public void setForeground(Color paramColor) {
    this.color = paramColor;
  }
  
  public void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2) {
    paramGraphics.setColor(paramComponent.isEnabled() ? ((this.color != null) ? this.color : paramComponent.getForeground()) : Color.gray);
    paramGraphics.translate(paramInt1, paramInt2);
    if (this.polygons != null)
      for (byte b = 0; b < this.polygons.length; b++) {
        paramGraphics.fillPolygon(this.polygons[b]);
        paramGraphics.drawPolygon(this.polygons[b]);
      }  
    paramGraphics.translate(-paramInt1, -paramInt2);
  }
  
  public int getIconWidth() {
    return this.size.width;
  }
  
  public int getIconHeight() {
    return this.size.height;
  }
}


/* Location:              E:\games\魔方\rubikplayer.jar!\ch\randelshofer\gui\PolygonIcon.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */